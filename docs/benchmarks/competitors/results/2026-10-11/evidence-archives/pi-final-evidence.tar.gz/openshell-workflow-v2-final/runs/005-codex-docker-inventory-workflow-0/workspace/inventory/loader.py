import csv
from decimal import Decimal, InvalidOperation
from .models import Item

def load_items(path):
    items = []
    with open(path, newline='', encoding='utf-8') as source:
        reader = csv.DictReader(source, strict=True)
        required = {'sku', 'category', 'quantity', 'unit_price'}
        try:
            if not required.issubset(reader.fieldnames or []):
                raise ValueError('CSV requires sku, category, quantity and unit_price')
            for line, row in enumerate(reader, 2):
                try:
                    if None in row or any(row[key] is None for key in required):
                        raise ValueError('missing or extra fields')
                    quantity = int(row['quantity'])
                    price = Decimal(row['unit_price'])
                    if quantity < 0 or not price.is_finite() or price < 0:
                        raise ValueError('negative or non-finite value')
                    items.append(Item(row['sku'], row['category'], quantity, price))
                except (ValueError, InvalidOperation, TypeError) as exc:
                    raise ValueError(f'Invalid CSV row {line}: {exc}') from exc
        except csv.Error as exc:
            raise ValueError(f'Invalid CSV row {reader.line_num}: {exc}') from exc
    return items
