"""Inventory reporting tools."""
