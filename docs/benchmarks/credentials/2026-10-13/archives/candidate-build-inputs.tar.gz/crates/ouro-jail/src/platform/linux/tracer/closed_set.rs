//! `linux-closed-v1`: the native Linux syscalls of jail-v1 §11.2 and the
//! shape of the arguments the observer reads from each one.
//!
//! The table is the module's single source of truth. The narrowing filter
//! ([`super::filter`]) turns it into `SECCOMP_RET_TRACE` numbers, and the
//! tracer thread uses the same rows to decide which argument is a pathname,
//! which is a directory fd and where the flags live. A syscall not in this
//! table is not observed and is not claimed to be.

use crate::platform::linux::abi;

/// The operation families the consumer maps onto the §11.2 audit rows.
///
/// `Open` does not say `fs.create` or `fs.write`: that distinction is made
/// from [`Args::flags`](super::Args::flags) by the consumer, exactly as
/// §11.2 requires ("An O_CREAT open emits one `fs.create`, otherwise a
/// mutation open emits one `fs.write`"). The tracer never emits an `Open`
/// for a read-only open at all.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub enum ClosedOp {
    Exec,
    Open,
    /// `truncate`: a mutation of an existing file named by a pathname. The
    /// consumer maps it to `fs.write` with the action `truncated`.
    /// `ftruncate` is deliberately not here: it names a descriptor, not a
    /// pathname, and is excluded exactly as `write` is.
    Truncate,
    Rename,
    Unlink,
    Rmdir,
    Mkdir,
    /// `mknod`/`mknodat`: a directory entry created for a device, FIFO or
    /// regular file. The consumer maps it to `fs.create`.
    Mknod,
    Link,
    Symlink,
    Connect,
}

impl ClosedOp {
    /// Every variant, for callers that count per operation.
    pub const ALL: [ClosedOp; 11] = [
        ClosedOp::Exec,
        ClosedOp::Open,
        ClosedOp::Truncate,
        ClosedOp::Rename,
        ClosedOp::Unlink,
        ClosedOp::Rmdir,
        ClosedOp::Mkdir,
        ClosedOp::Mknod,
        ClosedOp::Link,
        ClosedOp::Symlink,
        ClosedOp::Connect,
    ];

    /// The bit this operation occupies in an [`OpSet`](super::OpSet).
    #[must_use]
    pub fn bit(self) -> u16 {
        1u16 << (self as u16)
    }

    /// The §11.2 audit operation a result of this family is reported as
    /// when it is not a denial. `flags` decides the open family: an
    /// `O_CREAT` open is `fs.create`, any other mutation open `fs.write`, and
    /// with the flags undecodable the weaker claim, `fs.write`, is made.
    /// A truncation by path is a mutation of an existing file: `fs.write`
    /// with its own action. This is the one mapping the audit writer and the
    /// published table both use.
    #[must_use]
    pub fn audit_operation(self, flags: Option<u64>) -> &'static str {
        match self {
            ClosedOp::Exec => "proc.exec",
            ClosedOp::Open => {
                if flags.is_some_and(|value| value & (libc::O_CREAT as u64) != 0) {
                    "fs.create"
                } else {
                    "fs.write"
                }
            }
            ClosedOp::Truncate => "fs.write",
            ClosedOp::Rename => "fs.rename",
            ClosedOp::Unlink | ClosedOp::Rmdir => "fs.unlink",
            ClosedOp::Mkdir | ClosedOp::Mknod | ClosedOp::Link | ClosedOp::Symlink => "fs.create",
            ClosedOp::Connect => "net.connect",
        }
    }

    #[must_use]
    pub fn as_str(self) -> &'static str {
        match self {
            ClosedOp::Exec => "exec",
            ClosedOp::Open => "open",
            ClosedOp::Truncate => "truncate",
            ClosedOp::Rename => "rename",
            ClosedOp::Unlink => "unlink",
            ClosedOp::Rmdir => "rmdir",
            ClosedOp::Mkdir => "mkdir",
            ClosedOp::Mknod => "mknod",
            ClosedOp::Link => "link",
            ClosedOp::Symlink => "symlink",
            ClosedOp::Connect => "connect",
        }
    }
}

/// Where the flags of a row come from.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum FlagSource {
    /// The call carries no flags word worth recording. `mkdir` and
    /// `mkdirat` are here: their numeric argument is a mode, and recording a
    /// mode in a field named `flags` would misdescribe it.
    None,
    /// Register `n` is the flags word.
    Arg(u8),
    /// `creat`: the kernel defines it as `open(path, O_CREAT|O_WRONLY|O_TRUNC,
    /// mode)`, so the flags are the syscall itself rather than an argument.
    #[cfg_attr(target_arch = "aarch64", allow(dead_code))] // no native creat syscall
    ImpliedCreat,
    /// `openat2`: argument `ptr` points at a `struct open_how` of `size`
    /// bytes given by argument `size`. Only `open_how.flags` is decoded, and
    /// only when the caller passed at least a whole `open_how` (§11.2:
    /// "`openat2` requires decoding only the supported size/flags").
    OpenHow { ptr: u8, size: u8 },
}

/// One row of the closed set.
#[derive(Debug, Clone, Copy)]
pub struct Entry {
    pub nr: u64,
    pub name: &'static str,
    pub op: ClosedOp,
    /// Argument index of the directory fd that `path` is resolved against.
    pub dirfd: Option<u8>,
    /// Argument index of the primary pathname pointer.
    pub path: Option<u8>,
    /// Argument index of the directory fd that `path2` is resolved against.
    pub dirfd2: Option<u8>,
    /// Argument index of the second pathname pointer, for two-path calls.
    pub path2: Option<u8>,
    pub flags: FlagSource,
    /// `(pointer argument, length argument)` of a socket address.
    pub sockaddr: Option<(u8, u8)>,
}

/// `(directory fd argument, pathname argument)`, either of which a given
/// call may not have.
type At = (Option<u8>, Option<u8>);

const fn row(
    nr: u64,
    name: &'static str,
    op: ClosedOp,
    first: At,
    second: At,
    flags: FlagSource,
) -> Entry {
    Entry {
        nr,
        name,
        op,
        dirfd: first.0,
        path: first.1,
        dirfd2: second.0,
        path2: second.1,
        flags,
        sockaddr: None,
    }
}

/// The closed set on x86_64.
///
/// The `flags` of `creat` are implied and the `mode` arguments of `mkdir`,
/// `mkdirat`, `open`-family and `openat2` are deliberately not recorded:
/// §11.2 covers the decision to open for mutation, not the permissions the
/// caller asked for.
///
/// Laid out one row per line on purpose: the table is the thing a reviewer
/// checks against jail-v1 §11.2, so it is exempt from reformatting.
#[rustfmt::skip]
pub const CLOSED_SET: &[Entry] = &[
    // proc.exec
    row(abi::nr(59, 221) as u64, "execve", ClosedOp::Exec, (None, Some(0)), (None, None), FlagSource::None),
    row(abi::nr(322, 281) as u64, "execveat", ClosedOp::Exec, (Some(0), Some(1)), (None, None), FlagSource::Arg(4)),
    // fs.create / fs.write, decided from the flags by the consumer
    #[cfg(not(target_arch = "aarch64"))]
    row(2, "open", ClosedOp::Open, (None, Some(0)), (None, None), FlagSource::Arg(1)),
    row(abi::nr(257, 56) as u64, "openat", ClosedOp::Open, (Some(0), Some(1)), (None, None), FlagSource::Arg(2)),
    row(abi::nr(437, 437) as u64, "openat2", ClosedOp::Open, (Some(0), Some(1)), (None, None), FlagSource::OpenHow { ptr: 2, size: 3 }),
    #[cfg(not(target_arch = "aarch64"))]
    row(85, "creat", ClosedOp::Open, (None, Some(0)), (None, None), FlagSource::ImpliedCreat),
    // fs.write through a pathname. The second argument is a length, not flags.
    row(abi::nr(76, 45) as u64, "truncate", ClosedOp::Truncate, (None, Some(0)), (None, None), FlagSource::None),
    // fs.rename
    #[cfg(not(target_arch = "aarch64"))]
    row(82, "rename", ClosedOp::Rename, (None, Some(0)), (None, Some(1)), FlagSource::None),
    row(abi::nr(264, 38) as u64, "renameat", ClosedOp::Rename, (Some(0), Some(1)), (Some(2), Some(3)), FlagSource::None),
    row(abi::nr(316, 276) as u64, "renameat2", ClosedOp::Rename, (Some(0), Some(1)), (Some(2), Some(3)), FlagSource::Arg(4)),
    // fs.unlink
    #[cfg(not(target_arch = "aarch64"))]
    row(87, "unlink", ClosedOp::Unlink, (None, Some(0)), (None, None), FlagSource::None),
    row(abi::nr(263, 35) as u64, "unlinkat", ClosedOp::Unlink, (Some(0), Some(1)), (None, None), FlagSource::Arg(2)),
    #[cfg(not(target_arch = "aarch64"))]
    row(84, "rmdir", ClosedOp::Rmdir, (None, Some(0)), (None, None), FlagSource::None),
    // fs.create through directory entries
    #[cfg(not(target_arch = "aarch64"))]
    row(83, "mkdir", ClosedOp::Mkdir, (None, Some(0)), (None, None), FlagSource::None),
    row(abi::nr(258, 34) as u64, "mkdirat", ClosedOp::Mkdir, (Some(0), Some(1)), (None, None), FlagSource::None),
    // mknod(path, mode, dev) and mknodat(dirfd, path, mode, dev): the second
    // numeric argument is a mode, so it is not recorded as flags.
    #[cfg(not(target_arch = "aarch64"))]
    row(133, "mknod", ClosedOp::Mknod, (None, Some(0)), (None, None), FlagSource::None),
    row(abi::nr(259, 33) as u64, "mknodat", ClosedOp::Mknod, (Some(0), Some(1)), (None, None), FlagSource::None),
    #[cfg(not(target_arch = "aarch64"))]
    row(86, "link", ClosedOp::Link, (None, Some(0)), (None, Some(1)), FlagSource::None),
    row(abi::nr(265, 37) as u64, "linkat", ClosedOp::Link, (Some(0), Some(1)), (Some(2), Some(3)), FlagSource::Arg(4)),
    // symlink(target, linkpath) and symlinkat(target, newdirfd, linkpath).
    // `path` is the link the call creates, because that is the entry every
    // other row puts there and the one the closed set classifies on. The
    // target is a string the kernel stores without resolving it, so it is
    // `path2` and has no directory fd.
    #[cfg(not(target_arch = "aarch64"))]
    row(88, "symlink", ClosedOp::Symlink, (None, Some(1)), (None, Some(0)), FlagSource::None),
    row(abi::nr(266, 36) as u64, "symlinkat", ClosedOp::Symlink, (Some(1), Some(2)), (None, Some(0)), FlagSource::None),
    // net.connect
    Entry {
        nr: abi::nr(42, 203) as u64,
        name: "connect",
        op: ClosedOp::Connect,
        dirfd: None,
        path: None,
        dirfd2: None,
        path2: None,
        flags: FlagSource::None,
        sockaddr: Some((1, 2)),
    },
];

/// The row for a syscall number, or `None` when the number is outside the
/// closed set.
#[must_use]
pub fn lookup(nr: u64) -> Option<&'static Entry> {
    CLOSED_SET.iter().find(|entry| entry.nr == nr)
}

/// `O_CREAT|O_WRONLY|O_TRUNC`, the flags `creat` is defined as.
#[must_use]
pub fn implied_creat_flags() -> u64 {
    (libc::O_CREAT | libc::O_WRONLY | libc::O_TRUNC) as u64
}

/// Whether an open-family call asks for something the closed set covers.
///
/// §11.2 covers `open`, `openat`, `openat2` and `creat` "requesting
/// write/create/truncate". A read-only open is outside the set: it is not a
/// lost event and does not degrade coverage ("Operations explicitly outside
/// the closed set are not lost events").
#[must_use]
pub fn open_is_covered(flags: u64) -> bool {
    let accmode = flags & (libc::O_ACCMODE as u64);
    accmode != (libc::O_RDONLY as u64) || (flags & ((libc::O_CREAT | libc::O_TRUNC) as u64)) != 0
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::BTreeSet;

    #[test]
    fn the_set_has_exactly_the_twenty_two_rows_of_the_spec() {
        let count = if abi::AARCH64 { 13 } else { 22 };
        assert_eq!(CLOSED_SET.len(), count);
        let numbers: BTreeSet<u64> = CLOSED_SET.iter().map(|e| e.nr).collect();
        assert_eq!(numbers.len(), count, "no syscall number may appear twice");
        let expected: BTreeSet<u64> = if abi::AARCH64 {
            vec![221, 281, 56, 437, 45, 38, 276, 35, 34, 33, 37, 36, 203]
        } else {
            vec![
                59, 322, 2, 257, 437, 85, 76, 82, 264, 316, 87, 263, 84, 83, 258, 133, 259, 86,
                265, 88, 266, 42,
            ]
        }
        .into_iter()
        .collect();
        assert_eq!(numbers, expected);
        let names: BTreeSet<&str> = CLOSED_SET.iter().map(|e| e.name).collect();
        assert_eq!(names.len(), count, "no syscall name may appear twice");
    }

    /// `ftruncate` names a descriptor rather than a pathname, so it is
    /// excluded exactly as `write` is, and the table must say so by not
    /// containing it.
    #[test]
    #[cfg(any(target_arch = "x86_64", target_arch = "aarch64"))]
    fn descriptor_based_mutations_stay_outside_the_set() {
        for nr in [
            libc::SYS_ftruncate,
            libc::SYS_write,
            libc::SYS_pwrite64,
            libc::SYS_writev,
        ] {
            assert!(
                lookup(nr as u64).is_none(),
                "syscall {nr} mutates through a descriptor and is outside the set"
            );
        }
    }

    /// The table must agree with the `SYS_*` numbers of this target, which is
    /// the only cross-check that catches a transposed digit.
    #[test]
    #[cfg(any(target_arch = "x86_64", target_arch = "aarch64"))]
    fn numbers_match_the_targets_syscall_table() {
        let expected: &[(&str, u64)] = &[
            ("execve", libc::SYS_execve as u64),
            ("execveat", libc::SYS_execveat as u64),
            #[cfg(target_arch = "x86_64")]
            ("open", libc::SYS_open as u64),
            ("openat", libc::SYS_openat as u64),
            #[cfg(target_arch = "x86_64")]
            ("creat", libc::SYS_creat as u64),
            #[cfg(target_arch = "x86_64")]
            ("rename", libc::SYS_rename as u64),
            ("renameat", libc::SYS_renameat as u64),
            ("renameat2", libc::SYS_renameat2 as u64),
            #[cfg(target_arch = "x86_64")]
            ("unlink", libc::SYS_unlink as u64),
            ("unlinkat", libc::SYS_unlinkat as u64),
            #[cfg(target_arch = "x86_64")]
            ("rmdir", libc::SYS_rmdir as u64),
            #[cfg(target_arch = "x86_64")]
            ("mkdir", libc::SYS_mkdir as u64),
            ("mkdirat", libc::SYS_mkdirat as u64),
            #[cfg(target_arch = "x86_64")]
            ("link", libc::SYS_link as u64),
            ("linkat", libc::SYS_linkat as u64),
            #[cfg(target_arch = "x86_64")]
            ("symlink", libc::SYS_symlink as u64),
            ("symlinkat", libc::SYS_symlinkat as u64),
            ("connect", libc::SYS_connect as u64),
            ("truncate", libc::SYS_truncate as u64),
            #[cfg(target_arch = "x86_64")]
            ("mknod", libc::SYS_mknod as u64),
            ("mknodat", libc::SYS_mknodat as u64),
        ];
        for (name, nr) in expected {
            let entry = CLOSED_SET.iter().find(|e| e.name == *name).expect(name);
            assert_eq!(entry.nr, *nr, "{name}");
            assert_eq!(lookup(*nr).map(|e| e.name), Some(*name));
        }
        // openat2 is number 437 on every architecture that has it; libc does
        // not always export SYS_openat2, so it is checked against the value
        // the kernel's syscall table fixes.
        assert_eq!(lookup(437).map(|e| e.name), Some("openat2"));
    }

    #[test]
    fn nothing_outside_the_set_resolves() {
        assert!(lookup(0).is_none(), "read is not in the closed set");
        assert!(lookup(1).is_none(), "write is not in the closed set");
        assert!(lookup(9).is_none(), "mmap is not in the closed set");
        assert!(lookup(u64::from(u32::MAX)).is_none());
    }

    #[test]
    fn two_path_rows_carry_both_paths_and_their_directory_fds() {
        for name in [
            #[cfg(target_arch = "x86_64")]
            "rename",
            "renameat",
            "renameat2",
            #[cfg(target_arch = "x86_64")]
            "link",
            "linkat",
            #[cfg(target_arch = "x86_64")]
            "symlink",
            "symlinkat",
        ] {
            let e = CLOSED_SET.iter().find(|e| e.name == name).expect(name);
            assert!(
                e.path.is_some() && e.path2.is_some(),
                "{name} must snapshot both paths"
            );
            assert_ne!(e.path, e.path2, "{name} must read two different arguments");
        }
        let renameat = CLOSED_SET.iter().find(|e| e.name == "renameat").unwrap();
        assert_eq!((renameat.dirfd, renameat.dirfd2), (Some(0), Some(2)));
    }

    /// `path` is the entry the call creates or touches on every row. For
    /// `symlink` that is the link, argument 1, not the target string the
    /// kernel stores without resolving.
    #[test]
    fn symlink_puts_the_link_it_creates_in_the_primary_path() {
        #[cfg(target_arch = "x86_64")]
        {
            let symlink = CLOSED_SET.iter().find(|e| e.name == "symlink").unwrap();
            assert_eq!(symlink.path, Some(1), "symlink(target, linkpath): the link");
            assert_eq!(symlink.path2, Some(0), "and the target is the second path");
            assert_eq!(symlink.dirfd, None);
            assert_eq!(
                symlink.dirfd2, None,
                "a stored string is resolved against nothing"
            );
        }
        let symlinkat = CLOSED_SET.iter().find(|e| e.name == "symlinkat").unwrap();
        assert_eq!(
            symlinkat.path,
            Some(2),
            "symlinkat(target, newdirfd, linkpath)"
        );
        assert_eq!(
            symlinkat.dirfd,
            Some(1),
            "the link resolves against newdirfd"
        );
        assert_eq!(symlinkat.path2, Some(0));
        assert_eq!(symlinkat.dirfd2, None);
    }

    #[test]
    fn open_coverage_follows_the_spec_table() {
        let rdonly = libc::O_RDONLY as u64;
        assert!(
            !open_is_covered(rdonly),
            "a read-only open is outside the set"
        );
        assert!(
            !open_is_covered(rdonly | libc::O_CLOEXEC as u64),
            "O_CLOEXEC changes nothing"
        );
        assert!(
            !open_is_covered(rdonly | libc::O_DIRECTORY as u64),
            "opening a directory to read it"
        );
        assert!(open_is_covered(libc::O_WRONLY as u64));
        assert!(open_is_covered(libc::O_RDWR as u64));
        assert!(
            open_is_covered(rdonly | libc::O_CREAT as u64),
            "O_CREAT|O_RDONLY still creates"
        );
        assert!(
            open_is_covered(rdonly | libc::O_TRUNC as u64),
            "O_TRUNC mutates"
        );
        assert!(open_is_covered(implied_creat_flags()));
    }

    #[test]
    fn implied_creat_flags_are_what_creat_means() {
        let f = implied_creat_flags();
        assert_eq!(f & (libc::O_ACCMODE as u64), libc::O_WRONLY as u64);
        assert_ne!(f & (libc::O_CREAT as u64), 0);
        assert_ne!(f & (libc::O_TRUNC as u64), 0);
    }
}
