//! The raw kernel interface the observer needs: ptrace, `process_vm_readv`,
//! `waitpid`, `seccomp`.
//!
//! Every `unsafe` block in the tracer that is not the seccomp install lives
//! here, so the rest of the module is ordinary Rust. The request numbers and
//! option bits are spelled out rather than taken from `libc` so that the ABI
//! this module speaks is visible in one place; [`tests`] asserts each one
//! against `libc` so a typo cannot survive a build.

use std::io;

use libc::{c_int, c_uint, c_void, pid_t};

// ------------------------------------------------------------ ptrace ABI

pub const PTRACE_CONT: c_uint = 7;
pub const PTRACE_SINGLESTEP: c_uint = 9;
/// Read only by the x86_64 register reader; other architectures' ABIs
/// have no `PTRACE_GETREGS` (aarch64 uses `PTRACE_GETREGSET`).
#[cfg(target_arch = "x86_64")]
pub const PTRACE_GETREGS: c_uint = 12;
pub const PTRACE_DETACH: c_uint = 17;
pub const PTRACE_SYSCALL: c_uint = 24;
pub const PTRACE_GETEVENTMSG: c_uint = 0x4201;
pub const PTRACE_GETSIGINFO: c_uint = 0x4202;
pub const PTRACE_SEIZE: c_uint = 0x4206;
pub const PTRACE_LISTEN: c_uint = 0x4208;
/// Not in every `libc` release; kernel 4.3 and later.
pub const PTRACE_GET_SYSCALL_INFO: c_uint = 0x420e;

pub const PTRACE_O_TRACESYSGOOD: u64 = 0x0000_0001;
pub const PTRACE_O_TRACEFORK: u64 = 0x0000_0002;
pub const PTRACE_O_TRACEVFORK: u64 = 0x0000_0004;
pub const PTRACE_O_TRACECLONE: u64 = 0x0000_0008;
pub const PTRACE_O_TRACEEXEC: u64 = 0x0000_0010;
pub const PTRACE_O_TRACEEXIT: u64 = 0x0000_0040;
pub const PTRACE_O_TRACESECCOMP: u64 = 0x0000_0080;
pub const PTRACE_O_EXITKILL: u64 = 0x0010_0000;

/// The option word of the contract: every event the closed set needs, plus
/// `EXITKILL` so a dead supervisor cannot leave a traced tree running.
///
/// It is delivered by `PTRACE_SEIZE` itself rather than by a following
/// `PTRACE_SETOPTIONS`, which the kernel would refuse: every ptrace request
/// other than attach, seize, interrupt and kill needs the tracee stopped, and
/// a seized tracee is not.
pub const SEIZE_OPTIONS: u64 = PTRACE_O_TRACESYSGOOD
    | PTRACE_O_TRACEFORK
    | PTRACE_O_TRACEVFORK
    | PTRACE_O_TRACECLONE
    | PTRACE_O_TRACEEXEC
    | PTRACE_O_TRACEEXIT
    | PTRACE_O_TRACESECCOMP
    | PTRACE_O_EXITKILL;

pub const PTRACE_EVENT_FORK: c_int = 1;
pub const PTRACE_EVENT_VFORK: c_int = 2;
pub const PTRACE_EVENT_CLONE: c_int = 3;
pub const PTRACE_EVENT_EXEC: c_int = 4;
pub const PTRACE_EVENT_VFORK_DONE: c_int = 5;
pub const PTRACE_EVENT_EXIT: c_int = 6;
pub const PTRACE_EVENT_SECCOMP: c_int = 7;
pub const PTRACE_EVENT_STOP: c_int = 128;

/// `SIGTRAP | 0x80`: a syscall stop under `PTRACE_O_TRACESYSGOOD`.
pub const SYSCALL_STOP_SIG: c_int = libc::SIGTRAP | 0x80;

/// `si_code` of the stop the kernel reports at a signal handler's entry
/// while the tracee is single-stepped (`signal_delivered` →
/// `ptrace_notify(SIGTRAP, 0)`): the notification's exit code, `SIGTRAP`.
pub const SI_CODE_HANDLER_ENTRY: c_int = libc::SIGTRAP;
/// `si_code` of a `SIGTRAP` a single step raises: after one user
/// instruction (`TRAP_TRACE`), or at the exit of a syscall the kernel ran
/// while stepping (`TRAP_BRKPT`, `user_single_step_report`).
pub const TRAP_BRKPT: c_int = 1;
pub const TRAP_TRACE: c_int = 2;

/// Offsets from ucontext to the interrupted result register and PC.
/// x86_64 has mcontext at 40, with rax/rip at words 13/16; arm64 has
/// mcontext at 176, then fault_address, x0..x30, sp and pc. Native libc
/// layout assertions below independently check both ABIs.
pub const FRAME_RESULT: u64 = if cfg!(target_arch = "aarch64") {
    176 + 8
} else {
    40 + 13 * 8
};
pub const FRAME_IP: u64 = if cfg!(target_arch = "aarch64") {
    176 + 8 + 32 * 8
} else {
    40 + 16 * 8
};

/// `struct ptrace_syscall_info.op`.
pub const SYSCALL_INFO_NONE: u8 = 0;
pub const SYSCALL_INFO_ENTRY: u8 = 1;
pub const SYSCALL_INFO_EXIT: u8 = 2;
pub const SYSCALL_INFO_SECCOMP: u8 = 3;

/// The in-kernel restart codes. They are visible to a tracer at a syscall
/// exit stop and never to user space. None of them is a result yet: when
/// the thread next returns to user space the kernel either re-enters the
/// call or turns the code into `EINTR`, depending on the code and on the
/// signal being delivered (`arch/{x86,arm64}/kernel/signal.c`):
///
/// | code | a handler runs | no handler runs |
/// |---|---|---|
/// | `ERESTARTSYS` | `EINTR`, or re-entered under `SA_RESTART` | re-entered |
/// | `ERESTARTNOINTR` | re-entered | re-entered |
/// | `ERESTARTNOHAND` | `EINTR` | re-entered |
/// | `ERESTART_RESTARTBLOCK` | `EINTR` | continued by `restart_syscall` |
///
/// Taking a code for a result would double-count a re-entered call (jail-v1
/// §11.2, "Syscall restarts must not create duplicate successes"); taking
/// every code for a re-entry loses the `EINTR` result (J4 O-2).
pub const ERESTARTSYS: i64 = 512;
pub const ERESTARTNOINTR: i64 = 513;
pub const ERESTARTNOHAND: i64 = 514;
pub const ERESTART_RESTARTBLOCK: i64 = 516;

/// True for the four restart codes, and for nothing else. The range is not
/// contiguous: 515 is `ENOIOCTLCMD`, an ordinary internal failure and not a
/// signal to re-enter the syscall.
#[must_use]
pub fn is_restart(rval: i64) -> bool {
    matches!(
        rval,
        v if v == -ERESTARTSYS
            || v == -ERESTARTNOINTR
            || v == -ERESTARTNOHAND
            || v == -ERESTART_RESTARTBLOCK
    )
}

// ------------------------------------------------------------ seccomp ABI

pub const SECCOMP_SET_MODE_FILTER: libc::c_long = 1;
pub const SECCOMP_RET_ALLOW: u32 = 0x7fff_0000;
pub const SECCOMP_RET_TRACE: u32 = 0x7ff0_0000;
pub const AUDIT_ARCH: u32 = crate::platform::linux::abi::AUDIT_ARCH;
/// x86_64 marks an x32 syscall by this bit in `nr`.
pub const X32_SYSCALL_BIT: u32 = 0x4000_0000;
/// The 32-bit x86 audit architecture: `int 0x80` entries carry this arch and
/// numbers from the i386 table (audit 4 B2).
pub const AUDIT_ARCH_I386: u32 = 0x4000_0003;

pub const BPF_LD_W_ABS: u16 = 0x20;
pub const BPF_JEQ_K: u16 = 0x15;
pub const BPF_JSET_K: u16 = 0x45;
pub const BPF_RET_K: u16 = 0x06;

/// Byte offsets into `struct seccomp_data`.
pub const SECCOMP_DATA_NR: u32 = 0;
pub const SECCOMP_DATA_ARCH: u32 = 4;
/// The low word of `args[0]` on a little-endian host.
pub const SECCOMP_DATA_ARG0_LOW: u32 = 16;
/// The low word of `args[1]` on a little-endian host.
pub const SECCOMP_DATA_ARG1_LOW: u32 = 24;
/// The low word of `args[2]` on a little-endian host.
pub const SECCOMP_DATA_ARG2_LOW: u32 = 32;
/// `SECCOMP_RET_ERRNO`, with the errno in the data bits.
pub const SECCOMP_RET_ERRNO: u32 = 0x0005_0000;
/// Linux `ENOSYS`, spelled out because the filter targets the Linux ABI.
pub const LINUX_ENOSYS: u32 = 38;
/// `SECCOMP_RET_DATA`: the low sixteen bits of a verdict, which
/// `PTRACE_GETEVENTMSG` reports at a `PTRACE_EVENT_SECCOMP` stop.
pub const SECCOMP_RET_DATA: u32 = 0x0000_ffff;

// ------------------------------------------------------------ ptrace calls

fn ptrace_raw(
    request: c_uint,
    pid: pid_t,
    addr: *mut c_void,
    data: *mut c_void,
) -> io::Result<libc::c_long> {
    // `ptrace` returns -1 both for an error and for a legitimate -1 result,
    // so errno is cleared first. The observer never uses PEEK requests, where
    // that distinction matters, but clearing costs nothing and keeps the
    // helper honest for every caller.
    // SAFETY: `__errno_location` returns a pointer to this thread's errno,
    // valid for the lifetime of the thread.
    unsafe { *libc::__errno_location() = 0 };
    // SAFETY: a ptrace request with a pid and two machine words. Every caller
    // below passes either a null pointer, an integer encoded as a pointer
    // (which the kernel reads as a value, never dereferences), or a pointer to
    // a live local buffer whose size matches the `addr` argument. The kernel
    // validates `pid`; a wrong one fails with ESRCH rather than acting on
    // another process.
    let rc = unsafe { libc::ptrace(request, pid, addr, data) };
    if rc == -1 {
        let err = io::Error::last_os_error();
        if err.raw_os_error() != Some(0) {
            return Err(err);
        }
    }
    Ok(rc)
}

fn as_ptr(value: u64) -> *mut c_void {
    value as usize as *mut c_void
}

/// `PTRACE_SEIZE` with the option word in one call. The tracee is not
/// stopped by this and does not learn it happened.
pub fn seize(pid: pid_t, options: u64) -> io::Result<()> {
    ptrace_raw(PTRACE_SEIZE, pid, std::ptr::null_mut(), as_ptr(options)).map(|_| ())
}

/// Restart a stopped tracee. `signal` is delivered to it; 0 delivers nothing.
pub fn restart(pid: pid_t, request: c_uint, signal: c_int) -> io::Result<()> {
    ptrace_raw(request, pid, std::ptr::null_mut(), as_ptr(signal as u64)).map(|_| ())
}

/// `PTRACE_LISTEN`: leave a group-stopped tracee stopped, as the signal that
/// stopped it intended, while staying its tracer.
pub fn listen(pid: pid_t) -> io::Result<()> {
    ptrace_raw(
        PTRACE_LISTEN,
        pid,
        std::ptr::null_mut(),
        std::ptr::null_mut(),
    )
    .map(|_| ())
}

/// Whether a stopped tracee is in a group-stop.
///
/// `PTRACE_GETSIGINFO` is the documented way to tell the two kinds of
/// `PTRACE_EVENT_STOP` apart: it fails with `EINVAL` for a group-stop and
/// succeeds for the stop a `PTRACE_INTERRUPT` or a fresh attach produced.
/// Getting this wrong means either resuming a process the user stopped or
/// leaving a fresh tracee in `PTRACE_LISTEN` forever.
pub fn is_group_stop(pid: pid_t) -> bool {
    // `siginfo_t` is larger than anything the kernel writes here; a local of
    // the right type is the safe way to give the kernel its buffer.
    let mut info: libc::siginfo_t = unsafe { std::mem::zeroed() };
    match ptrace_raw(
        PTRACE_GETSIGINFO,
        pid,
        std::ptr::null_mut(),
        (&raw mut info).cast::<c_void>(),
    ) {
        Ok(_) => false,
        Err(err) => err.raw_os_error() == Some(libc::EINVAL),
    }
}

/// Send `signal` to one task of this process.
pub fn tgkill(tid: pid_t, signal: c_int) -> io::Result<()> {
    // SAFETY: `tgkill` takes three integers. The tgid is this process, so the
    // signal cannot reach a task outside it even if `tid` has been recycled.
    let rc = unsafe { libc::syscall(libc::SYS_tgkill, libc::getpid(), tid, signal) };
    if rc == 0 {
        Ok(())
    } else {
        Err(io::Error::last_os_error())
    }
}

/// Send `signal` to a tracee. Used to end a tree that will not end itself.
pub fn kill(pid: pid_t, signal: c_int) -> io::Result<()> {
    // SAFETY: `kill` takes a pid and a signal and dereferences nothing.
    let rc = unsafe { libc::kill(pid, signal) };
    if rc == 0 {
        Ok(())
    } else {
        Err(io::Error::last_os_error())
    }
}

extern "C" fn wake_handler(_signal: c_int) {}

/// The signal the supervisor uses to interrupt the tracer thread's
/// `waitpid`.
///
/// A real-time signal above the range glibc reserves for its own threading
/// implementation, so installing a handler for it cannot disturb anything
/// else in the process.
#[must_use]
pub fn wake_signal() -> c_int {
    libc::SIGRTMIN() + 1
}

/// Install the no-op handler that makes a blocking `waitpid` return `EINTR`.
///
/// The handler does nothing at all: it allocates nothing, takes no lock and
/// touches no global state, so it is async-signal-safe by construction. It
/// exists only so that the kernel interrupts the wait; without `SA_RESTART`
/// the syscall returns `EINTR` and the tracer thread gets to look at its stop
/// flag. This is process-global state, installed once, the first time a
/// tracer is attached.
///
/// # Errors
/// The `errno` of `sigaction`.
pub fn install_wake_handler() -> io::Result<()> {
    // SAFETY: `sigaction` is a plain C struct of integers and a function
    // pointer; zeroing it is the documented way to start from a clean one.
    let mut action: libc::sigaction = unsafe { std::mem::zeroed() };
    let handler: extern "C" fn(c_int) = wake_handler;
    action.sa_sigaction = handler as *const () as usize;
    // No SA_RESTART: the point is that `waitpid` returns EINTR.
    action.sa_flags = 0;
    // SAFETY: `sigemptyset` writes one `sigset_t` through the pointer.
    unsafe { libc::sigemptyset(&raw mut action.sa_mask) };
    // SAFETY: installs a handler for one signal. `action` is live for the
    // call; the old action is not wanted, so the third argument is null.
    let rc = unsafe { libc::sigaction(wake_signal(), &raw const action, std::ptr::null_mut()) };
    if rc == 0 {
        Ok(())
    } else {
        Err(io::Error::last_os_error())
    }
}

pub fn detach(pid: pid_t) -> io::Result<()> {
    ptrace_raw(
        PTRACE_DETACH,
        pid,
        std::ptr::null_mut(),
        std::ptr::null_mut(),
    )
    .map(|_| ())
}

pub fn event_msg(pid: pid_t) -> io::Result<u64> {
    let mut msg: libc::c_ulong = 0;
    ptrace_raw(
        PTRACE_GETEVENTMSG,
        pid,
        std::ptr::null_mut(),
        (&raw mut msg).cast::<c_void>(),
    )?;
    Ok(msg as u64)
}

/// The decoded `struct ptrace_syscall_info` of a stopped tracee.
#[derive(Debug, Default, Clone, Copy)]
pub struct SyscallInfo {
    pub op: u8,
    pub arch: u32,
    /// The user instruction pointer: at an entry or seccomp stop, the
    /// address just past the instruction that made the call.
    pub ip: u64,
    pub nr: u64,
    pub args: [u64; 6],
    pub rval: i64,
}

/// `struct ptrace_syscall_info` as the kernel lays it out on both native ABIs:
/// `op` at 0, `arch` at 4, `instruction_pointer` at 8, `stack_pointer` at
/// 16, then the union at 24 (`nr` + six args for an entry or seccomp stop,
/// `rval` for an exit stop).
const SYSCALL_INFO_LEN: usize = 88;

/// # Errors
/// The `errno` of `PTRACE_GET_SYSCALL_INFO`: `ESRCH` when the tracee is no
/// longer in the stop — at a stop the tracer has not resumed, only a
/// `SIGKILL` does that — and `EIO` when the kernel described nothing.
pub fn syscall_info(pid: pid_t) -> io::Result<SyscallInfo> {
    let mut buf = [0u8; SYSCALL_INFO_LEN];
    let n = ptrace_raw(
        PTRACE_GET_SYSCALL_INFO,
        pid,
        as_ptr(buf.len() as u64),
        buf.as_mut_ptr().cast::<c_void>(),
    )?;
    if n <= 0 {
        return Err(io::Error::from_raw_os_error(libc::EIO));
    }
    let word = |off: usize| u64::from_ne_bytes(buf[off..off + 8].try_into().unwrap_or([0; 8]));
    let mut info = SyscallInfo {
        op: buf[0],
        arch: u32::from_ne_bytes(buf[4..8].try_into().unwrap_or([0; 4])),
        ip: word(8),
        ..SyscallInfo::default()
    };
    match info.op {
        SYSCALL_INFO_ENTRY | SYSCALL_INFO_SECCOMP => {
            info.nr = word(24);
            for (i, slot) in info.args.iter_mut().enumerate() {
                *slot = word(32 + 8 * i);
            }
        }
        SYSCALL_INFO_EXIT => info.rval = word(24) as i64,
        _ => {}
    }
    Ok(info)
}

/// `si_signo` and `si_code` of the siginfo a stopped tracee reports.
///
/// # Errors
/// The `errno` of `PTRACE_GETSIGINFO` (`EINVAL` for a group-stop).
pub fn siginfo(pid: pid_t) -> io::Result<(c_int, c_int)> {
    // SAFETY: an all-zero `siginfo_t` is a valid value of the type; the
    // kernel overwrites it.
    let mut info: libc::siginfo_t = unsafe { std::mem::zeroed() };
    ptrace_raw(
        PTRACE_GETSIGINFO,
        pid,
        std::ptr::null_mut(),
        (&raw mut info).cast::<c_void>(),
    )?;
    Ok((info.si_signo, info.si_code))
}

/// Locate the signal frame the kernel has just built for a single-stepped
/// handler. Called only after checking the kernel's handler-entry siginfo.
#[cfg(target_arch = "x86_64")]
pub fn handler_ucontext(
    pid: pid_t,
    delivered: u64,
    _site_ip: u64,
    _next_ip: u64,
) -> io::Result<Option<u64>> {
    // SAFETY: integer register buffer of the kernel's documented size.
    let mut regs: libc::user_regs_struct = unsafe { std::mem::zeroed() };
    ptrace_raw(
        PTRACE_GETREGS,
        pid,
        std::ptr::null_mut(),
        (&raw mut regs).cast(),
    )?;
    Ok(
        (regs.rax == 0 && regs.rdi == delivered && regs.rsp.checked_add(8) == Some(regs.rdx))
            .then_some(regs.rdx),
    )
}

/// Linux arm64 user_pt_regs: x0..x30, sp, pc, pstate (NT_PRSTATUS).
#[cfg(target_arch = "aarch64")]
#[repr(C)]
#[derive(Default)]
struct Arm64Regs {
    x: [u64; 31],
    sp: u64,
    pc: u64,
    pstate: u64,
}

#[cfg(target_arch = "aarch64")]
fn arm64_regset<T>(pid: pid_t, request: c_uint, note: u64, value: &mut T) -> io::Result<()> {
    let mut iov = libc::iovec {
        iov_base: std::ptr::from_mut(value).cast(),
        iov_len: std::mem::size_of::<T>(),
    };
    ptrace_raw(request, pid, as_ptr(note), (&raw mut iov).cast())?;
    if iov.iov_len != std::mem::size_of::<T>() {
        return Err(io::Error::from_raw_os_error(libc::EIO));
    }
    Ok(())
}

#[cfg(target_arch = "aarch64")]
pub fn handler_ucontext(
    pid: pid_t,
    delivered: u64,
    site_ip: u64,
    next_ip: u64,
) -> io::Result<Option<u64>> {
    let mut regs = Arm64Regs::default();
    arm64_regset(pid, libc::PTRACE_GETREGSET, 1, &mut regs)?;
    // rt_sigframe is siginfo (128 bytes), then ucontext. The kernel only
    // supplies x2 with SA_SIGINFO, so derive the frame from sp for ordinary
    // handlers too. setup_return always sets x0 to the delivered signal.
    // `do_signal` restores x0 before `get_signal`, so a forged SIGTRAP could
    // satisfy the x0 test at the restart site; require the pc to be neither
    // the interrupted `svc` nor the instruction after it, which only the
    // kernel's handler-entry notification can produce.
    Ok(
        if regs.x[0] == delivered && regs.sp & 15 == 0 && regs.pc != site_ip && regs.pc != next_ip {
            regs.sp.checked_add(128)
        } else {
            None
        },
    )
}

#[cfg(not(any(target_arch = "x86_64", target_arch = "aarch64")))]
pub fn handler_ucontext(
    _pid: pid_t,
    _delivered: u64,
    _site_ip: u64,
    _next_ip: u64,
) -> io::Result<Option<u64>> {
    Err(io::Error::from_raw_os_error(libc::ENOSYS))
}

// ------------------------------------------------------- remote memory

/// Copy at most `out.len()` bytes from `addr` in `pid`.
///
/// Returns the number of bytes copied. A short or zero return is normal: the
/// kernel stops at an unmapped page, and `process_vm_readv` may satisfy fewer
/// bytes than asked for. The caller decides what a short read means; this
/// function never invents bytes.
pub fn read_remote(pid: pid_t, addr: u64, out: &mut [u8]) -> usize {
    if addr == 0 || out.is_empty() {
        return 0;
    }
    let local = libc::iovec {
        iov_base: out.as_mut_ptr().cast::<c_void>(),
        iov_len: out.len(),
    };
    let remote = libc::iovec {
        iov_base: addr as usize as *mut c_void,
        iov_len: out.len(),
    };
    // SAFETY: one local iovec describing `out`, which is live and writable for
    // `out.len()` bytes, and one remote iovec that is only an address and a
    // length in another address space; the kernel validates it and returns
    // EFAULT rather than touching this process's memory. The call needs
    // PTRACE_MODE_ATTACH on `pid`, which the tracer thread holds because it is
    // that process's tracer.
    let n = unsafe { libc::process_vm_readv(pid, &raw const local, 1, &raw const remote, 1, 0) };
    if n <= 0 { 0 } else { n as usize }
}

// ------------------------------------------------------------ wait

#[derive(Debug, Clone, Copy)]
pub enum Wait {
    /// A task changed state. `status` is the raw wait status.
    Status { pid: pid_t, status: c_int },
    /// `WNOHANG` and nothing to report.
    Nothing,
    /// No children and no tracees are left.
    NoChildren,
    /// Interrupted; the caller retries.
    Interrupted,
}

/// `waitpid(-1, ..., __WALL | flags)`: every child of this process and every
/// tracee of this thread, threads included.
pub fn wait_any(flags: c_int) -> Wait {
    let mut status: c_int = 0;
    // SAFETY: `waitpid` writes one `c_int` through the pointer; `status` is a
    // live local. -1 asks for any child, which is the contract's design: the
    // tracer thread owns every wait in the process.
    let pid = unsafe { libc::waitpid(-1, &raw mut status, libc::__WALL | flags) };
    if pid > 0 {
        return Wait::Status { pid, status };
    }
    if pid == 0 {
        return Wait::Nothing;
    }
    match io::Error::last_os_error().raw_os_error() {
        Some(libc::ECHILD) => Wait::NoChildren,
        Some(libc::EINTR) => Wait::Interrupted,
        _ => Wait::NoChildren,
    }
}

/// This thread's kernel task id. `TracerPid` in `/proc/<pid>/status` names
/// the tracer *thread*, so confirming a seize needs this and not `getpid`.
/// This process's id, for the `/proc` walks that need it.
pub fn getpid() -> pid_t {
    // SAFETY: `getpid` takes no arguments and cannot fail.
    unsafe { libc::getpid() }
}

pub fn gettid() -> pid_t {
    // SAFETY: `gettid` takes no arguments and cannot fail.
    unsafe { libc::gettid() }
}

/// Suppress an exec at entry, or inject its EPERM result at exit.
#[cfg(target_arch = "x86_64")]
pub fn deny_exec(pid: pid_t, entry: bool) -> io::Result<()> {
    let mut regs: libc::user_regs_struct = unsafe { std::mem::zeroed() };
    ptrace_raw(
        PTRACE_GETREGS,
        pid,
        std::ptr::null_mut(),
        (&raw mut regs).cast(),
    )?;
    if entry {
        regs.orig_rax = u64::MAX;
    } else {
        regs.rax = (-i64::from(libc::EPERM)) as u64;
    }
    ptrace_raw(
        libc::PTRACE_SETREGS,
        pid,
        std::ptr::null_mut(),
        (&raw mut regs).cast(),
    )?;
    Ok(())
}
/// Skip the syscall through NT_ARM_SYSTEM_CALL, not x8: the kernel has
/// already copied x8 into pt_regs.syscallno before the seccomp stop. At the
/// exit stop replace x0 with EPERM, preserving all other registers.
#[cfg(target_arch = "aarch64")]
pub fn deny_exec(pid: pid_t, entry: bool) -> io::Result<()> {
    if entry {
        let mut syscallno: i32 = -1;
        arm64_regset(pid, libc::PTRACE_SETREGSET, 0x404, &mut syscallno)
    } else {
        let mut regs = Arm64Regs::default();
        arm64_regset(pid, libc::PTRACE_GETREGSET, 1, &mut regs)?;
        regs.x[0] = (-i64::from(libc::EPERM)) as u64;
        arm64_regset(pid, libc::PTRACE_SETREGSET, 1, &mut regs)
    }
}

#[cfg(not(any(target_arch = "x86_64", target_arch = "aarch64")))]
pub fn deny_exec(_pid: pid_t, _entry: bool) -> io::Result<()> {
    Err(io::Error::from_raw_os_error(libc::ENOSYS))
}

/// Bounded argv snapshot: at most 256 args, 64 KiB total, 4096 bytes per arg.
pub fn argv(pid: pid_t, address: u64) -> Option<Vec<Vec<u8>>> {
    if address == 0 {
        return None;
    }
    let mut result = Vec::new();
    let mut total = 0;
    for i in 0..=256u64 {
        let mut ptr = [0; 8];
        if read_remote(pid, address.checked_add(i * 8)?, &mut ptr) != 8 {
            return None;
        }
        let mut at = u64::from_ne_bytes(ptr);
        if at == 0 {
            return Some(result);
        }
        if i == 256 {
            return None;
        }
        let mut arg = Vec::new();
        loop {
            let mut bytes = [0; 256];
            let n = read_remote(pid, at, &mut bytes);
            if n == 0 {
                return None;
            }
            let end = bytes[..n].iter().position(|b| *b == 0);
            arg.extend_from_slice(&bytes[..end.unwrap_or(n)]);
            if arg.len() > 4096 || total + arg.len() > 65536 {
                return None;
            }
            if end.is_some() {
                break;
            }
            at = at.checked_add(n as u64)?;
        }
        total += arg.len();
        result.push(arg);
    }
    None
}

#[cfg(test)]
mod tests {
    use super::*;

    /// The ABI constants spelled out above must be the ones `libc` knows.
    #[test]
    #[cfg(target_arch = "aarch64")]
    fn arm64_signal_frame_and_register_layout_match_libc() {
        let mcontext = std::mem::offset_of!(libc::ucontext_t, uc_mcontext) as u64;
        assert_eq!(
            FRAME_RESULT,
            mcontext + std::mem::offset_of!(libc::mcontext_t, regs) as u64
        );
        assert_eq!(
            FRAME_IP,
            mcontext + std::mem::offset_of!(libc::mcontext_t, pc) as u64
        );
        assert_eq!(std::mem::size_of::<Arm64Regs>(), 34 * 8);
        assert_eq!(std::mem::offset_of!(Arm64Regs, sp), 31 * 8);
        assert_eq!(std::mem::offset_of!(Arm64Regs, pc), 32 * 8);
        assert_eq!(std::mem::size_of::<libc::siginfo_t>(), 128);
    }

    /// `PTRACE_GET_SYSCALL_INFO` is deliberately absent: it is not in every
    /// `libc` release, which is why this module defines it.
    #[test]
    fn ptrace_constants_match_libc() {
        assert_eq!(u64::from(PTRACE_CONT), libc::PTRACE_CONT as u64);
        assert_eq!(u64::from(PTRACE_SINGLESTEP), libc::PTRACE_SINGLESTEP as u64);
        #[cfg(target_arch = "x86_64")]
        assert_eq!(u64::from(PTRACE_GETREGS), libc::PTRACE_GETREGS as u64);
        assert_eq!(u64::from(PTRACE_GETSIGINFO), libc::PTRACE_GETSIGINFO as u64);
        assert_eq!(u64::from(PTRACE_DETACH), libc::PTRACE_DETACH as u64);
        assert_eq!(u64::from(PTRACE_SYSCALL), libc::PTRACE_SYSCALL as u64);
        assert_eq!(
            u64::from(PTRACE_GETEVENTMSG),
            libc::PTRACE_GETEVENTMSG as u64
        );
        assert_eq!(u64::from(PTRACE_SEIZE), libc::PTRACE_SEIZE as u64);
        assert_eq!(u64::from(PTRACE_LISTEN), libc::PTRACE_LISTEN as u64);
        assert_eq!(PTRACE_O_TRACESYSGOOD, libc::PTRACE_O_TRACESYSGOOD as u64);
        assert_eq!(PTRACE_O_TRACEFORK, libc::PTRACE_O_TRACEFORK as u64);
        assert_eq!(PTRACE_O_TRACEVFORK, libc::PTRACE_O_TRACEVFORK as u64);
        assert_eq!(PTRACE_O_TRACECLONE, libc::PTRACE_O_TRACECLONE as u64);
        assert_eq!(PTRACE_O_TRACEEXEC, libc::PTRACE_O_TRACEEXEC as u64);
        assert_eq!(PTRACE_O_TRACEEXIT, libc::PTRACE_O_TRACEEXIT as u64);
        assert_eq!(PTRACE_O_TRACESECCOMP, libc::PTRACE_O_TRACESECCOMP as u64);
        assert_eq!(PTRACE_O_EXITKILL, libc::PTRACE_O_EXITKILL as u64);
        assert_eq!(
            i64::from(PTRACE_EVENT_FORK),
            i64::from(libc::PTRACE_EVENT_FORK)
        );
        assert_eq!(
            i64::from(PTRACE_EVENT_VFORK),
            i64::from(libc::PTRACE_EVENT_VFORK)
        );
        assert_eq!(
            i64::from(PTRACE_EVENT_CLONE),
            i64::from(libc::PTRACE_EVENT_CLONE)
        );
        assert_eq!(
            i64::from(PTRACE_EVENT_EXEC),
            i64::from(libc::PTRACE_EVENT_EXEC)
        );
        assert_eq!(
            i64::from(PTRACE_EVENT_VFORK_DONE),
            i64::from(libc::PTRACE_EVENT_VFORK_DONE)
        );
        assert_eq!(
            i64::from(PTRACE_EVENT_EXIT),
            i64::from(libc::PTRACE_EVENT_EXIT)
        );
        assert_eq!(
            i64::from(PTRACE_EVENT_SECCOMP),
            i64::from(libc::PTRACE_EVENT_SECCOMP)
        );
    }

    #[test]
    fn seccomp_and_errno_constants_match_libc() {
        assert_eq!(
            SECCOMP_SET_MODE_FILTER,
            i64::from(libc::SECCOMP_SET_MODE_FILTER)
        );
        assert_eq!(SECCOMP_RET_ALLOW, libc::SECCOMP_RET_ALLOW);
        assert_eq!(SECCOMP_RET_TRACE, libc::SECCOMP_RET_TRACE);
        assert_eq!(SECCOMP_RET_DATA, libc::SECCOMP_RET_DATA);
        assert_eq!(
            super::super::filter::SECCOMP_FILTER_FLAG_NEW_LISTENER,
            u32::try_from(libc::SECCOMP_FILTER_FLAG_NEW_LISTENER).unwrap()
        );
        assert_eq!(
            i64::from(super::super::filter::LISTENER_SYSCALL.1),
            libc::SYS_seccomp
        );
        assert_eq!(
            u32::from(BPF_JSET_K),
            libc::BPF_JMP | libc::BPF_JSET | libc::BPF_K
        );
        // `args[1]` starts 16 + 8 bytes into `struct seccomp_data`.
        assert_eq!(
            SECCOMP_DATA_ARG1_LOW as usize,
            std::mem::offset_of!(libc::seccomp_data, args) + 8
        );
    }

    /// The signal-frame offsets are glibc's view of the same kernel layout:
    /// `uc_mcontext` inside `ucontext_t`, and `REG_RAX`/`REG_RIP` in its
    /// `gregs`.
    #[cfg(target_arch = "x86_64")]
    #[test]
    fn the_signal_frame_offsets_match_the_ucontext_layout() {
        let mcontext = std::mem::offset_of!(libc::ucontext_t, uc_mcontext) as u64;
        let gregs = std::mem::offset_of!(libc::mcontext_t, gregs) as u64;
        assert_eq!(FRAME_RESULT, mcontext + gregs + 8 * libc::REG_RAX as u64);
        assert_eq!(FRAME_IP, mcontext + gregs + 8 * libc::REG_RIP as u64);
        assert_eq!(TRAP_BRKPT, libc::TRAP_BRKPT);
        assert_eq!(TRAP_TRACE, libc::TRAP_TRACE);
    }

    #[test]
    fn restart_codes_are_exactly_the_four_kernel_values() {
        assert!(is_restart(-512), "-ERESTARTSYS");
        assert!(is_restart(-513), "-ERESTARTNOINTR");
        assert!(is_restart(-514), "-ERESTARTNOHAND");
        assert!(is_restart(-516), "-ERESTART_RESTARTBLOCK");
        assert!(!is_restart(-515), "515 is not a restart code");
        assert!(!is_restart(-517), "beyond the restart range");
        assert!(!is_restart(-1), "-EPERM is an ordinary result");
        assert!(!is_restart(0), "success is not a restart");
        assert!(!is_restart(512), "a positive 512 is a byte count");
    }

    /// The unsafe boundary of `read_remote`: a pid that does not exist, a
    /// null address and an empty buffer must all come back as "no bytes",
    /// never as a fabricated read or a crash.
    #[test]
    fn read_remote_refuses_impossible_inputs() {
        let mut buf = [0xabu8; 64];
        assert_eq!(read_remote(0, 0, &mut buf), 0, "null address");
        assert_eq!(read_remote(-1, 0x1000, &mut buf), 0, "negative pid");
        assert_eq!(
            read_remote(std::process::id() as pid_t, 0x1, &mut buf),
            0,
            "unmapped page"
        );
        assert_eq!(
            read_remote(std::process::id() as pid_t, 0x1000, &mut []),
            0,
            "empty buffer"
        );
        assert_eq!(buf, [0xabu8; 64], "no failing read may touch the buffer");
    }

    /// Reading this process's own memory is the positive control for the
    /// same unsafe boundary.
    #[test]
    fn read_remote_reads_this_process() {
        let source = b"/tmp/observer-precondition\0";
        let mut buf = [0u8; 32];
        let n = read_remote(
            std::process::id() as pid_t,
            source.as_ptr() as u64,
            &mut buf[..source.len()],
        );
        assert_eq!(n, source.len());
        assert_eq!(&buf[..source.len()], source);
    }

    /// The unsafe boundary of the ptrace helpers: a pid we do not trace must
    /// fail with ESRCH and must not be reported as a decoded stop.
    #[test]
    fn ptrace_helpers_refuse_a_process_we_do_not_trace() {
        let me = std::process::id() as pid_t;
        let err = syscall_info(me).expect_err("we are not stopped and not our own tracee");
        assert_eq!(err.raw_os_error(), Some(libc::ESRCH), "{err}");
        let err = siginfo(me).expect_err("not a tracee");
        assert_eq!(err.raw_os_error(), Some(libc::ESRCH), "{err}");
        let err = handler_ucontext(me, 1, 0, 4).expect_err("not a tracee");
        assert!(
            matches!(err.raw_os_error(), Some(libc::ESRCH | libc::ENOSYS)),
            "{err}"
        );
        let err = event_msg(me).expect_err("not a tracee");
        assert_eq!(err.raw_os_error(), Some(libc::ESRCH), "{err}");
    }

    /// The wake signal must be one nothing else in the process uses, and its
    /// handler must interrupt a blocking call rather than let the kernel
    /// restart it — that is the whole point of installing it without
    /// `SA_RESTART`.
    ///
    /// The blocking call here is `nanosleep` and not `waitpid`: a test that
    /// waits on any child would reap the children of other tests in this
    /// binary, which is exactly the hazard the tracer thread exists to take
    /// on deliberately.
    #[test]
    fn the_wake_signal_interrupts_a_blocking_call_instead_of_killing_us() {
        assert!(
            wake_signal() > libc::SIGRTMIN(),
            "the first real-time signals belong to the threading implementation"
        );
        assert!(wake_signal() <= libc::SIGRTMAX());
        install_wake_handler().expect("install the handler");
        let tid = gettid();
        let waker = std::thread::spawn(move || {
            std::thread::sleep(std::time::Duration::from_millis(50));
            tgkill(tid, wake_signal()).expect("wake");
        });
        let request = libc::timespec {
            tv_sec: 30,
            tv_nsec: 0,
        };
        let mut remaining = libc::timespec {
            tv_sec: 0,
            tv_nsec: 0,
        };
        let started = std::time::Instant::now();
        // SAFETY: two live `timespec` locals; `nanosleep` writes only the
        // second one.
        let rc = unsafe { libc::nanosleep(&raw const request, &raw mut remaining) };
        let elapsed = started.elapsed();
        let errno = io::Error::last_os_error().raw_os_error();
        waker.join().expect("the waking thread");
        assert_eq!(rc, -1, "the sleep must not have completed");
        assert_eq!(
            errno,
            Some(libc::EINTR),
            "the handler ran and did not restart it"
        );
        assert!(
            elapsed < std::time::Duration::from_secs(5),
            "the signal must interrupt the call, not wait it out: {elapsed:?}"
        );
    }

    #[test]
    fn gettid_is_a_task_of_this_process() {
        let tid = gettid();
        assert!(tid > 0);
        assert!(
            std::path::Path::new(&format!("/proc/self/task/{tid}")).exists(),
            "gettid must name a task of this thread group"
        );
    }
}
