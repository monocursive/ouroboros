//! Optional argv accident filters. These do not constrain program effects.
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};

#[derive(Clone, Debug, Default, PartialEq, Eq, Deserialize, Serialize)]
#[serde(deny_unknown_fields)]
pub struct Rules {
    #[serde(default)]
    pub deny: Vec<String>,
    #[serde(default)]
    pub forbid: Vec<String>,
}
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Hit {
    pub pattern: String,
    pub digest: String,
    pub forbidden: bool,
}
impl Rules {
    pub fn is_empty(&self) -> bool {
        self.deny.is_empty() && self.forbid.is_empty()
    }
    pub fn validate(&self) -> Result<(), String> {
        if self.deny.len() + self.forbid.len() > 64 {
            return Err("at most 64 command rules are supported".into());
        }
        for pattern in self.deny.iter().chain(&self.forbid) {
            if pattern.len() > 4096 {
                return Err("command pattern exceeds 4096 bytes".into());
            }
            let parts = tokens(pattern)?;
            if parts.is_empty()
                || parts.first().is_some_and(|p| p == b"**")
                || parts.iter().take(parts.len() - 1).any(|p| p == b"**")
            {
                return Err(
                    "command rules need argv[0]; ** is only allowed as the final token".into(),
                );
            }
        }
        Ok(())
    }
    pub fn check(&self, argv: Option<&[Vec<u8>]>, path: Option<&[u8]>) -> Option<Hit> {
        if self.is_empty() {
            return None;
        }
        let Some(argv) = argv else {
            return Some(Hit {
                pattern: "<unreadable-or-oversized-argv>".into(),
                digest: "unavailable".into(),
                forbidden: false,
            });
        };
        let mut hash = Sha256::new();
        for arg in argv {
            hash.update((arg.len() as u64).to_le_bytes());
            hash.update(arg);
        }
        let digest = format!("sha256:{:x}", hash.finalize());
        for (patterns, forbidden) in [(&self.forbid, true), (&self.deny, false)] {
            for pattern in patterns {
                if tokens(pattern).is_ok_and(|parts| matches(&parts, argv, path)) {
                    return Some(Hit {
                        pattern: pattern.clone(),
                        digest,
                        forbidden,
                    });
                }
            }
        }
        None
    }
}
// Small quote tokenizer, with no expansions or shell syntax evaluation.
fn tokens(text: &str) -> Result<Vec<Vec<u8>>, String> {
    let mut result = Vec::new();
    let mut part = Vec::new();
    let mut quote = None;
    let mut escape = false;
    let mut active = false;
    for b in text.bytes() {
        if escape {
            part.push(b);
            escape = false;
            active = true;
            continue;
        }
        if b == b'\\' && quote != Some(b'\'') {
            escape = true;
            active = true;
            continue;
        }
        if quote == Some(b) {
            quote = None;
            continue;
        }
        if quote.is_none() && (b == b'\'' || b == b'"') {
            quote = Some(b);
            active = true;
            continue;
        }
        if quote.is_none() && b.is_ascii_whitespace() {
            if active {
                result.push(std::mem::take(&mut part));
                active = false;
            }
        } else {
            if b == 0 {
                return Err("NUL in command rule".into());
            }
            part.push(b);
            active = true;
        }
    }
    if escape || quote.is_some() {
        return Err("unfinished quote or escape in command rule".into());
    }
    if active {
        result.push(part);
    }
    Ok(result)
}
fn glob(pattern: &[u8], value: &[u8]) -> bool {
    let (mut p, mut v, mut star, mut retry) = (0, 0, None, 0);
    while v < value.len() {
        if p < pattern.len() && (pattern[p] == b'?' || pattern[p] == value[v]) {
            p += 1;
            v += 1;
        } else if p < pattern.len() && pattern[p] == b'*' {
            star = Some(p);
            p += 1;
            retry = v;
        } else if let Some(s) = star {
            retry += 1;
            v = retry;
            p = s + 1;
        } else {
            return false;
        }
    }
    while p < pattern.len() && pattern[p] == b'*' {
        p += 1;
    }
    p == pattern.len()
}
fn matches(parts: &[Vec<u8>], argv: &[Vec<u8>], path: Option<&[u8]>) -> bool {
    if parts.is_empty() {
        return false;
    }
    // An `execve` with argc 0 carries no argv[0] to match or to spoof:
    // element 0 then matches the exec path alone, the identity the
    // first-position fallback already trusts.
    let synthesized;
    let argv: &[Vec<u8>] = if !argv.is_empty() {
        argv
    } else {
        match path {
            Some(path) => {
                synthesized = vec![path.to_vec()];
                &synthesized
            }
            None => return false,
        }
    };
    let rest = parts.last().is_some_and(|p| p == b"**");
    let count = parts.len() - usize::from(rest);
    if argv.len() < count || (!rest && argv.len() != count) {
        return false;
    }
    parts.iter().take(count).enumerate().all(|(i, p)| {
        glob(p, &argv[i])
            || (i == 0
                && (glob(p, argv[0].rsplit(|b| *b == b'/').next().unwrap_or_default())
                    || path.is_some_and(|path| {
                        glob(p, path)
                            || glob(p, path.rsplit(|b| *b == b'/').next().unwrap_or_default())
                    })))
    })
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn positional_and_tail() {
        let rules = Rules {
            deny: vec!["git push --force".into(), "rm -rf /*".into()],
            forbid: vec!["dangerous-tool **".into()],
        };
        rules.validate().unwrap();
        let args = |s: &str| {
            s.split(' ')
                .map(|s| s.as_bytes().to_vec())
                .collect::<Vec<_>>()
        };
        assert!(
            rules
                .check(Some(&args("/usr/bin/git push --force")), None)
                .is_some()
        );
        assert!(
            rules
                .check(Some(&args("git push --force main")), None)
                .is_none()
        );
        assert!(
            rules
                .check(Some(&args("fake anything")), Some(b"/bin/dangerous-tool"))
                .unwrap()
                .forbidden
        );
        assert!(rules.check(Some(&args("sh -c rm")), None).is_none());
        assert!(rules.check(None, None).is_some());
        assert_eq!(
            tokens("cmd 'two words' \"\" **").unwrap(),
            vec![
                b"cmd".to_vec(),
                b"two words".to_vec(),
                vec![],
                b"**".to_vec()
            ]
        );
    }

    #[test]
    fn a_rule_with_no_argv0_refuses_instead_of_matching_everything() {
        assert!(
            Rules {
                deny: vec!["**".into()],
                forbid: Vec::new(),
            }
            .validate()
            .is_err(),
            "a lone ** has no argv[0] and must not validate"
        );
    }

    /// jail-v2 K22: the documented bound is enforced, not silently ignored.
    #[test]
    fn more_than_the_documented_rule_cap_refuses_at_validation() {
        let rules = |count: usize| Rules {
            deny: (0..count).map(|i| format!("tool-{i}")).collect(),
            forbid: Vec::new(),
        };
        rules(64)
            .validate()
            .expect("64 rules are the documented cap");
        let error = rules(65).validate().expect_err("65 rules refuse");
        assert!(error.contains("at most 64 command rules"), "{error}");
    }

    /// A command matching both a deny and a forbid rule yields the forbid:
    /// the forbid list is evaluated first, so forbid wins.
    #[test]
    fn forbid_wins_when_a_command_matches_both_a_deny_and_a_forbid() {
        let rules = Rules {
            deny: vec!["git **".into()],
            forbid: vec!["git push --force **".into()],
        };
        rules.validate().unwrap();
        let args: Vec<Vec<u8>> = "git push --force upstream"
            .split(' ')
            .map(|s| s.as_bytes().to_vec())
            .collect();
        let hit = rules
            .check(Some(&args), None)
            .expect("a doubly matched command still hits");
        assert!(hit.forbidden, "forbid wins over deny: {hit:?}");
        assert_eq!(hit.pattern, "git push --force **");
        // The same argv under deny alone is an ordinary (non-forbidden) hit.
        let deny_only = Rules {
            deny: vec!["git **".into()],
            forbid: Vec::new(),
        };
        deny_only.validate().unwrap();
        let hit = deny_only.check(Some(&args), None).expect("deny hits");
        assert!(!hit.forbidden);
    }

    #[test]
    fn an_exec_with_no_argv_matches_the_exec_path_alone() {
        let rules = Rules {
            deny: Vec::new(),
            forbid: vec!["dangerous-tool **".into()],
        };
        rules.validate().unwrap();
        let hit = rules
            .check(Some(&[]), Some(b"/usr/bin/dangerous-tool"))
            .expect("argc 0 still matches through the exec path");
        assert!(hit.forbidden);
        assert!(
            rules
                .check(Some(&[]), Some(b"/usr/bin/other-tool"))
                .is_none()
        );
        assert!(rules.check(Some(&[]), None).is_none());
    }
}
