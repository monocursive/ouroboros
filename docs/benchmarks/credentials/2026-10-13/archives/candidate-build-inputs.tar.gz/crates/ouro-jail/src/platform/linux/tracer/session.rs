//! The tracer thread: one `waitpid(-1, __WALL)` loop that owns every child
//! and every tracee of the process, and the §11 bookkeeping that turns its
//! stops into the events of [`super::TracerEvent`]. It ends on its own
//! account of what it answers for ([`Owed`]), not when no child is left.
//!
//! Everything the spec calls a semantic lives here as code:
//!
//! * `Exit` is emitted once, when the last thread of a thread group that was
//!   seen to exec is reaped, and only if that thread is the group leader.
//!   A worker exit is a decrement; a leader that calls `pthread_exit` while
//!   workers live is a zombie the kernel will not report until the group is
//!   empty; a fork child that never execs is tracked and reaped but emits no
//!   `Exit` (§11.2).
//! * `Exec` is emitted only on `PTRACE_EVENT_EXEC`, the confirmed kernel
//!   transition, and carries the pathname snapshot of the entry it was paired
//!   with. A failed `execve` never reaches that event and comes out as
//!   `Syscall { op: Exec, ret: -errno }`. A non-leader exec is followed: the
//!   thread's id becomes the leader's, the in-flight entry moves with it, and
//!   the process keeps the identity it was born with. Whatever the leader
//!   itself had in flight can no longer return: it is abandoned, a gap of its
//!   own classes, and never paired with the exec's syscall exit (J4 W3).
//! * Entry and exit are paired per thread. An exit with no entry is a gap. A
//!   kernel restart code at the exit (`ERESTARTSYS` and its family) is not a
//!   result yet: the kernel decides afterwards whether to re-enter the call
//!   or to return `EINTR` (J4 O-2), and the call stays in flight until the
//!   observer has seen that decision — see [`RestartWait`]. A re-entry
//!   produces the one result; an `EINTR` is the result; emitting the code
//!   itself would be the duplicate §11.2 forbids, and dropping it would be
//!   the silence §11.4 forbids. A restart read from a handler's frame, which
//!   the program can rewrite, is believed only when the re-entry is seen
//!   (J4 W3, R1).
//! * A read-only open never becomes an event, never takes an in-flight slot
//!   and so is never refused one (J4 O-1), and never even costs a second
//!   stop: the tracee is continued from the seccomp stop instead of being
//!   stepped to the syscall exit.
//! * A tracee killed at its seccomp entry stop before the observer resumed
//!   it made no call: the kernel skips a call whose thread has a fatal signal
//!   pending after the trace event (`__seccomp_filter`), so it is neither a
//!   result nor a loss (J4 O-3). A call the observer had already let run
//!   when the kill came may have had its effect and stays a gap.
//! * Nothing observed is ever replaced by a guess. Unreadable argument
//!   memory, an undecodable `open_how`, an untracked task and a final status
//!   that cannot be attributed each become a `Gap` with its own reason, its
//!   own counter and the set of operations it affected.
//!
//! Three properties of the outbox are worth stating separately, because they
//! are what a consumer's loss looks like:
//!
//! * Results are droppable, lifecycle facts are not. A consumer that stops
//!   reading loses `Syscall` events after a bounded stall; the lifecycle
//!   facts queue in the tracer's own buffer and are delivered when the
//!   consumer returns. The §11.4 byte budget and a count bound them too — an
//!   `Exec` carries a child-chosen pathname, so it is dropped with a gap when
//!   either is full — but the critical facts, `Exit`, `UntracedChildExit`,
//!   `Gap` and `Finished`, are exempt from every cap (J4 D6). The first
//!   three are fixed-size and bounded by the tasks that exist; a `Gap` past a
//!   cap is merged into the one summary per reason that is delivered ahead of
//!   the next fact, so its reason, classes, count and interval survive while
//!   the backlog stays bounded. A supervisor never loses the exit status it
//!   exists to report, nor the record of what it could not see.
//! * The buffer is bounded in bytes, not in events, because §11.4 budgets
//!   bytes and two four-kilobyte pathnames per event make a count meaningless.
//!   The budget covers what was handed to the channel and not yet taken as
//!   well ([`super::Events`] gives the bytes back), so the figure the
//!   observer plan records is the bound in force (J4 W3).
//! * Nothing is ever delivered with a bare `try_send`. Every send has a
//!   deadline, and what misses it is counted.

use std::collections::{HashMap, HashSet, VecDeque};
use std::sync::Arc;
use std::sync::OnceLock;
use std::sync::atomic::{AtomicBool, AtomicI32, AtomicU64, AtomicUsize, Ordering};
use std::sync::mpsc::{Sender, SyncSender, TrySendError};
use std::time::{Duration, Instant};

use libc::pid_t;

use super::closed_set::{self, ClosedOp, Entry, FlagSource};
use super::proc;
use super::sys::{self, Wait};
use super::{
    Args, GapReason, OpSet, PathSnapshot, SockaddrSnapshot, TracerConfig, TracerError, TracerEvent,
    TracerSummary, clock, event_bytes,
};

/// How long a tracee may be held at a stop by a consumer that is not reading.
/// After this the result is dropped and counted; the tree keeps moving.
const QUEUE_BLOCK: Duration = Duration::from_secs(1);

/// How often a full outbox is retried inside that second.
const QUEUE_POLL: Duration = Duration::from_micros(200);

/// How long the tracer keeps trying to hand over the terminal gap and
/// `Finished` after the tree is dead. Nothing is stopped behind them, so this
/// is generous; `finish` ends it immediately by setting the stop flag.
const TERMINAL_DRAIN: Duration = Duration::from_secs(30);

const TERMINAL_POLL: Duration = Duration::from_millis(5);

/// Most lifecycle events the tracer will hold for a consumer that is not
/// reading. They are tiny and bounded by the number of tasks; past this the
/// backlog itself is the problem and is reported as one. The critical facts
/// are exempt ([`Session::is_critical`]): a gap past it is coalesced, an
/// exit is admitted.
const LIFECYCLE_MAX: usize = 16_384;

/// How long a killed tree is given to be reaped before the remaining tracees
/// are recorded as abandoned.
const KILL_GRACE: Duration = Duration::from_secs(2);

/// How long to wait for `/proc/<pid>/status` to show this thread as the
/// tracer after a successful `PTRACE_SEIZE`.
const SEIZE_CONFIRM: Duration = Duration::from_millis(500);

/// What the supervisor shares with the tracer thread.
pub(super) struct Handles {
    pub stop: Arc<AtomicBool>,
    pub shutdown_ns: Arc<AtomicU64>,
    pub tid: Arc<AtomicI32>,
    /// Bytes handed to the channel and not yet taken by the consumer.
    pub handed: Arc<AtomicUsize>,
}

/// The two `/proc` reads that name a task: its thread group and its birth.
///
/// A seam, so a unit test can play what the kernel will not hand an
/// unprivileged test on the reference host: a tid recycled for a new task
/// (J4 S1). The live implementation is [`LiveProc`].
pub(super) trait ProcView: Send {
    /// The thread group `tid` belongs to, in this process's pid namespace.
    fn tgid(&self, tid: pid_t) -> Option<pid_t>;
    /// Field 22 of `/proc/<tid>/stat`: the task's start time in clock ticks
    /// since boot.
    fn start_ticks(&self, tid: pid_t) -> Option<u64>;
    /// The direct children of every thread of `pid` (J5-T).
    fn children(&self, pid: pid_t) -> Vec<pid_t> {
        proc::children(pid)
    }
    /// The raw `/proc/<tid>/cmdline` bytes (audit 6 N2).
    fn cmdline(&self, tid: pid_t) -> Option<Vec<u8>> {
        proc::cmdline_bytes(tid)
    }
    /// The raw `/proc/<tid>/exe` link bytes (audit 6 N2).
    fn exe(&self, tid: pid_t) -> Option<Vec<u8>> {
        use std::os::unix::ffi::OsStrExt as _;
        std::fs::read_link(format!("/proc/{tid}/exe"))
            .ok()
            .map(|link| link.as_os_str().as_bytes().to_vec())
    }
    /// The raw `/proc/<tid>/fd/<fd>` link bytes (audit 6 N1).
    fn fd_link(&self, tid: pid_t, fd: i64) -> Option<Vec<u8>> {
        use std::os::unix::ffi::OsStringExt as _;
        std::fs::read_link(format!("/proc/{tid}/fd/{fd}"))
            .ok()
            .map(|link| link.into_os_string().into_vec())
    }
    /// The link count of the file `/proc/<tid>/fd/<fd>` resolves to (audit 7
    /// L7): 0 once the file is unlinked. `None` when it cannot be read.
    fn fd_nlink(&self, tid: pid_t, fd: i64) -> Option<u64> {
        use std::os::unix::fs::MetadataExt as _;
        std::fs::metadata(format!("/proc/{tid}/fd/{fd}"))
            .ok()
            .map(|meta| meta.nlink())
    }
}

/// `/proc`, read now.
pub(super) struct LiveProc;

impl ProcView for LiveProc {
    fn tgid(&self, tid: pid_t) -> Option<pid_t> {
        proc::tgid(tid)
    }

    fn start_ticks(&self, tid: pid_t) -> Option<u64> {
        proc::start_ticks(tid)
    }
}

/// J5-T: the children of this process, besides its tracees, whose end the
/// tracer answers for.
///
/// It ends on this account, never on `waitpid(-1)` returning `ECHILD`. A
/// process can start with children it never made — a shell's process
/// substitution forked before it `exec`ed the supervisor, a background job,
/// a library's helper — and those are no part of the attempt: waiting for
/// them held the tracer open until its deadline and then reported them as
/// unreaped. While the tracer runs it still reaps any of them that exits
/// (`waitpid(-1)` cannot leave them out) and delivers the status as
/// [`TracerEvent::UntracedChildExit`], so nothing is lost; one alive when it
/// finishes is left to its owner. A child it gains after attaching is the
/// opposite case — an orphan of the traced tree adopted by a subreaper
/// supervisor — and is owed like the backend (`Session::adopted`).
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum Owed {
    /// Nothing: the launcher is itself a child of this process.
    Nothing,
    /// The child the launcher descends through — bubblewrap — with its
    /// birth, until its exit has been reaped and delivered.
    Backend {
        pid: pid_t,
        birth: Option<u64>,
        reaped: bool,
    },
    /// The launcher's ancestry could not be read, so which child is the
    /// backend is unknown: every child is waited for, as before J5-T.
    Every,
}

impl Owed {
    /// Read from the kernel's parent links while the launcher is seized and
    /// blocked, so the chain above it cannot change under the walk.
    fn toward(launcher: pid_t, procfs: &dyn ProcView) -> Owed {
        match proc::child_toward(sys::getpid(), launcher) {
            Some(child) if child == launcher => Owed::Nothing,
            Some(child) => Owed::Backend {
                pid: child,
                birth: procfs.start_ticks(child),
                reaped: false,
            },
            None => Owed::Every,
        }
    }
}

/// A traced thread.
struct Task {
    tgid: pid_t,
    start_ticks: Option<u64>,
    pending: Option<InFlight>,
    /// Where `pending` entered the kernel.
    site: Site,
    /// `pending` was taken at the stop not yet resumed: a resume that fails
    /// with `ESRCH` means the kernel will skip it (J4 O-3).
    entry_fresh: bool,
    /// A call whose exit carried a restart code, waiting for the kernel's
    /// decision. While it is set the thread is single-stepped.
    restart: Option<RestartWait>,
}

/// Where a call entered the kernel: its ABI, its number and the user
/// instruction pointer just past the instruction that made it. A kernel
/// restart re-executes that instruction with the same number, so a re-entry
/// stops here again (J4 O-2).
#[derive(Debug, Default, Clone, Copy, PartialEq, Eq)]
struct Site {
    arch: u32,
    nr: u64,
    ip: u64,
    /// arm64 restores the original x0 argument before restarting; x86_64
    /// restores the syscall number in rax. Keep the entry value to verify it.
    arg0: u64,
}

/// A call whose syscall exit carried a kernel restart code (J4 O-2).
///
/// The code is not the call's result. When the thread next heads for user
/// space the kernel delivers any pending signal and then either re-enters
/// the call or returns `EINTR` (the table on [`sys::ERESTARTSYS`]). The
/// observer steps the thread (`PTRACE_SINGLESTEP`), which makes every way
/// out a stop:
///
/// * the entry stop of the re-entered call, at the same [`Site`], before any
///   user instruction has run: restarted;
/// * the notification the kernel gives a single-stepped tracee at a signal
///   handler's entry, after it has settled the call and written the frame:
///   `EINTR` or restarted, from the restart code and, for `ERESTARTSYS`
///   (whose outcome depends on `SA_RESTART`, which a tracer cannot read),
///   from the `rax` and `rip` the kernel saved in that frame;
/// * a death, or the thread's destruction by another's `execve`: the call
///   did nothing and nothing was returned — neither a result nor a loss;
/// * anything else — a step trap in user space (the continuation ran through
///   `restart_syscall`, which is not traced), an unreadable or unrecognised
///   frame, a stop out of this sequence: [`GapReason::RestartUnresolved`].
///
/// "Restarted" at a handler's entry is not yet the end (J4 W3, tracer review
/// R1). The re-entry comes only after the handler returns, through
/// `rt_sigreturn`, which restores the frame — and the frame is the
/// program's memory: the handler, or a sibling thread before the observer
/// reads it, can rewrite it, so the program sees `EINTR` from a call the
/// observer read as restarted. The thread is then let run
/// ([`Awaiting::Reentry`]) and the wait is settled by what follows:
///
/// * its next entry stop at the same [`Site`]: the re-entry, restarted;
/// * its next entry stop anywhere else: [`GapReason::RestartUnresolved`] —
///   a call inside the handler cannot be told from one after a rewritten
///   frame, so a covered call made by an `SA_RESTART` handler costs a gap;
/// * its end first: nothing when the kernel decided the restart whatever the
///   frame (`ERESTARTNOINTR`, so there is no `EINTR` it could have hidden),
///   [`GapReason::RestartUnresolved`] when the frame decided it.
///
/// The call keeps its in-flight slot until then.
struct RestartWait {
    call: InFlight,
    /// The positive restart code.
    code: i64,
    site: Site,
    /// The last signal delivered to the thread since the exit, if any. The
    /// kernel notifies a handler's entry only after a signal was delivered.
    delivered: Option<libc::c_int>,
    awaiting: Awaiting,
}

/// What a [`RestartWait`] is waiting for.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum Awaiting {
    /// The kernel's decision. The thread is single-stepped.
    Decision,
    /// The re-entry a handler's entry announced. The thread runs freely.
    Reentry {
        /// The restart code alone decided it (`ERESTARTNOINTR`), not the
        /// frame the program can rewrite.
        by_kernel: bool,
    },
}

/// What an entry stop of a thread owing a restart decision showed.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum EntryStop {
    /// Stopped at the entry of the call made at this site.
    At(Site),
    /// Killed at this stop before it was resumed: the kernel skips the call,
    /// and which call it was can no longer be read.
    Killed,
    /// Not describable.
    Unreadable,
}

/// What the kernel did with a call whose exit carried a restart code.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum Verdict {
    /// Re-entered: the re-entered call produces the one result.
    Restarted,
    /// `EINTR` was returned to the program: that is the call's result.
    Interrupted,
    /// Not established: a [`GapReason::RestartUnresolved`] gap.
    Unknown,
}

/// The kernel's decision at a signal handler's entry
/// (`arch/{x86,arm64}/kernel/signal.c`). `ERESTARTNOHAND` and `ERESTART_RESTARTBLOCK`
/// become `EINTR` and `ERESTARTNOINTR` is re-entered, whatever the handler.
/// `ERESTARTSYS` is re-entered only under `SA_RESTART`, which is read from
/// what the kernel saved in the frame: the result register is `-EINTR`
/// with the PC unchanged, or the PC is rewound over the syscall instruction.
/// For a restart, x86_64 restores the syscall number in rax and rewinds two
/// bytes; arm64 restores the original x0 argument and rewinds four bytes.
/// Anything else is not a frame this call produced.
fn verdict_at_handler(code: i64, frame: Option<(u64, u64)>, site: Site) -> Verdict {
    match code {
        sys::ERESTARTNOINTR => Verdict::Restarted,
        sys::ERESTARTNOHAND | sys::ERESTART_RESTARTBLOCK => Verdict::Interrupted,
        sys::ERESTARTSYS => match frame {
            Some((ax, ip)) if ax == (-i64::from(libc::EINTR)) as u64 && ip == site.ip => {
                Verdict::Interrupted
            }
            Some((ax, ip))
                if ax
                    == if site.arch == 0xc000_00b7 {
                        site.arg0
                    } else {
                        site.nr
                    }
                    && ip
                        == site
                            .ip
                            .wrapping_sub(if site.arch == 0xc000_00b7 { 4 } else { 2 }) =>
            {
                Verdict::Restarted
            }
            _ => Verdict::Unknown,
        },
        _ => Verdict::Unknown,
    }
}

/// A call that stopped at its entry and has not yet returned.
///
/// One entry exists per in-flight syscall, so the variants' size difference
/// (the closed-set call's captured arguments) costs at most a few hundred
/// bytes per stopped task.
#[allow(clippy::large_enum_variant)]
enum InFlight {
    /// A closed-set call, with the arguments read at its entry.
    Closed(Pending),
    /// A syscall under another ABI (J4 D2): never decoded, so its return is
    /// the one thing the observer learns about it.
    Foreign,
    /// `seccomp(2)` asking for a notification listener (J4 D1): its return
    /// says whether the child now holds one.
    Listener,
    /// `clone(2)` with `CLONE_UNTRACED` (J4 S4): its return says whether a
    /// task now exists that the kernel did not attach to this tracer.
    Untraced,
}

impl InFlight {
    /// The operations a hole left by this call could have held: the row's
    /// own for a closed-set call, all of them for a call nothing decoded or
    /// a listener that could hide any of them.
    fn ops(&self) -> OpSet {
        match self {
            InFlight::Closed(pending) => OpSet::of(pending.entry.op),
            InFlight::Foreign | InFlight::Listener | InFlight::Untraced => OpSet::ALL,
        }
    }
}

/// A traced thread group.
struct Process {
    threads: HashSet<pid_t>,
    /// Set by `PTRACE_EVENT_EXEC`. §11.2 ties `proc.exit` to a witnessed
    /// exec, so a fork child that never execs emits none.
    witnessed_exec: bool,
    /// False when `/proc` would not say which thread group this task belongs
    /// to. Such a group never gets an `Exit`: the gap was already recorded.
    identity_known: bool,
    /// The process's birth: its leader's start time, read when the group was
    /// first registered (§11.3). Every event about the group carries it, so
    /// a later process given the same number is never confused with it.
    birth: Option<u64>,
}

#[derive(Clone)]
/// A closed-set call that has entered the kernel and not yet returned.
struct Pending {
    entry: &'static Entry,
    args: Args,
    /// `PTRACE_EVENT_EXEC` arrived for this entry, so the syscall exit that
    /// follows is the transition already reported and not a second result.
    exec_confirmed: bool,
    /// Arguments that could not be read. Which of these is loss and which is
    /// a tracee passing a pointer that never could have worked is decided at
    /// the syscall exit, from the kernel's own return.
    path_unreadable: bool,
    path2_unreadable: bool,
    sockaddr_unreadable: bool,
    flags_unavailable: bool,
    /// The entry-stop register arguments, kept so the exit can re-read the
    /// memory the kernel re-reads after the stop and prove the snapshot
    /// stable. Registers cannot change between the stops; only pointed
    /// memory can.
    raw: [u64; 6],
    /// The argv the command rules judged at an exec's entry stop, kept for
    /// the re-check against the kernel's own copy at the exec event
    /// ([`exec_recheck`]). `None` for every other call, and whenever no
    /// command rules are configured.
    entry_argv: Option<Vec<Vec<u8>>>,
}

pub(super) fn run(
    launcher: pid_t,
    config: TracerConfig,
    tx: SyncSender<TracerEvent>,
    ready: Sender<Result<(), TracerError>>,
    handles: Handles,
) -> TracerSummary {
    handles.tid.store(sys::gettid(), Ordering::Release);
    let epoch_boottime_ns = config.epoch_boottime_ns;
    let mut session = Session::new(
        config,
        tx,
        Arc::clone(&handles.handed),
        epoch_boottime_ns,
        Box::new(LiveProc),
    );
    match seize_and_confirm(launcher) {
        Ok(()) => {
            if ready.send(Ok(())).is_err() {
                // The caller went away between spawning and confirming.
                let _ = sys::detach(launcher);
                return session.summary;
            }
        }
        Err(err) => {
            let _ = ready.send(Err(err));
            return session.summary;
        }
    }
    // Attached is the first event, before any bookkeeping that could itself
    // produce one.
    let start_ticks = session.procfs.start_ticks(launcher);
    session.emit(TracerEvent::Attached {
        pid: launcher,
        start_ticks,
        monotonic_ns: clock::boottime_ns(),
    });
    session.register(launcher);
    session.owed = Owed::toward(launcher, &*session.procfs);
    session.beside = session
        .procfs
        .children(sys::getpid())
        .into_iter()
        .filter_map(|pid| session.procfs.start_ticks(pid).map(|birth| (pid, birth)))
        .collect();
    session.run_loop(&handles);
    session.finish(&handles)
}

/// Install the handler that lets `finish` interrupt a blocking `waitpid`.
/// Process-global and installed once; the handler does nothing at all.
fn ensure_wake_handler() -> bool {
    static INSTALLED: OnceLock<bool> = OnceLock::new();
    *INSTALLED.get_or_init(|| sys::install_wake_handler().is_ok())
}

fn seize_and_confirm(launcher: pid_t) -> Result<(), TracerError> {
    // J5-D: the one statement of which architecture the tables cover, so
    // the tracer refuses exactly where `doctor` reports it unsupported.
    if !super::super::seccomp::tables_cover(std::env::consts::ARCH) {
        return Err(TracerError::UnsupportedArch);
    }
    ensure_wake_handler();
    sys::seize(launcher, sys::SEIZE_OPTIONS).map_err(|err| TracerError::Seize {
        pid: launcher,
        errno: err.raw_os_error().unwrap_or(0),
    })?;
    // PTRACE_SEIZE does not stop the tracee, so the seize is confirmed from
    // the kernel's own view of it: `TracerPid` names the tracing *thread*,
    // which is this one.
    let me = sys::gettid();
    let deadline = Instant::now() + SEIZE_CONFIRM;
    loop {
        match proc::tracer_pid(launcher) {
            Some(tracer) if tracer == me => return Ok(()),
            Some(tracer) => {
                return Err(TracerError::SeizedByAnotherThread {
                    pid: launcher,
                    tracer,
                });
            }
            None => {
                if Instant::now() >= deadline {
                    return Err(TracerError::SeizeUnconfirmed { pid: launcher });
                }
                std::thread::sleep(Duration::from_millis(1));
            }
        }
    }
}

/// One event waiting to be handed to the consumer.
struct Queued {
    event: TracerEvent,
    bytes: usize,
    lifecycle: bool,
}

struct CoalescedGap {
    reason: GapReason,
    ops: OpSet,
    from_ns: u64,
    to_ns: u64,
    /// `None` once any merged gap had an unknown size.
    count: Option<u64>,
}

// J5-B2 O03 seams (tracer gaps) begin.
/// `OURO_JAIL_TEST_TRACER_TRUNCATE_PATH=<substring>`: every covered non-exec
/// call whose path contains `<substring>` reports "the kernel accepted the
/// call but the tracer could not read the path" — the truncation case O03
/// names — so that call, when it succeeds, becomes a `path_unreadable` gap
/// rather than a result.
///
/// The substring gates the seam to the test's own target path so the observer
/// capability probe (whose paths never match) is untouched. A test seam (S9):
/// read once when the session starts, empty/unset leaves the tracer unchanged
/// (the release binary is unaffected), and, like every `OURO_JAIL_TEST_*`
/// variable, it is recorded in jail state and in every receipt with native
/// details (`state::persist::test_seams`). It can only MANUFACTURE a gap the
/// tracer already records for real truncation — never hide a result or widen
/// authority — so a run under it ends exactly as a run with that real loss would.
pub const TRUNCATE_PATH_SEAM: &str = "OURO_JAIL_TEST_TRACER_TRUNCATE_PATH";

/// `OURO_JAIL_TEST_TRACER_UNMATCHED_EXIT=<substring>`: every covered non-exec
/// entry whose path contains `<substring>` is followed to its exit stop
/// without being recorded, so its exit has no entry to pair with and is an
/// `unmatched_exit` gap. A path-gated test seam (S9), read once when the
/// session starts, recorded like every `OURO_JAIL_TEST_*` variable; it
/// manufactures only a gap the tracer already records.
pub const UNMATCHED_EXIT_SEAM: &str = "OURO_JAIL_TEST_TRACER_UNMATCHED_EXIT";

fn seam_marker(name: &str) -> Option<Vec<u8>> {
    std::env::var(name)
        .ok()
        .filter(|value| !value.is_empty())
        .map(String::into_bytes)
}

fn path_has_marker(snapshot: Option<&PathSnapshot>, marker: &[u8]) -> bool {
    snapshot.is_some_and(|snapshot| {
        snapshot
            .bytes
            .windows(marker.len())
            .any(|window| window == marker)
    })
}

// J5-B2 O03 seams end.

/// The named components of a raw pathname: empty components (`//`, a
/// trailing `/`) and `.` name nothing and are dropped.
fn components(path: &[u8]) -> impl DoubleEndedIterator<Item = &[u8]> {
    path.split(|byte| *byte == b'/')
        .filter(|component| !component.is_empty() && *component != b".")
}

/// Security 2026-09-29 (audit 6 N1, review fixes): whether the kernel's own
/// resolution of the descriptor a successful open returned — the
/// `/proc/<tid>/fd/<ret>` link, `resolved` — corroborates the pathname
/// snapshot the event would certify.
///
/// Components are compared, not only the final one, so an A-B-A rewrite of
/// a directory component is caught as well as one of the name: an absolute
/// snapshot must name exactly the resolved path; a relative one, resolved
/// against a cwd or dirfd the observer does not read, must be its tail; and
/// past a `..` only the components after the last one are comparable. An
/// `O_TMPFILE` open names a directory and its descriptor resolves to an
/// unnamed `#<ino>` inside it, so the directory is compared. Anything else —
/// a link that is no path (the `pipe:[…]` behind `/dev/stderr`), a symlink
/// along the way, a concurrent rename — does not corroborate, which only
/// ever weakens the claim.
///
/// What this cannot see: the descriptor table is shared with the sibling
/// threads, which run while this one is stopped, so a sibling can put a
/// same-named file at descriptor `ret` before the link is read. That is the
/// residual of reading a shared table from outside the process.
///
/// Audit 7 L7, the ` (deleted)` annotation: the kernel appends it to an
/// unlinked file's link, but a live file can also be
/// *named* that way, so the annotation alone would let a decoy named
/// `README.md (deleted)` pass an A-B-A race as a certified `README.md`
/// claim. When the annotation is present and the open is not an
/// `O_TMPFILE` (whose descriptor is legitimately unnamed), the link count
/// read from the descriptor decides: only a file whose count has reached 0
/// corroborates. `nlink` is `None` when the count could not be read or was
/// never asked for; an unreadable count does not corroborate. The check only
/// ever weakens.
fn path_corroborated(snapshot: &[u8], resolved: &[u8], tmpfile: bool, nlink: Option<u64>) -> bool {
    if resolved.ends_with(b" (deleted)") && !tmpfile && nlink != Some(0) {
        return false;
    }
    let resolved = resolved.strip_suffix(b" (deleted)").unwrap_or(resolved);
    if !resolved.starts_with(b"/") {
        return false;
    }
    // Compare from the tail without allocating component vectors.
    let mut resolved = components(resolved).rev();
    if tmpfile && !resolved.next().is_some_and(|name| name.starts_with(b"#")) {
        return false;
    }
    let mut matched = false;
    for component in components(snapshot).rev() {
        if component == b".." {
            return matched;
        }
        if resolved.next() != Some(component) {
            return false;
        }
        matched = true;
    }
    if snapshot.starts_with(b"/") {
        resolved.next().is_none()
    } else {
        matched
    }
}

/// Security 2026-09-29 (audit 6 N2, review fixes): the command rules
/// re-checked at the exec event, against what the kernel installed.
///
/// `entry` is the argv the entry stop judged (tracee memory), `kernel` the
/// kernel's own copy (`/proc/<tid>/cmdline`), `claimed` the exec pathname
/// snapshot and `image` the `/proc/<tid>/exe` link.
///
/// - The same argv (or, for an `execve` with none, the one empty argument
///   the kernel inserts): the entry verdict stands for the arguments, and
///   the image the kernel loaded is the new evidence for element 0.
/// - An interpreter rewrite — a `#!` script or a `binfmt_misc` handler: the
///   kernel replaced `argv[0]` with the interpreter, its optional argument
///   and the file name, and kept `argv[1..]` as the tail. The rules judge
///   what the entry check judged, the script and its arguments, so they see
///   the kernel's copy of the element before the tail with that tail — never
///   the interpreter's argv, so `forbid = ["bash **"]` does not kill every
///   bash script the entry check let through.
/// - Any other difference: the argv changed between the entry read and the
///   kernel's copy, which is judged with the claimed path and the image as
///   element 0's identity.
/// - An unreadable kernel copy: refused, as an unreadable argv is at the
///   entry stop.
///
/// This stays an accident filter (jail-v2 §7.2): a tracee that races its
/// own argv into the shape of an interpreter rewrite is judged on that
/// shape, as a `sh -c` re-spelling is.
fn exec_recheck(
    rules: &crate::commands::Rules,
    entry: &[Vec<u8>],
    kernel: Option<&[Vec<u8>]>,
    claimed: Option<&[u8]>,
    image: Option<&[u8]>,
) -> Option<crate::commands::Hit> {
    let image = image.map(|image| image.strip_suffix(b" (deleted)").unwrap_or(image));
    let Some(kernel) = kernel else {
        return rules.check(None, claimed);
    };
    if kernel == entry || (entry.is_empty() && kernel == [Vec::<u8>::new()]) {
        return rules.check(Some(kernel), image);
    }
    let tail = entry.get(1..).unwrap_or(&[]);
    if kernel.len() >= tail.len() + 2 && kernel.ends_with(tail) {
        return rules.check(Some(&kernel[kernel.len() - tail.len() - 1..]), claimed);
    }
    rules
        .check(Some(kernel), claimed)
        .or_else(|| rules.check(Some(kernel), image))
}

struct Session {
    config: TracerConfig,
    tx: SyncSender<TracerEvent>,
    /// Bytes of events handed to the channel that the consumer has not taken
    /// yet: part of the budget, given back by [`super::Events`].
    handed: Arc<AtomicUsize>,
    /// Events not yet handed to the channel, oldest first.
    pending: VecDeque<Queued>,
    pending_bytes: usize,
    lifecycle_pending: usize,
    /// The byte ceiling the outbox admits against: buffered and handed-over
    /// bytes together ([`super::QueueBounds::bytes_max`]).
    bytes_max: usize,
    /// The byte ceiling results admit against: `bytes_max` short of the
    /// lifecycle reserve, so the reserve stays free for lifecycle facts
    /// ([`super::QueueBounds::result_bytes_max`]).
    result_bytes_max: usize,
    /// True while the consumer is behind: results are dropped without
    /// waiting another second to find out again.
    stalled: bool,
    disconnected: bool,
    /// The loss being coalesced, one summary per reason, per §11.4
    /// ("Coalesce repeated losses into bounded interval summaries"). At most
    /// one entry per [`GapReason`], so it is bounded whatever the child does.
    coalesced: Vec<CoalescedGap>,
    /// The `CLOCK_BOOTTIME` reading at supervisor start. Gap endpoints are
    /// elapsed time since it, not time since boot (§11.4).
    epoch_boottime_ns: u64,
    /// The last moment an event reached the consumer. A gap bounds itself
    /// from here, which is what §11.4 means by the last known healthy point.
    last_healthy_ns: u64,
    summary: TracerSummary,
    tasks: HashMap<pid_t, Task>,
    procs: HashMap<pid_t, Process>,
    /// Threads the kernel destroyed for a reason we saw, with the moment we
    /// may stop expecting their notification. Bounded, and pruned, so a
    /// recycled pid cannot be swallowed by a stale entry.
    retired: HashMap<pid_t, Instant>,
    /// Tracees whose death was reported before their fork event arrived,
    /// with the moment the late fork event can no longer follow. Fork-order
    /// races: the child stopped nothing, ran nothing, and is not loss.
    tracee_deaths: HashMap<pid_t, Instant>,
    inflight: usize,
    scratch: Vec<u8>,
    /// Where task identity comes from: `/proc`, or a test's script.
    procfs: Box<dyn ProcView>,
    // J5-B2 O03 seams: the path substrings that mark a covered call whose path
    // read is forced unreadable, or whose entry is dropped so its exit is
    // unmatched. `None` in the release binary unless the seam is set.
    force_truncate_marker: Option<Vec<u8>>,
    force_unmatched_marker: Option<Vec<u8>>,
    /// J5-T: which children, besides the tracees, the tracer answers for.
    owed: Owed,
    /// J5-T: the children this process had when the tracer attached, by
    /// birth. Any other child that is not a tracee came after — an orphan
    /// a subreaper supervisor adopted from the traced tree — and is owed.
    beside: Vec<(pid_t, u64)>,
}

impl Session {
    fn new(
        config: TracerConfig,
        tx: SyncSender<TracerEvent>,
        handed: Arc<AtomicUsize>,
        epoch_boottime_ns: u64,
        procfs: Box<dyn ProcView>,
    ) -> Self {
        let scratch = vec![0u8; config.path_snapshot_max.max(128)];
        // §11.4 budgets the whole user-space queue: the buffer and what was
        // handed to the channel and not taken yet are admitted against it
        // together. The bounds are the ones the observer plan records.
        let bounds = config.queue_bounds();
        Session {
            config,
            tx,
            handed,
            pending: VecDeque::new(),
            pending_bytes: 0,
            lifecycle_pending: 0,
            bytes_max: bounds.bytes_max,
            result_bytes_max: bounds.result_bytes_max,
            stalled: false,
            disconnected: false,
            coalesced: Vec::new(),
            epoch_boottime_ns,
            last_healthy_ns: clock::boottime_ns().saturating_sub(epoch_boottime_ns),
            summary: TracerSummary::default(),
            tasks: HashMap::new(),
            procs: HashMap::new(),
            retired: HashMap::new(),
            tracee_deaths: HashMap::new(),
            inflight: 0,
            scratch,
            procfs,
            force_truncate_marker: seam_marker(TRUNCATE_PATH_SEAM),
            force_unmatched_marker: seam_marker(UNMATCHED_EXIT_SEAM),
            // `run` reads the real one once the launcher is seized; a
            // session built without it keeps the rule before J5-T.
            owed: Owed::Every,
            beside: Vec::new(),
        }
    }

    /// Now, as elapsed time since the supervisor started: the base every gap
    /// endpoint is reported on. §11.4 bounds a gap from the last known
    /// healthy point, which is an age and not an instant on the boot clock.
    fn now_ns(&self) -> u64 {
        clock::boottime_ns().saturating_sub(self.epoch_boottime_ns)
    }

    // ---------------------------------------------------------- the outbox

    /// Everything held for the consumer: buffered, or handed over and not
    /// yet taken. The handed-over part can only be smaller by the time it is
    /// used, so admitting against it errs towards less.
    fn held(&self) -> usize {
        self.pending_bytes + self.handed.load(Ordering::Relaxed)
    }

    /// Whether an event is a lifecycle fact rather than an audit result.
    /// Lifecycle facts are not subject to result backpressure.
    fn is_lifecycle(event: &TracerEvent) -> bool {
        !matches!(event, TracerEvent::Syscall { .. })
    }

    /// Whether the event is a lifecycle fact a supervisor must never lose.
    /// These are fixed-size, so admitting them whatever the byte budget can
    /// overshoot it only by their own small size — the alternative is a
    /// supervisor without the exit status it exists to report.
    ///
    /// Audit 7 L10: an `Exec` that carries a command hit is critical too.
    /// The kill itself happens at the exec stop, but the `command_rule` note
    /// rides on this event, and a best-effort `forbid` needs the
    /// `Fact::CommandForbidden` it carries to stop the run; a verdict lost
    /// to queue pressure would leave a forbidden command unreported.
    fn is_critical(event: &TracerEvent) -> bool {
        match event {
            TracerEvent::Exec { command, .. } => command.is_some(),
            event => matches!(
                event,
                TracerEvent::Exit { .. }
                    | TracerEvent::Gap { .. }
                    | TracerEvent::Finished
                    | TracerEvent::UntracedChildExit { .. }
            ),
        }
    }

    /// The closed-set operations a lost event would have carried, so a gap
    /// can name exactly the classes it affected (§11.4).
    fn ops_of(event: &TracerEvent) -> OpSet {
        match event {
            TracerEvent::Syscall { op, .. } => OpSet::of(*op),
            // §11.4 assigns proc.exec and proc.exit to the same class.
            TracerEvent::Exec { .. } | TracerEvent::Exit { .. } => OpSet::of(ClosedOp::Exec),
            _ => OpSet::EMPTY,
        }
    }

    /// Hand as much of the backlog to the consumer as it will take.
    fn flush(&mut self) {
        while let Some(front) = self.pending.pop_front() {
            let lifecycle = front.lifecycle;
            let bytes = front.bytes;
            // Charged before the send, so the consumer's credit, which comes
            // after the receive, can never run ahead of it.
            self.handed.fetch_add(bytes, Ordering::Relaxed);
            match self.tx.try_send(front.event) {
                Ok(()) => {
                    self.pending_bytes -= bytes;
                    if lifecycle {
                        self.lifecycle_pending -= 1;
                    }
                    self.summary.emitted += 1;
                    self.last_healthy_ns = self.now_ns();
                }
                Err(TrySendError::Full(event)) => {
                    self.handed.fetch_sub(bytes, Ordering::Relaxed);
                    self.pending.push_front(Queued {
                        event,
                        bytes,
                        lifecycle,
                    });
                    return;
                }
                Err(TrySendError::Disconnected(event)) => {
                    self.handed.fetch_sub(bytes, Ordering::Relaxed);
                    self.pending.push_front(Queued {
                        event,
                        bytes,
                        lifecycle,
                    });
                    self.disconnected = true;
                    return;
                }
            }
        }
        self.stalled = false;
    }

    fn room_for(&self, bytes: usize) -> bool {
        self.pending.len() < self.config.queue_max.max(1)
            && self.held() + bytes <= self.result_bytes_max
    }

    fn enqueue(&mut self, event: TracerEvent, bytes: usize, lifecycle: bool) {
        if lifecycle {
            self.lifecycle_pending += 1;
        }
        if matches!(event, TracerEvent::Gap { .. }) {
            self.summary.gaps += 1;
        }
        self.pending_bytes += bytes;
        self.summary.queue_bytes_peak = self.summary.queue_bytes_peak.max(self.held());
        self.pending.push_back(Queued {
            event,
            bytes,
            lifecycle,
        });
    }

    /// Put the coalesced gaps in front of whatever comes next, so the loss
    /// is never hidden behind the event that followed it. They are critical
    /// facts, so no cap applies to them.
    fn materialise_gap(&mut self) {
        for gap in std::mem::take(&mut self.coalesced) {
            let event = TracerEvent::Gap {
                reason: gap.reason,
                ops: gap.ops,
                from_ns: gap.from_ns,
                to_ns: gap.to_ns,
                count: gap.count,
            };
            let bytes = event_bytes(&event);
            self.enqueue(event, bytes, true);
        }
    }

    fn emit(&mut self, event: TracerEvent) {
        self.flush();
        let lifecycle = Session::is_lifecycle(&event);
        let bytes = event_bytes(&event);
        let ops = Session::ops_of(&event);

        if lifecycle {
            // Two caps bound the lifecycle backlog: a count, and the §11.4
            // byte budget, lifecycle events included — an `Exec` carries a
            // child-chosen pathname of up to `path_snapshot_max` bytes, so
            // without the budget the backlog alone could exceed it many times
            // over. Results stop short of [`LIFECYCLE_RESERVE`], so a dropped
            // `Exec` means the budget was full of evidence, not that the
            // reserve failed.
            let over =
                self.lifecycle_pending >= LIFECYCLE_MAX || self.held() + bytes > self.bytes_max;
            if over {
                // J4 D6: the critical facts are exempt from every cap, both
                // of them. Checking the count first, as this used to, dropped
                // a target's `Exit` behind a backlog of fork facts.
                if !Session::is_critical(&event) {
                    self.summary.loss.lifecycle_dropped += 1;
                    self.note_drop(GapReason::LifecycleDropped, ops);
                    return;
                }
                if let TracerEvent::Gap {
                    reason,
                    ops,
                    from_ns,
                    to_ns,
                    count,
                } = event
                {
                    // Not dropped: merged into this reason's summary, which
                    // is delivered ahead of the next fact. A child that can
                    // cause a gap per syscall cannot grow the backlog past
                    // one entry per reason this way.
                    self.coalesce(reason, ops, from_ns, to_ns, count);
                    return;
                }
                // `Exit`, `UntracedChildExit` and `Finished` are fixed-size
                // and bounded by the tasks that exist: past every cap.
            }
            self.materialise_gap();
            self.enqueue(event, bytes, true);
            self.flush();
            return;
        }

        if self.room_for(bytes) {
            self.materialise_gap();
            self.enqueue(event, bytes, false);
            self.flush();
            return;
        }
        if self.stalled || self.disconnected {
            // The consumer already failed to keep up once. Do not hold a
            // tracee at a stop for another second to find out again.
            self.summary.loss.queue_dropped += 1;
            self.note_drop(GapReason::QueueFull, ops);
            return;
        }
        // Bounded backpressure: wait, but never longer than this (§11.4).
        let deadline = Instant::now() + QUEUE_BLOCK;
        loop {
            self.flush();
            if self.room_for(bytes) {
                self.materialise_gap();
                self.enqueue(event, bytes, false);
                self.flush();
                return;
            }
            if self.disconnected || Instant::now() >= deadline {
                self.stalled = true;
                self.summary.loss.queue_dropped += 1;
                self.note_drop(GapReason::QueueFull, ops);
                return;
            }
            std::thread::sleep(QUEUE_POLL);
        }
    }

    /// Record one dropped event into its reason's coalesced gap.
    fn note_drop(&mut self, reason: GapReason, ops: OpSet) {
        let now = self.now_ns();
        let from = self.last_healthy_ns;
        self.coalesce(reason, ops, from, now, Some(1));
    }

    /// Merge a gap into the summary for its reason, or open one. Reasons are
    /// never merged into each other, so no summary misnames its loss.
    fn coalesce(
        &mut self,
        reason: GapReason,
        ops: OpSet,
        from_ns: u64,
        to_ns: u64,
        count: Option<u64>,
    ) {
        if let Some(gap) = self.coalesced.iter_mut().find(|gap| gap.reason == reason) {
            gap.from_ns = gap.from_ns.min(from_ns);
            gap.to_ns = gap.to_ns.max(to_ns);
            gap.ops = gap.ops.union(ops);
            gap.count = gap.count.zip(count).and_then(|(a, b)| a.checked_add(b));
            return;
        }
        self.coalesced.push(CoalescedGap {
            reason,
            ops,
            from_ns,
            to_ns,
            count,
        });
    }

    /// Record a gap that is not queue loss. It is a lifecycle event, so it
    /// is never dropped to make room for a result.
    fn gap(&mut self, reason: GapReason, ops: OpSet, count: Option<u64>) {
        let event = TracerEvent::Gap {
            reason,
            ops,
            from_ns: self.last_healthy_ns,
            to_ns: self.now_ns(),
            count,
        };
        self.emit(event);
    }

    // ---------------------------------------------------------- the loop

    fn run_loop(&mut self, handles: &Handles) {
        let mut shutdown: Option<Instant> = None;
        loop {
            if shutdown.is_none() && handles.stop.load(Ordering::Acquire) {
                let budget = Duration::from_nanos(handles.shutdown_ns.load(Ordering::Acquire));
                shutdown = Some(Instant::now() + budget);
            }
            if let Some(deadline) = shutdown {
                if self.tasks.is_empty() {
                    break;
                }
                if Instant::now() >= deadline {
                    self.force_stop();
                    break;
                }
            }
            // J5-T: done on its own account. Past this point a blocking
            // wait could only be for a child the tracer does not answer for.
            if self.accounted_for() {
                break;
            }
            // About to block: hand the consumer whatever is still buffered,
            // so a backlog never waits on the tree making its next call.
            self.flush();
            // Blocking, so a stop costs nothing while the tree is busy. The
            // supervisor interrupts it with the wake signal; `EINTR` comes
            // back as `Interrupted` and the loop looks at the flag again.
            match sys::wait_any(0) {
                Wait::Interrupted | Wait::Nothing => continue,
                // Every child and every tracee is gone. Nothing else can
                // arrive, so the tracer is done whether or not it was asked.
                Wait::NoChildren => break,
                Wait::Status { pid, status } => self.handle(pid, status),
            }
        }
    }

    /// J5-T: every tracee has been reaped and the backend's exit delivered
    /// ([`Owed`]). Any other child of this process may live on.
    fn accounted_for(&self) -> bool {
        self.tasks.is_empty()
            && match self.owed {
                Owed::Nothing => true,
                Owed::Backend { pid, birth, reaped } => reaped || !self.still_there(pid, birth),
                Owed::Every => false,
            }
            && self.adopted().is_empty()
    }

    /// J5-T: this process's children that are not tracees and that it did
    /// not have, under the same birth, when the tracer attached — orphans of
    /// the traced tree a subreaper supervisor adopted, zombie or alive. They
    /// are the attempt's, so the tracer reaps them before it finishes (L01.7).
    fn adopted(&self) -> Vec<pid_t> {
        self.procfs
            .children(sys::getpid())
            .into_iter()
            .filter(|pid| !self.tasks.contains_key(pid))
            .filter(|pid| {
                !self.beside.iter().any(|(known, birth)| {
                    known == pid && self.procfs.start_ticks(*pid) == Some(*birth)
                })
            })
            .collect()
    }

    /// Whether `pid` still names the process born at `birth`, zombie
    /// included. Without a birth, whether anything has the number.
    fn still_there(&self, pid: pid_t, birth: Option<u64>) -> bool {
        match (self.procfs.start_ticks(pid), birth) {
            (Some(now), Some(born)) => now == born,
            (now, None) => now.is_some(),
            (None, Some(_)) => false,
        }
    }

    /// The shutdown budget expired with tracees still alive. End them rather
    /// than leave them stopped at a ptrace stop nobody will answer.
    fn force_stop(&mut self) {
        let alive: Vec<pid_t> = self.tasks.keys().copied().collect();
        if alive.is_empty() {
            return;
        }
        // Whatever these tracees were about to do is unobserved, whether or
        // not the kill and the reap below succeed. That is the loss, and it
        // is recorded before anything is attempted. With live tasks beyond
        // the observation boundary, loss is not limited to in-flight calls.
        self.summary.loss.abandoned_tracees += alive.len() as u64;
        self.gap(
            GapReason::TraceesAbandoned,
            OpSet::ALL,
            Some(alive.len() as u64),
        );
        for pid in &alive {
            let _ = sys::kill(*pid, libc::SIGKILL);
            let _ = sys::restart(*pid, sys::PTRACE_CONT, libc::SIGKILL);
        }
        let deadline = Instant::now() + KILL_GRACE;
        while !self.tasks.is_empty() && Instant::now() < deadline {
            match sys::wait_any(libc::WNOHANG) {
                Wait::Status { pid, status } => self.handle(pid, status),
                Wait::NoChildren => break,
                Wait::Nothing | Wait::Interrupted => {
                    std::thread::sleep(TERMINAL_POLL);
                }
            }
        }
        let left = self.tasks.len() as u64;
        if left > 0 {
            // Killed but not even reaped: the kernel will reparent them to
            // init, and their statuses are gone for good.
            self.summary.loss.death_unattributed += left;
            self.gap(GapReason::DeathUnattributed, OpSet::EMPTY, Some(left));
        }
    }

    fn handle(&mut self, pid: pid_t, status: libc::c_int) {
        self.summary.stops += 1;
        // Expired retirements and fork-race ghosts are dropped on every
        // stop, not only when a death is delivered: a clone-and-exec loop
        // can run for a long time without reporting a single one.
        self.prune_retired();
        if libc::WIFEXITED(status) || libc::WIFSIGNALED(status) {
            self.handle_death(pid, status);
            return;
        }
        if !libc::WIFSTOPPED(status) {
            return;
        }
        let signal = libc::WSTOPSIG(status);
        let event = (status >> 16) & 0xff;
        // A stop from a task we have not seen is the fork ordering race: the
        // child stopped before its parent reported the event that created it.
        self.register(pid);

        if self
            .tasks
            .get(&pid)
            .is_some_and(|task| task.restart.is_some())
            && let Some(inject) = self.handle_restart_stop(pid, signal, event)
        {
            self.restart(pid, inject);
            return;
        }

        let mut inject = 0;
        match event {
            sys::PTRACE_EVENT_SECCOMP => self.handle_entry(pid),
            sys::PTRACE_EVENT_EXEC => self.handle_exec(pid),
            sys::PTRACE_EVENT_FORK | sys::PTRACE_EVENT_VFORK | sys::PTRACE_EVENT_CLONE => {
                self.handle_fork(pid);
            }
            // The thread is about to die. The death itself is reported by
            // `waitpid`, with the status the consumer needs; nothing is
            // emitted here.
            sys::PTRACE_EVENT_EXIT | sys::PTRACE_EVENT_VFORK_DONE => {}
            sys::PTRACE_EVENT_STOP => {
                // Two different stops share this event. `PTRACE_GETSIGINFO`
                // is the documented way to tell them apart: it fails with
                // EINVAL only for a group-stop.
                if sys::is_group_stop(pid) {
                    // Leave it stopped, as whoever sent the signal intended,
                    // and stay its tracer.
                    if let Err(err) = sys::listen(pid) {
                        self.restart_failed(pid, &err);
                    }
                    return;
                }
                // The initial stop of a newly attached child, or a
                // PTRACE_INTERRUPT. Nothing to deliver.
            }
            _ => {
                if signal == sys::SYSCALL_STOP_SIG {
                    self.handle_syscall_stop(pid);
                } else {
                    // An ordinary signal on its way to the tracee.
                    inject = signal;
                }
            }
        }
        self.restart(pid, inject);
    }

    fn restart(&mut self, pid: pid_t, signal: libc::c_int) {
        // A call waiting for the kernel's restart decision is followed one
        // instruction at a time, so that decision is a stop (`RestartWait`);
        // a call in flight is stepped to its syscall exit; anything else
        // runs to its next traced event.
        let (request, fresh) = match self.tasks.get(&pid) {
            Some(Task {
                restart:
                    Some(RestartWait {
                        awaiting: Awaiting::Decision,
                        ..
                    }),
                ..
            }) => (sys::PTRACE_SINGLESTEP, false),
            Some(task) if task.pending.is_some() => (sys::PTRACE_SYSCALL, task.entry_fresh),
            _ => (sys::PTRACE_CONT, false),
        };
        let result = sys::restart(pid, request, signal);
        if let Some(task) = self.tasks.get_mut(&pid) {
            task.entry_fresh = false;
        }
        match result {
            Ok(()) => {}
            Err(err) if err.raw_os_error() == Some(libc::ESRCH) => {
                if fresh {
                    // J4 O-3: the entry was taken at this very stop, and the
                    // tracee was killed before it could be resumed from it
                    // (at an unresumed stop only SIGKILL makes the resume
                    // fail with ESRCH). The kernel skips a call whose thread
                    // has a fatal signal pending after the trace event, so
                    // this one never ran: no result, and no loss.
                    self.entry_never_ran(pid);
                }
            }
            Err(err) => self.restart_failed(pid, &err),
        }
    }

    /// J4 O-3: forget the entry of a thread killed at its seccomp stop.
    fn entry_never_ran(&mut self, tid: pid_t) {
        if self
            .tasks
            .get_mut(&tid)
            .and_then(|task| task.pending.take())
            .is_some()
        {
            self.inflight = self.inflight.saturating_sub(1);
            self.summary.killed_at_entry += 1;
        }
    }

    /// A stopped tracee that cannot be restarted would stay stopped forever,
    /// and nothing else in the tree could make progress past it. ESRCH means
    /// it died between its stop and the call, which the next wait reports;
    /// anything else is recorded, and the tracee is killed rather than left.
    fn restart_failed(&mut self, pid: pid_t, err: &std::io::Error) {
        if err.raw_os_error() == Some(libc::ESRCH) {
            return;
        }
        self.summary.loss.restart_failed += 1;
        self.gap(GapReason::RestartFailed, OpSet::EMPTY, Some(1));
        let _ = sys::kill(pid, libc::SIGKILL);
    }

    // ---------------------------------------------------------- identity

    /// Make sure `tid` is tracked, learning its thread group and birth from
    /// `/proc`.
    fn register(&mut self, tid: pid_t) {
        if self.tasks.contains_key(&tid) {
            return;
        }
        self.summary.tracees += 1;
        let start_ticks = self.procfs.start_ticks(tid);
        let (tgid, identity_known) = match self.procfs.tgid(tid) {
            Some(tgid) => (tgid, true),
            None => {
                self.summary.loss.identity_unavailable += 1;
                self.gap(GapReason::IdentityUnavailable, OpSet::EMPTY, Some(1));
                (tid, false)
            }
        };
        self.tasks.insert(
            tid,
            Task {
                tgid,
                start_ticks,
                pending: None,
                site: Site::default(),
                entry_fresh: false,
                restart: None,
            },
        );
        // A new group's birth is its leader's start time: the task itself
        // when it is the leader (a fork child), else the leader read now.
        // An existing group keeps the birth it was registered with.
        if !self.procs.contains_key(&tgid) {
            let birth = if tgid == tid {
                start_ticks
            } else {
                self.procfs.start_ticks(tgid)
            };
            self.procs.insert(
                tgid,
                Process {
                    threads: HashSet::new(),
                    witnessed_exec: false,
                    identity_known,
                    birth,
                },
            );
        }
        let process = self.procs.get_mut(&tgid).expect("just inserted");
        process.identity_known &= identity_known;
        process.threads.insert(tid);
    }

    fn tgid_of(&self, tid: pid_t) -> pid_t {
        self.tasks.get(&tid).map_or(tid, |task| task.tgid)
    }

    /// The birth of the process `tgid` names now.
    fn birth_of(&self, tgid: pid_t) -> Option<u64> {
        self.procs.get(&tgid).and_then(|process| process.birth)
    }

    /// Forget expired retirement and fork-race entries. Both are time-bounded,
    /// so a recycled pid cannot be swallowed by a stale one for longer than
    /// the grace period.
    fn prune_retired(&mut self) {
        let now = Instant::now();
        self.retired.retain(|_, deadline| *deadline > now);
        self.tracee_deaths.retain(|_, deadline| *deadline > now);
    }

    // ---------------------------------------------------------- events

    fn handle_fork(&mut self, parent_tid: pid_t) {
        let Ok(child) = sys::event_msg(parent_tid) else {
            self.summary.loss.syscall_info_unavailable += 1;
            self.gap(GapReason::SyscallInfoUnavailable, OpSet::ALL, Some(1));
            return;
        };
        let child = child as pid_t;
        // Fork-ordering race: the child died before its first stop, so this
        // late event names a task that no longer exists and never executed
        // anything observable. No task entry, no identity gap, no `Fork` —
        // recording the dead pid would be false loss plus an entry nothing
        // would ever reap (§11.4: only what was seen is ever claimed).
        let raced_death = self.tracee_deaths.remove(&child).is_some();
        if self.procfs.tgid(child).is_none() {
            if !raced_death {
                self.summary.late_fork_races += 1;
            }
            return;
        }
        self.register(child);
        let parent = self.tgid_of(parent_tid);
        let child_tgid = self.tgid_of(child);
        let child_start_ticks = self.tasks.get(&child).and_then(|task| task.start_ticks);
        self.emit(TracerEvent::Fork {
            parent,
            parent_tid,
            child,
            // A CLONE_THREAD child lands in the thread group that made the
            // call; a new process starts its own.
            is_thread: child_tgid == parent,
            child_start_ticks,
            monotonic_ns: clock::boottime_ns(),
        });
    }

    fn handle_exec(&mut self, tid: pid_t) {
        // After execve the thread group has exactly one thread and its id is
        // the leader's, which is the id this stop was reported under. If a
        // worker did the exec, PTRACE_GETEVENTMSG names the id it had before.
        let former = sys::event_msg(tid)
            .map(|value| value as pid_t)
            .unwrap_or(tid);
        self.exec_transition(tid, former);
    }

    /// The exec transition reported under `tid`, made by the thread that had
    /// the id `former` before it (`tid` itself for a leader exec).
    fn exec_transition(&mut self, tid: pid_t, former: pid_t) {
        self.summary.exec_transitions += 1;
        let non_leader = former != tid && former > 0;
        let mut carried: Option<(InFlight, Site)> = None;
        if non_leader && let Some(task) = self.tasks.remove(&former) {
            carried = task.pending.map(|pending| (pending, task.site));
            if let Some(wait) = task.restart {
                // Not reachable: the thread that execs is in its `execve`,
                // not waiting for a restart decision. Kept exact anyway.
                self.restart_ended(wait);
            }
            // That task did not die: it is this one now, under the leader's
            // id. Nothing will ever report it, so it is not retired — a
            // recycled pid with this number must not be swallowed.
            self.summary.tasks_destroyed_by_exec += 1;
            if let Some(process) = self.procs.get_mut(&task.tgid) {
                process.threads.remove(&former);
            }
        }
        // The task registered under `tid` was the leader until now. After a
        // non-leader exec that thread is gone: the kernel destroyed it, and
        // the thread that execed took its id. Whatever it had in flight can
        // no longer return, and the syscall exit that follows is the exec's
        // own — whether or not the exec's entry was followed (J4 W3, loss
        // review finding 1: when it was refused an in-flight slot, the
        // leader's stale entry used to be paired with that exit, an invented
        // result). The gap names the call, because the entry is in hand.
        let (stale, stale_wait) = match self.tasks.get_mut(&tid) {
            Some(task) if non_leader => (task.pending.take(), task.restart.take()),
            // A leader's own exec: a wait would have been settled at its
            // `execve` entry, so one here is out of sequence.
            Some(task) => (None, task.restart.take()),
            None => (None, None),
        };
        if let Some(call) = stale {
            self.inflight = self.inflight.saturating_sub(1);
            self.summary.loss.abandoned_entries += 1;
            self.gap(GapReason::EntryAbandoned, call.ops(), Some(1));
        }
        match stale_wait {
            Some(wait) if non_leader => self.restart_ended(wait),
            Some(wait) => {
                self.inflight = self.inflight.saturating_sub(1);
                self.summary.loss.restart_unresolved += 1;
                self.gap(GapReason::RestartUnresolved, wait.call.ops(), Some(1));
            }
            None => {}
        }
        let tgid = self.tgid_of(tid);
        let mut destroyed = Vec::new();
        if let Some(process) = self.procs.get_mut(&tgid) {
            for other in process.threads.iter().copied() {
                if other != tid {
                    destroyed.push(other);
                }
            }
            process.threads.retain(|thread| *thread == tid);
            process.threads.insert(tid);
            process.witnessed_exec = true;
        }
        for thread in destroyed {
            // The kernel destroys the other threads without reporting them,
            // so their entry is retired for a bounded time in case one was
            // already on its way.
            self.retired.insert(thread, Instant::now() + KILL_GRACE);
            self.summary.tasks_destroyed_by_exec += 1;
            let Some(task) = self.tasks.remove(&thread) else {
                continue;
            };
            if let Some(pending) = task.pending {
                // The entry is in hand: the gap names the call it would have
                // reported, not an anonymous hole (§11.4).
                self.inflight = self.inflight.saturating_sub(1);
                self.summary.loss.abandoned_entries += 1;
                self.gap(GapReason::EntryAbandoned, pending.ops(), Some(1));
            }
            if let Some(wait) = task.restart {
                // Destroyed while its restart was owed: as a death.
                self.restart_ended(wait);
            }
        }
        let mut path = None;
        let mut dirfd = None;
        let mut syscall = None;
        let mut command = None;
        if let Some(task) = self.tasks.get_mut(&tid) {
            if let Some((pending, site)) = carried {
                task.pending = Some(pending);
                task.site = site;
            }
            if let Some(InFlight::Closed(pending)) = task.pending.as_mut()
                && pending.entry.op == ClosedOp::Exec
            {
                pending.exec_confirmed = true;
                path = pending.args.path.clone();
                dirfd = pending.args.dirfd;
                syscall = Some(pending.entry.name);
                // Security 2026-09-29 (audit 6 N2): the argv the entry-stop
                // check judged is tracee memory, which a sibling thread can
                // rewrite for the kernel's own copy. The image is installed
                // here and has run nothing, so the kernel's own copy of the
                // argv and of the image are re-checked ([`exec_recheck`]).
                // An entry the rules already denied never reaches this stop.
                if !self.config.commands.is_empty() && pending.args.command.is_none() {
                    let kernel_argv = self
                        .procfs
                        .cmdline(tid)
                        .as_deref()
                        .and_then(proc::parse_cmdline);
                    let image = self.procfs.exe(tid);
                    command = exec_recheck(
                        &self.config.commands,
                        pending.entry_argv.as_deref().unwrap_or(&[]),
                        kernel_argv.as_deref(),
                        pending.args.path.as_ref().map(|p| p.bytes.as_slice()),
                        image.as_deref(),
                    )
                    .map(Box::new);
                }
            }
            if command.is_some() {
                // The exec was observed whole and its event carries the
                // verdict, so its entry leaves flight here: the death that
                // follows has no call to abandon.
                task.pending = None;
                self.inflight = self.inflight.saturating_sub(1);
            }
        }
        // Security 2026-09-27 (audit 3 A1): the kernel has already installed
        // the new image at this stop, so `/proc/<tid>/exe` names what actually
        // runs, whatever the tracee did to the pathname between the entry
        // snapshot and the kernel's own copy. A read that fails keeps the
        // event (the snapshot's claim stands, as before) without the
        // corroboration.
        let images = self
            .config
            .target
            .as_ref()
            .filter(|(pid, _)| *pid == tgid)
            .map_or(&[][..], |(_, images)| images.as_slice());
        let kernel_image = proc::kernel_exe(tid, images);
        // Audit 2026-10-08 H2: a `#!` target loads the interpreter its
        // script names, so the kernel image is not one of the target's own
        // spellings. The evidence for that rewrite — each candidate's first
        // line read through the tracee's root, and the kernel's own copy of
        // the new argv — is read in this same stopped window; the
        // confirmation decision stays with the observer, which already owns
        // the kernel image's.
        let (shebangs, kernel_argv) = if kernel_image.is_some() && !images.is_empty() {
            (
                images
                    .iter()
                    .map(|candidate| {
                        proc::shebang_image(tid, candidate)
                            .or_else(|| proc::binfmt_image(tid, candidate))
                    })
                    .collect(),
                self.procfs
                    .cmdline(tid)
                    .as_deref()
                    .and_then(proc::parse_cmdline),
            )
        } else {
            (Vec::new(), None)
        };
        if command.is_some() {
            // The hit is live: the process dies before its image runs an
            // instruction — after the image was read above, so the event
            // keeps the kernel's evidence — and the event records the verdict
            // and stops the run for a `forbid`.
            unsafe {
                libc::kill(tid, libc::SIGKILL);
            }
        }
        let start_ticks = self.birth_of(tgid);
        self.emit(TracerEvent::Exec {
            pid: tgid,
            start_ticks,
            syscall,
            path,
            kernel_image,
            dirfd,
            command,
            shebangs,
            kernel_argv,
            monotonic_ns: clock::boottime_ns(),
        });
    }

    /// Security 2026-09-27 (audit 4 B2): whether a *foreign-ABI* entry is one of
    /// the two special calls anyway — a `seccomp` asking for its own
    /// notification listener, or a `clone` the kernel will not attach to this
    /// tracer.
    ///
    /// The i386 (`int 0x80`) numbers are 354 (`seccomp`, flags in `args[1]`) and
    /// 120 (`clone`, flags in `args[0]`); the x32 spellings are the native
    /// numbers with the x32 bit set. Register positions are identical across
    /// these ABIs, so the same flag tests decide. The reference host does accept
    /// `int 0x80`, and under `none` a listener created through it can pass any
    /// syscall with `SECCOMP_USER_NOTIF_FLAG_CONTINUE` and no trace stop at all
    /// — which is the open-ended [`GapReason::ChildNotificationListener`] gap,
    /// not the bounded `foreign_abi` interval a plain foreign call costs.
    fn compat_special(info: &sys::SyscallInfo) -> Option<InFlight> {
        let listener_flags =
            u64::from(crate::platform::linux::tracer::filter::SECCOMP_FILTER_FLAG_NEW_LISTENER);
        let untraced_flag = u64::from(crate::platform::linux::tracer::filter::CLONE_UNTRACED);
        let x32 = info.arch == 0xc000_003e && info.nr & u64::from(sys::X32_SYSCALL_BIT) != 0;
        let i386 = info.arch == sys::AUDIT_ARCH_I386;
        let arm32 = info.arch == 0x4000_0028;
        if !i386 && !x32 && !arm32 {
            return None;
        }
        let nr = info.nr & !u64::from(sys::X32_SYSCALL_BIT);
        let is_seccomp = (arm32 && nr == 383)
            || (i386
                && nr == u64::from(crate::platform::linux::tracer::filter::I386_LISTENER_SYSCALL))
            || (x32 && !i386 && nr == 317);
        let is_clone = (arm32 && nr == 120)
            || (i386
                && nr == u64::from(crate::platform::linux::tracer::filter::I386_CLONE_SYSCALL))
            || (x32 && !i386 && nr == 56);
        if is_seccomp && info.args[1] & listener_flags != 0 {
            return Some(InFlight::Listener);
        }
        if nr == 435 || (is_clone && info.args[0] & untraced_flag != 0) {
            return Some(InFlight::Untraced);
        }
        None
    }

    /// Whether a covered, register-sourced read-only open is filtered at
    /// its entry (`--read-open-fast-path`), counted as such. An `openat2`
    /// never is: its flags live in tracee memory the kernel re-reads after
    /// this stop (audit 2026-09-25-2, S1), so a read-only verdict there is
    /// only an assertion until the exit re-read confirms it, and the call
    /// is followed to its exit. Filtered at entry, a sibling flipping
    /// `open_how.flags` between the two kernel reads could perform a
    /// covered mutation with no event and no gap.
    fn filter_readonly_open_at_entry(&mut self, entry: &'static Entry) -> bool {
        if matches!(entry.flags, FlagSource::OpenHow { .. }) {
            return false;
        }
        // A read-only open is outside `linux-closed-v1`. It is not a loss,
        // it is not an event, and the tracee is continued from here rather
        // than stepped to a syscall exit nobody reads. It is filtered before
        // the in-flight bound is consulted (J4 O-1): with the table full it
        // is still not a call the observer had to follow, so refusing it
        // would record a read as lost evidence.
        self.summary.filtered_readonly_opens += 1;
        true
    }

    /// A `PTRACE_EVENT_SECCOMP` stop: the tracee is at the entry of a call
    /// the narrowing filter traces, and the syscall has not run.
    fn handle_entry(&mut self, tid: pid_t) {
        let info = match sys::syscall_info(tid) {
            Ok(info)
                if info.op == sys::SYSCALL_INFO_SECCOMP || info.op == sys::SYSCALL_INFO_ENTRY =>
            {
                info
            }
            // J4 O-3: the tracee left this stop without being resumed, which
            // only a SIGKILL does — it is either on its way out (`ESRCH`) or
            // already stopped at its exit notification. The kernel skips a
            // call whose thread has a fatal signal pending after the trace
            // event (`__seccomp_filter`), so whatever it was, it never ran.
            Err(err) if err.raw_os_error() == Some(libc::ESRCH) => {
                self.summary.killed_at_entry += 1;
                return;
            }
            Ok(_) if Self::at_exit_notification(tid) => {
                self.summary.killed_at_entry += 1;
                return;
            }
            _ => {
                self.summary.loss.syscall_info_unavailable += 1;
                self.gap(GapReason::SyscallInfoUnavailable, OpSet::ALL, Some(1));
                return;
            }
        };
        let site = Site {
            arch: info.arch,
            nr: info.nr,
            ip: info.ip,
            arg0: info.args[0],
        };
        // jail-v1 §9.2: validate the architecture before the syscall number.
        // A compat or x32 entry carries a number from a different table, and
        // naming it from this one would mislabel the call (J4 D2): it is
        // foreign, followed to its return and never decoded.
        if info.arch != sys::AUDIT_ARCH || info.nr & u64::from(sys::X32_SYSCALL_BIT) != 0 {
            // Security 2026-09-27 (audit 4 B2): the two calls whose *native*
            // forms carry their own classification — a listener hides every
            // later syscall for as long as it is held, and an untraced
            // descendant is never seen again, so both are open-ended gaps,
            // not closed intervals — reach those classifications through a
            // compat ABI too. Only `none` stops here (contained baselines
            // EPERM the foreign arch before the trace), but its receipt must
            // not present a live listener channel as an ended interval.
            if let Some(special) = Session::compat_special(&info) {
                self.follow(tid, special, site);
                return;
            }
            self.follow(tid, InFlight::Foreign, site);
            return;
        }
        // J4 D1: a child asking for its own notification listener. The flags
        // are the register the kernel will read, not memory the child could
        // change behind this stop.
        if info.nr == u64::from(crate::platform::linux::tracer::filter::LISTENER_SYSCALL.1)
            && info.args[1]
                & u64::from(
                    crate::platform::linux::tracer::filter::SECCOMP_FILTER_FLAG_NEW_LISTENER,
                )
                != 0
        {
            self.follow(tid, InFlight::Listener, site);
            return;
        }
        // J4 S4: a clone the kernel will not attach to this tracer. The flags
        // are the register the kernel reads. Contained baselines refuse the
        // flag (EPERM outranks the trace), so only `none` stops here.
        if info.nr == u64::from(crate::platform::linux::tracer::filter::CLONE_SYSCALL.1)
            && info.args[0] & u64::from(crate::platform::linux::tracer::filter::CLONE_UNTRACED) != 0
        {
            self.follow(tid, InFlight::Untraced, site);
            return;
        }
        let Some(entry) = closed_set::lookup(info.nr) else {
            self.stop_not_ours(tid);
            return;
        };
        // Flags first: they decide whether this call is in the closed set at
        // all, and one that is not must cost neither a read of the tracee's
        // memory, nor an in-flight slot, nor a mark in the loss counters.
        let (flags, flags_unavailable) = self.capture_flags(tid, entry, &info.args);
        if !self.config.learning
            && entry.op == ClosedOp::Open
            && let Some(flags) = flags
            && !closed_set::open_is_covered(flags)
        {
            // Register-sourced flags are the kernel's own saved pt_regs, so
            // an entry-time read-only verdict is final. `openat2`'s verdict
            // never is — see [`Session::filter_readonly_open_at_entry`].
            if self.filter_readonly_open_at_entry(entry) {
                return;
            }
            // The verification follow costs an in-flight slot like any
            // followed call; refused one, the call runs unfollowed, which is
            // a hole the receipt must name.
            if !self.admit(OpSet::of(entry.op)) {
                return;
            }
            let pending = Pending {
                entry,
                args: Args {
                    flags: Some(flags),
                    ..Args::default()
                },
                exec_confirmed: false,
                path_unreadable: false,
                path2_unreadable: false,
                sockaddr_unreadable: false,
                flags_unavailable,
                raw: info.args,
                entry_argv: None,
            };
            self.begin(tid, InFlight::Closed(pending), site);
            return;
        }
        if !self.admit(OpSet::of(entry.op)) {
            // With command rules configured, an exec refused its in-flight
            // slot would resume unfollowed, with no argv read and no verdict
            // at all. The refusal already recorded its gap; the process dies
            // rather than run an unjudged exec (the `deny_exec` failure path
            // below makes the same call).
            if entry.op == ClosedOp::Exec && !self.config.commands.is_empty() {
                unsafe {
                    libc::kill(tid, libc::SIGKILL);
                }
            }
            return;
        }
        let mut pending = self.capture_paths(tid, entry, &info.args);
        pending.args.flags = flags;
        pending.flags_unavailable = flags_unavailable;
        if entry.op == ClosedOp::Exec && !self.config.commands.is_empty() {
            let argv = sys::argv(tid, info.args[if entry.name == "execveat" { 2 } else { 1 }]);
            pending.args.command = self
                .config
                .commands
                .check(
                    argv.as_deref(),
                    pending.args.path.as_ref().map(|p| p.bytes.as_slice()),
                )
                .map(Box::new);
            pending.entry_argv = argv;
            if pending.args.command.is_some() && sys::deny_exec(tid, true).is_err() {
                self.gap(GapReason::ForeignAbi, OpSet::ALL, None);
                unsafe {
                    libc::kill(tid, libc::SIGKILL);
                }
                return;
            }
        }
        self.begin(tid, InFlight::Closed(pending), site);
    }

    /// Whether a tracee is stopped at its `PTRACE_EVENT_EXIT` notification:
    /// where a thread killed at another stop stops next (J4 O-3).
    fn at_exit_notification(tid: pid_t) -> bool {
        matches!(
            sys::siginfo(tid),
            Ok((libc::SIGTRAP, code)) if code == libc::SIGTRAP | (sys::PTRACE_EVENT_EXIT << 8)
        )
    }

    /// Whether another call may be followed to its return. When the
    /// in-flight bound is reached the entry is refused, and the gap names
    /// what that call could have been.
    fn admit(&mut self, ops: OpSet) -> bool {
        if self.inflight >= self.config.inflight_max {
            self.summary.loss.inflight_rejected += 1;
            self.gap(GapReason::InflightExhausted, ops, Some(1));
            return false;
        }
        true
    }

    /// Follow `call`, which is not a closed-set call but decides what the
    /// observer can see from here on, or record what refusing it costs.
    ///
    /// Refused an in-flight slot, it runs unfollowed, and its return is the
    /// one fact that would have said whether it did anything. So the refusal
    /// costs what success would (J4 W3, loss review finding 3): a listener
    /// request is the open-ended `child_notification_listener` gap, and a
    /// `clone(CLONE_UNTRACED)` the open-ended `untraced_descendant` gap —
    /// never a one-count `inflight_exhausted` gap with an end, which would
    /// claim coverage back that the listener or the descendant can take. A
    /// foreign call is one call: `inflight_exhausted`, as for any other.
    fn follow(&mut self, tid: pid_t, call: InFlight, site: Site) {
        if self.inflight < self.config.inflight_max {
            self.begin(tid, call, site);
            return;
        }
        self.summary.loss.inflight_rejected += 1;
        match call {
            InFlight::Listener => {
                self.gap(GapReason::ChildNotificationListener, OpSet::ALL, None);
            }
            InFlight::Untraced => {
                self.gap(GapReason::UntracedDescendant, OpSet::ALL, None);
            }
            InFlight::Foreign | InFlight::Closed(_) => {
                self.gap(GapReason::InflightExhausted, call.ops(), Some(1));
            }
        }
    }

    /// Record `call`, which entered the kernel at `site`, as this thread's
    /// call in flight.
    fn begin(&mut self, tid: pid_t, call: InFlight, site: Site) {
        if self
            .tasks
            .get(&tid)
            .is_some_and(|task| task.restart.is_some())
        {
            // A new entry while a restart decision is still owed: the entry
            // stop that could have been the re-entry was judged in
            // `handle_restart_stop`, so this is out of sequence.
            self.settle_restart(tid, Verdict::Unknown);
        }
        let replaced = self
            .tasks
            .get(&tid)
            .and_then(|task| task.pending.as_ref().map(InFlight::ops));
        if let Some(ops) = replaced {
            // The previous entry for this thread never returned, and the gap
            // names the call it was (§11.4).
            self.summary.loss.abandoned_entries += 1;
            self.inflight = self.inflight.saturating_sub(1);
            self.gap(GapReason::EntryAbandoned, ops, Some(1));
        }
        if let Some(task) = self.tasks.get_mut(&tid) {
            task.pending = Some(call);
            task.site = site;
            task.entry_fresh = true;
            self.inflight += 1;
        }
    }

    /// A stop for a number the narrowing filter never traces. The trace
    /// data says whose it is: a stop carrying other data was asked for by
    /// another filter — a child's own `SECCOMP_RET_TRACE` — on a call outside
    /// the closed set, and is continued untouched (not a result, not a loss,
    /// and never decoded). One carrying this filter's own data means the
    /// program the launcher installed is not this module's, which is a gap.
    fn stop_not_ours(&mut self, tid: pid_t) {
        match sys::event_msg(tid) {
            // Audit 2026-09-25-2, S14: the expected data is this attempt's
            // own, not the public constant a child filter could echo.
            Ok(data)
                if data & u64::from(sys::SECCOMP_RET_DATA) != u64::from(self.config.trace_data) =>
            {
                self.summary.requested_by_other_filters += 1;
            }
            Ok(_) => {
                self.summary.loss.unexpected_trace_stops += 1;
                self.gap(GapReason::UnexpectedTraceStop, OpSet::ALL, Some(1));
            }
            // J4 O-3: killed at this seccomp stop; the kernel skips the call.
            Err(err) if err.raw_os_error() == Some(libc::ESRCH) => {
                self.summary.killed_at_entry += 1;
            }
            Err(_) => {
                self.summary.loss.syscall_info_unavailable += 1;
                self.gap(GapReason::SyscallInfoUnavailable, OpSet::ALL, Some(1));
            }
        }
    }

    /// A `SIGTRAP | 0x80` stop: the syscall entry or exit of a call whose
    /// entry we recorded.
    fn handle_syscall_stop(&mut self, tid: pid_t) {
        let info = match sys::syscall_info(tid) {
            Ok(info) => info,
            Err(err)
                if err.raw_os_error() == Some(libc::ESRCH)
                    && self
                        .tasks
                        .get(&tid)
                        .is_some_and(|task| task.pending.is_some()) =>
            {
                // J4 O-3, at the exit: killed after its call ran, before the
                // return could be read. The result is lost, and the entry in
                // hand is what names it: the death that follows records it
                // once, as `entry_abandoned` of that call's own classes —
                // not a second gap in every class.
                return;
            }
            Err(_) => {
                self.summary.loss.syscall_info_unavailable += 1;
                self.gap(GapReason::SyscallInfoUnavailable, OpSet::ALL, Some(1));
                return;
            }
        };
        match info.op {
            // With the narrowing filter the entry is reported as a seccomp
            // stop, so this is the entry of a call already recorded there.
            sys::SYSCALL_INFO_ENTRY => {}
            sys::SYSCALL_INFO_EXIT => self.handle_exit(tid, info.rval),
            // The tracee is not in a syscall. Nothing to pair, nothing lost.
            sys::SYSCALL_INFO_NONE => {}
            _ => {
                self.summary.loss.syscall_info_unavailable += 1;
                self.gap(GapReason::SyscallInfoUnavailable, OpSet::ALL, Some(1));
            }
        }
    }

    fn handle_exit(&mut self, tid: pid_t, mut rval: i64) {
        let tgid = self.tgid_of(tid);
        let Some(call) = self
            .tasks
            .get_mut(&tid)
            .and_then(|task| task.pending.take())
        else {
            // A syscall exit with no entry to pair it with: either the entry
            // was never seen or this thread is not one we track.
            self.summary.loss.unmatched_exits += 1;
            self.gap(GapReason::UnmatchedExit, OpSet::ALL, Some(1));
            return;
        };
        if sys::is_restart(rval) {
            // Not a result yet (J4 O-2): the kernel decides after this stop
            // whether to re-enter the call or to return EINTR, and the call
            // stays in flight until the observer has seen which.
            if let Some(task) = self.tasks.get_mut(&tid) {
                task.restart = Some(RestartWait {
                    call,
                    code: -rval,
                    site: task.site,
                    delivered: None,
                    awaiting: Awaiting::Decision,
                });
            }
            return;
        }
        self.inflight = self.inflight.saturating_sub(1);
        let mut pending = match call {
            InFlight::Closed(pending) => pending,
            InFlight::Foreign => {
                if rval == -i64::from(libc::ENOSYS) {
                    // No such call in its table, or an ABI this kernel lacks
                    // (x32 on the reference host): it had no effect, and a
                    // tracee must not be able to manufacture loss by naming
                    // a call nothing has.
                    self.summary.foreign_rejected += 1;
                } else {
                    self.summary.loss.foreign_abi += 1;
                    self.gap(GapReason::ForeignAbi, OpSet::ALL, Some(1));
                }
                return;
            }
            InFlight::Listener => {
                if rval >= 0 {
                    // The return is the listener's descriptor. From here on
                    // any closed-set call may be continued with no stop, for
                    // as long as anyone holds it: every class, no count.
                    self.summary.loss.notification_listeners += 1;
                    self.gap(GapReason::ChildNotificationListener, OpSet::ALL, None);
                } else {
                    // Refused (EBUSY under the `agent` mediation listener,
                    // EINVAL, EACCES): no listener exists, nothing is hidden.
                    self.summary.listener_refused += 1;
                }
                return;
            }
            InFlight::Untraced => {
                if rval > 0 {
                    // The return is the new task's id. Nothing traces it: not
                    // its calls (they fail with ENOSYS, a trace stop with no
                    // tracer), not its lifetime. §11.2 makes an untracked
                    // descendant a gap; how much it hides is unknown and the
                    // interval has no end.
                    self.summary.loss.untraced_descendants += 1;
                    self.gap(GapReason::UntracedDescendant, OpSet::ALL, None);
                } else {
                    self.summary.untraced_clone_refused += 1;
                }
                return;
            }
        };
        if pending.args.command.is_some() {
            if sys::deny_exec(tid, false).is_err() {
                self.gap(GapReason::ForeignAbi, OpSet::ALL, None);
                unsafe {
                    libc::kill(tid, libc::SIGKILL);
                }
                return;
            }
            rval = -i64::from(libc::EPERM);
        }
        if pending.exec_confirmed {
            // `Exec` was already emitted for this call at the confirmed
            // transition; the zero that follows is the same event.
            return;
        }
        let op = pending.entry.op;
        // J5-B2 O03 seam: when this covered call's path matches the seam
        // marker, treat its exit as unmatched — the entry might never have been
        // seen — so it becomes an `unmatched_exit` gap, never a result. The
        // in-flight slot is already released above, so this matches a genuinely
        // unmatched exit. Gated to a non-exec op.
        if op != ClosedOp::Exec
            && let Some(marker) = &self.force_unmatched_marker
            && path_has_marker(pending.args.path.as_ref(), marker)
        {
            self.summary.loss.unmatched_exits += 1;
            self.gap(GapReason::UnmatchedExit, OpSet::ALL, Some(1));
            return;
        }
        // An argument the observer could not read is only a hole in coverage
        // when the kernel could read it. When the kernel rejected the same
        // pointer or structure, there was no covered operation to miss, and
        // counting it as loss would let a tracee manufacture loss at will by
        // passing addresses that can never work.
        let rejected = rval == -i64::from(libc::EFAULT) || rval == -i64::from(libc::EINVAL);
        let mut unreadable = 0u64;
        if pending.path_unreadable {
            unreadable += 1;
        }
        if pending.path2_unreadable {
            unreadable += 1;
        }
        if unreadable > 0 {
            if rejected {
                self.summary.argument_invalid += unreadable;
            } else {
                self.summary.loss.path_unreadable += unreadable;
                self.gap(GapReason::PathUnreadable, OpSet::of(op), Some(unreadable));
            }
        }
        if pending.sockaddr_unreadable {
            if rejected {
                self.summary.argument_invalid += 1;
            } else {
                self.summary.loss.sockaddr_unreadable += 1;
                self.gap(GapReason::SockaddrUnreadable, OpSet::of(op), Some(1));
            }
        }
        if pending.flags_unavailable {
            // Without the flags, membership of the mutation set was never
            // established, so this must not be delivered as a covered open.
            // A rejected call had no covered effect to miss either.
            if rejected {
                self.summary.argument_invalid += 1;
            } else {
                self.summary.loss.flags_unavailable += 1;
                self.gap(GapReason::FlagsUnavailable, OpSet::of(op), Some(1));
            }
            return;
        }
        // Security 2026-09-25 (audit F1): the entry snapshot of pointed
        // arguments is only an assertion while the same bytes still read at
        // the exit. A thread of the tracee can rewrite `open_how.flags`, a
        // pathname or an address family between the entry stop and the
        // kernel's own copy after it, which would falsify this event's
        // classification — a mutation recorded as a read, or a path that was
        // never used. Re-read and compare; on any disagreement the event is
        // dropped and the call becomes a gap of its own classes, so the
        // receipt can never present a falsified snapshot as observed fact.
        // Register arguments need no re-read: the kernel consumes the saved
        // pt_regs, which this stop pair already saw.
        if !pending.exec_confirmed && !self.arguments_stable(tid, &pending) {
            self.summary.loss.argument_snapshot_unstable += 1;
            self.gap(GapReason::ArgumentSnapshotUnstable, OpSet::of(op), Some(1));
            return;
        }
        if op == ClosedOp::Open
            && (!self.config.learning || matches!(pending.entry.flags, FlagSource::OpenHow { .. }))
            && let Some(flags) = pending.args.flags
            && !closed_set::open_is_covered(flags)
        {
            // A memory-sourced read-only `openat2` followed for verification
            // (audit 2026-09-25-2, S1). Security 2026-09-27 (audit 3 A1):
            // the exit re-read agreeing with the entry snapshot does NOT
            // prove the kernel applied these flags — a thread of the tracee
            // can flip `open_how.flags` for the kernel's own copy and
            // restore them before this stop (an A-B-A rewrite), which this
            // observer cannot tell apart. The verdict is therefore not
            // certifiable: the call is counted, but it is also a gap of its
            // own classes, never a silent filter. Register-sourced flags
            // are immune (the kernel consumes the saved `pt_regs`) and keep
            // their entry-time read-only skip.
            self.summary.filtered_readonly_opens += 1;
            self.summary.loss.memory_flags_unverified += 1;
            self.gap(GapReason::MemoryFlagsUnverified, OpSet::of(op), Some(1));
            return;
        }
        // Security 2026-09-29 (audit 6 N1): byte stability is not
        // certification for a pathname either — a sibling thread can
        // rewrite the buffer for the kernel's own copy and restore it
        // before the exit re-read, the same A-B-A rewrite the flags gap
        // above names. A successful open hands the observer one kernel
        // fact: the descriptor's own `/proc/<tid>/fd/<ret>` link, resolved
        // by the kernel for the file it actually opened. When it
        // corroborates the snapshot ([`path_corroborated`]) the claim
        // stands; otherwise (an unreadable link, or a disagreement a
        // symlink, a pipe or a rename could also explain) the claim is
        // downgraded to an incomplete path, counted, and named by a
        // bookkeeping gap, so a receipt never certifies a pathname the
        // kernel may not have used. The call and its event are kept — no
        // result is missing — so this never degrades a class or stops a
        // strict run: failures of this check only weaken, never accuse.
        if op == ClosedOp::Open
            && rval >= 0
            && let Some(snapshot) = pending.args.path.as_mut()
            && snapshot.complete
        {
            let tmpfile = pending
                .args
                .flags
                .is_some_and(|flags| flags & (libc::O_TMPFILE as u64) == libc::O_TMPFILE as u64);
            let corroborated = self.procfs.fd_link(tid, rval).is_some_and(|resolved| {
                // Audit 7 L7: the kernel's ` (deleted)` annotation can
                // also be a live file's literal name, so when the raw
                // link carries it the descriptor's link count — read
                // while the tracee is stopped — must agree the file is
                // truly unlinked.
                let nlink = if resolved.ends_with(b" (deleted)") {
                    self.procfs.fd_nlink(tid, rval)
                } else {
                    None
                };
                path_corroborated(&snapshot.bytes, &resolved, tmpfile, nlink)
            });
            if !corroborated {
                self.summary.path_claims_unverified += 1;
                self.gap(GapReason::PathClaimUnverified, OpSet::EMPTY, Some(1));
                snapshot.complete = false;
            }
        }
        self.summary.ops.bump(op);
        let start_ticks = self.birth_of(tgid);
        self.emit(TracerEvent::Syscall {
            pid: tgid,
            start_ticks,
            tid,
            op,
            syscall: pending.entry.name,
            args: pending.args,
            ret: rval,
            monotonic_ns: clock::boottime_ns(),
        });
    }

    /// Whether the pointed arguments this event asserts still read at the
    /// syscall exit as they read at the entry stop (audit F1).
    ///
    /// The kernel consumes pointed arguments *after* the entry stop resumes,
    /// re-reading the same user memory the observer snapshotted; a thread of
    /// the tracee can rewrite it in that window. At the exit stop the kernel
    /// has finished with the memory, so a re-read that agrees with the entry
    /// snapshot is the strongest check a passive observer can make, and any
    /// disagreement — including memory that can no longer be read — means the
    /// snapshot may not be what the kernel applied. Only what the event
    /// asserts is checked: register arguments (immutable between the stops),
    /// incomplete path snapshots (already carried as weaker assertions) and
    /// addresses whose family was never read need no re-read.
    fn arguments_stable(&mut self, tid: pid_t, pending: &Pending) -> bool {
        let raw = pending.raw;
        if let FlagSource::OpenHow { ptr, .. } = pending.entry.flags {
            let mut word = [0u8; 8];
            if sys::read_remote(tid, raw[ptr as usize], &mut word) != 8 {
                return false;
            }
            if pending.args.flags != Some(u64::from_ne_bytes(word)) {
                return false;
            }
        }
        for (index, snapshot) in [
            pending.entry.path.map(|i| (i, pending.args.path.as_ref())),
            pending
                .entry
                .path2
                .map(|i| (i, pending.args.path2.as_ref())),
        ]
        .into_iter()
        .flatten()
        {
            let Some(snapshot) = snapshot else { continue };
            if !snapshot.complete || raw[index as usize] == 0 {
                // An incomplete snapshot already carries its weaker claim,
                // and no complete snapshot was ever read from a null pointer.
                continue;
            }
            if !self.path_unchanged(tid, raw[index as usize], &snapshot.bytes) {
                return false;
            }
        }
        if let Some((ptr, _len)) = pending.entry.sockaddr
            && let Some(snapshot) = pending.args.sockaddr.as_ref()
            && snapshot.complete
            && let Some(family) = snapshot.family
        {
            let mut word = [0u8; 2];
            if sys::read_remote(tid, raw[ptr as usize], &mut word) != 2 {
                return false;
            }
            if family != u16::from_ne_bytes(word) {
                return false;
            }
        }
        true
    }

    /// Compare exactly the captured bytes and their terminating NUL. No
    /// allocation or read of unrelated bytes beyond that terminator is needed.
    /// Partial reads are retried; an unreadable byte or changed terminator is
    /// still instability, including a formerly empty pathname becoming nonempty.
    fn path_unchanged(&mut self, tid: pid_t, addr: u64, expected: &[u8]) -> bool {
        if addr == 0 || expected.len() >= self.config.path_snapshot_max {
            return false;
        }
        let length = expected.len() + 1;
        let mut offset = 0;
        while offset < length {
            let Some(at) = addr.checked_add(offset as u64) else {
                return false;
            };
            let want = (length - offset)
                .min(self.scratch.len())
                .min(4096 - (at % 4096) as usize);
            let read = sys::read_remote(tid, at, &mut self.scratch[..want]);
            if read == 0 {
                return false;
            }
            for (index, byte) in self.scratch[..read].iter().enumerate() {
                if *byte != expected.get(offset + index).copied().unwrap_or(0) {
                    return false;
                }
            }
            offset += read;
        }
        true
    }

    // ------------------------------------------------ restart decisions (O-2)

    /// A stop of a thread whose last call exited with a restart code and is
    /// waiting for the kernel's decision ([`RestartWait`]). Returns the
    /// signal to deliver when this stop is fully handled here; `None` hands
    /// it on to the ordinary handling, after settling the wait if the stop
    /// settles it.
    fn handle_restart_stop(
        &mut self,
        tid: pid_t,
        signal: libc::c_int,
        event: libc::c_int,
    ) -> Option<libc::c_int> {
        let (code, site, delivered, awaiting) = {
            let wait = self.tasks.get(&tid)?.restart.as_ref()?;
            (wait.code, wait.site, wait.delivered, wait.awaiting)
        };
        if event == sys::PTRACE_EVENT_SECCOMP {
            // The thread's next entry. Stepped since the exit, no user
            // instruction ran before it, so only the kernel's re-entry can
            // be here; let run since a handler's entry, it is the re-entry
            // only if it is at the call's own site. Either way it is judged
            // here, and then handled as ever.
            let seen = Self::entry_stop(tid);
            self.judge_entry_stop(tid, seen);
            return None;
        }
        if awaiting != Awaiting::Decision {
            // Waiting for the re-entry while the handler runs: signals,
            // group-stops, forks and the thread's exit are handled as ever,
            // and the wait goes on.
            return None;
        }
        match event {
            // A group-stop, or the thread's exit: the decision is still
            // ahead, or never comes. Handled as ever; the thread keeps
            // stepping. An exec reported under this id is another thread's,
            // which destroyed this one: `exec_transition` ends the wait.
            sys::PTRACE_EVENT_STOP | sys::PTRACE_EVENT_EXIT | sys::PTRACE_EVENT_EXEC => None,
            0 if signal != sys::SYSCALL_STOP_SIG => {
                if signal == libc::SIGTRAP {
                    if let Some(uc) =
                        delivered.and_then(|sig| self.handler_entry(tid, sig, site.ip, site.ip + 4))
                    {
                        // The kernel has set up a handler and settled the
                        // call. This notification is not a signal: nothing
                        // is delivered for it.
                        let frame = Self::read_frame(tid, uc);
                        match verdict_at_handler(code, frame, site) {
                            Verdict::Restarted => {
                                // Believed at the re-entry itself (R1).
                                if let Some(wait) =
                                    self.tasks.get_mut(&tid).and_then(|t| t.restart.as_mut())
                                {
                                    wait.awaiting = Awaiting::Reentry {
                                        by_kernel: code == sys::ERESTARTNOINTR,
                                    };
                                }
                            }
                            verdict => self.settle_restart(tid, verdict),
                        }
                        return Some(0);
                    }
                    if Self::is_step_trap(tid) {
                        // A step that ended in user space without a re-entry
                        // or a handler: the continuation ran through
                        // `restart_syscall`, or a code reached user space.
                        // The trap is this observer's own, not the tracee's.
                        self.settle_restart(tid, Verdict::Unknown);
                        return Some(0);
                    }
                }
                // A signal on its way: deliver it, still stepping, so the
                // handler it may run announces itself.
                if let Some(wait) = self.tasks.get_mut(&tid).and_then(|t| t.restart.as_mut()) {
                    wait.delivered = Some(signal);
                }
                Some(signal)
            }
            // A syscall stop, a fork or an exec: not a stop this sequence
            // produces. Settled as unknown, then handled as ever.
            _ => {
                self.settle_restart(tid, Verdict::Unknown);
                None
            }
        }
    }

    /// The `ucontext` of the signal frame the kernel has just set up, when
    /// the stop is the notification of a handler's entry to a single-stepped
    /// tracee: `si_code` is the notification's own, then the native register
    /// reader verifies the delivered signal and locates the kernel frame.
    /// An ordinary signal-delivery stop is not this handler-entry stop.
    fn handler_entry(
        &mut self,
        tid: pid_t,
        delivered: libc::c_int,
        site_ip: u64,
        next_ip: u64,
    ) -> Option<u64> {
        let (signo, code) = sys::siginfo(tid).ok()?;
        if signo != libc::SIGTRAP || code != sys::SI_CODE_HANDLER_ENTRY {
            return None;
        }
        sys::handler_ucontext(tid, u64::try_from(delivered).ok()?, site_ip, next_ip).ok()?
    }

    /// The interrupted result register and PC the kernel saved in the frame
    /// whose `ucontext` is at `uc`.
    fn read_frame(tid: pid_t, uc: u64) -> Option<(u64, u64)> {
        let mut word = [0u8; 8];
        let mut read = |offset: u64| {
            (sys::read_remote(tid, uc.checked_add(offset)?, &mut word) == 8)
                .then(|| u64::from_ne_bytes(word))
        };
        let ax = read(sys::FRAME_RESULT)?;
        let ip = read(sys::FRAME_IP)?;
        Some((ax, ip))
    }

    /// Whether a `SIGTRAP` stop is a trap this observer's stepping raised.
    fn is_step_trap(tid: pid_t) -> bool {
        matches!(
            sys::siginfo(tid),
            Ok((libc::SIGTRAP, sys::TRAP_TRACE | sys::TRAP_BRKPT))
        )
    }

    /// What the entry stop `tid` is at shows.
    fn entry_stop(tid: pid_t) -> EntryStop {
        match sys::syscall_info(tid) {
            Ok(info)
                if info.op == sys::SYSCALL_INFO_SECCOMP || info.op == sys::SYSCALL_INFO_ENTRY =>
            {
                EntryStop::At(Site {
                    arch: info.arch,
                    nr: info.nr,
                    ip: info.ip,
                    arg0: info.args[0],
                })
            }
            // Left this stop without being resumed, which only a SIGKILL does
            // (J4 O-3): on its way out, or already at its exit notification.
            Err(err) if err.raw_os_error() == Some(libc::ESRCH) => EntryStop::Killed,
            Ok(_) if Self::at_exit_notification(tid) => EntryStop::Killed,
            _ => EntryStop::Unreadable,
        }
    }

    /// Judge an entry stop of a thread whose restart wait is still open.
    fn judge_entry_stop(&mut self, tid: pid_t, seen: EntryStop) {
        let Some((site, awaiting)) = self
            .tasks
            .get(&tid)
            .and_then(|task| task.restart.as_ref())
            .map(|wait| (wait.site, wait.awaiting))
        else {
            return;
        };
        match (seen, awaiting) {
            (EntryStop::At(at), _) if at == site => self.settle_restart(tid, Verdict::Restarted),
            // Killed at the re-entry, which the kernel now skips (J4 O-3):
            // stepped here, it can only be the re-entry; let run, it is taken
            // as one only when the kernel alone decided the restart. The call
            // is counted once, as killed at its entry, by `handle_entry` —
            // not a second time as a restart that never finished (J4 W3,
            // tracer review R2).
            (EntryStop::Killed, Awaiting::Decision | Awaiting::Reentry { by_kernel: true }) => {
                if self
                    .tasks
                    .get_mut(&tid)
                    .and_then(|task| task.restart.take())
                    .is_some()
                {
                    self.inflight = self.inflight.saturating_sub(1);
                }
            }
            _ => self.settle_restart(tid, Verdict::Unknown),
        }
    }

    /// Settle a thread's restart wait with `verdict`.
    fn settle_restart(&mut self, tid: pid_t, verdict: Verdict) {
        let Some(wait) = self
            .tasks
            .get_mut(&tid)
            .and_then(|task| task.restart.take())
        else {
            return;
        };
        match verdict {
            Verdict::Restarted => {
                // The re-entered call is a new entry with its own slot.
                self.inflight = self.inflight.saturating_sub(1);
                self.summary.restarts += 1;
            }
            Verdict::Interrupted => {
                // The call's result is EINTR, delivered as any other result
                // (which also releases its slot).
                self.summary.interrupted += 1;
                if let Some(task) = self.tasks.get_mut(&tid) {
                    task.pending = Some(wait.call);
                    task.site = wait.site;
                }
                self.handle_exit(tid, -i64::from(libc::EINTR));
            }
            Verdict::Unknown => {
                self.inflight = self.inflight.saturating_sub(1);
                self.summary.loss.restart_unresolved += 1;
                self.gap(GapReason::RestartUnresolved, wait.call.ops(), Some(1));
            }
        }
    }

    /// A restart wait whose thread ended — died, or was destroyed by another
    /// thread's `execve` — before the wait was settled. Before the kernel's
    /// decision the call did nothing and returned nothing, and so after a
    /// restart the kernel alone decided: neither a result nor a loss. After
    /// a restart read from the frame, the `EINTR` the program may have seen
    /// was never observed: a gap (J4 W3, R1).
    fn restart_ended(&mut self, wait: RestartWait) {
        self.inflight = self.inflight.saturating_sub(1);
        match wait.awaiting {
            Awaiting::Decision | Awaiting::Reentry { by_kernel: true } => {
                self.summary.restarts_unfinished += 1;
            }
            Awaiting::Reentry { by_kernel: false } => {
                self.summary.loss.restart_unresolved += 1;
                self.gap(GapReason::RestartUnresolved, wait.call.ops(), Some(1));
            }
        }
    }

    fn handle_death(&mut self, pid: pid_t, status: libc::c_int) {
        let Some(task) = self.tasks.remove(&pid) else {
            if self.retired.remove(&pid).is_some() {
                // A thread the kernel destroyed at a non-leader exec.
                return;
            }
            if self.procfs.tgid(pid).is_some() {
                // A tracee reported dead before its first stop: under ptrace
                // it stays in /proc as a zombie only its real parent can
                // reap, while a genuinely untraced direct child was reaped
                // by this very wait and is already gone. The fork event that
                // names it is still in flight; nothing it did was observed
                // to be lost, so this is a race to count, not a child exit
                // to report and not a gap (§11.4).
                self.summary.late_fork_races += 1;
                self.tracee_deaths.insert(pid, Instant::now() + KILL_GRACE);
                return;
            }
            // J5-T: the backend's exit is the one the tracer owes; any other
            // child's is delivered all the same, and is not the tree's.
            if let Owed::Backend {
                pid: backend,
                reaped,
                ..
            } = &mut self.owed
                && *backend == pid
            {
                *reaped = true;
            }
            self.summary.untraced_child_exits += 1;
            self.emit(TracerEvent::UntracedChildExit { pid, status });
            return;
        };
        self.summary.reaped_tasks += 1;
        if let Some(pending) = task.pending {
            // The entry can no longer return, and the gap names the call it
            // was, because the entry is in hand (§11.4).
            self.inflight = self.inflight.saturating_sub(1);
            self.summary.loss.abandoned_entries += 1;
            self.gap(GapReason::EntryAbandoned, pending.ops(), Some(1));
        }
        if let Some(wait) = task.restart {
            // Died while its restart was owed (a fatal signal's delivery is
            // exactly such a decision point).
            self.restart_ended(wait);
        }
        let Some(process) = self.procs.get_mut(&task.tgid) else {
            // A task whose thread group we no longer hold: its death cannot
            // be attributed, so it is a hole rather than a silent drop.
            self.summary.loss.death_unattributed += 1;
            self.gap(
                GapReason::DeathUnattributed,
                OpSet::of(ClosedOp::Exec),
                Some(1),
            );
            return;
        };
        process.threads.remove(&pid);
        if !process.threads.is_empty() {
            // A worker thread exited. That is not the death of a process.
            return;
        }
        let process = self.procs.remove(&task.tgid).expect("just borrowed");
        if !process.witnessed_exec {
            // §11.2: a fork child that never execs is tracked for scope and
            // lifetime and emits no public `proc.exit`.
            return;
        }
        if !process.identity_known {
            self.summary.loss.death_unattributed += 1;
            self.gap(
                GapReason::DeathUnattributed,
                OpSet::of(ClosedOp::Exec),
                Some(1),
            );
            return;
        }
        if pid != task.tgid {
            // Invariant: the kernel delays a group leader's report until its
            // last thread is gone (`delay_group_leader`), so the last reap in
            // a thread group is always the leader's. Reaching this branch
            // would mean that guarantee did not hold, and §11.2 forbids
            // presenting a worker's status as the process's.
            self.summary.loss.final_status_unknown += 1;
            self.gap(
                GapReason::FinalStatusUnknown,
                OpSet::of(ClosedOp::Exec),
                None,
            );
            return;
        }
        self.summary.exits += 1;
        self.emit(TracerEvent::Exit {
            pid: task.tgid,
            start_ticks: process.birth,
            status,
            monotonic_ns: clock::boottime_ns(),
        });
    }

    // ---------------------------------------------------------- arguments

    /// The flags word of a row, and whether flags the consumer needs for
    /// classification could not be decoded.
    fn capture_flags(
        &mut self,
        tid: pid_t,
        entry: &'static Entry,
        raw: &[u64; 6],
    ) -> (Option<u64>, bool) {
        match entry.flags {
            FlagSource::None => (None, false),
            FlagSource::Arg(index) => (Some(raw[index as usize]), false),
            FlagSource::ImpliedCreat => (Some(closed_set::implied_creat_flags()), false),
            FlagSource::OpenHow { ptr, size } => {
                // `open_how` is { u64 flags; u64 mode; u64 resolve; }. A
                // caller that passes a smaller size gets EINVAL from the
                // kernel and gives us nothing to decode.
                const OPEN_HOW_VER0: u64 = 24;
                if raw[size as usize] < OPEN_HOW_VER0 {
                    return (None, true);
                }
                let mut word = [0u8; 8];
                if sys::read_remote(tid, raw[ptr as usize], &mut word) == 8 {
                    (Some(u64::from_ne_bytes(word)), false)
                } else {
                    (None, true)
                }
            }
        }
    }

    /// Read the pathnames, directory fds and socket address the row names.
    fn capture_paths(&mut self, tid: pid_t, entry: &'static Entry, raw: &[u64; 6]) -> Pending {
        let mut args = Args::default();
        let mut path_unreadable = false;
        let mut path2_unreadable = false;
        let mut sockaddr_unreadable = false;
        if let Some(index) = entry.path {
            let (snapshot, unreadable) = self.read_path(tid, raw[index as usize]);
            args.path = snapshot;
            path_unreadable = unreadable;
        }
        // J5-B2 O03 seam: force this covered call's path to be
        // kernel-accepted-but-unreadable — the truncation case O03 names —
        // when its path matches the seam marker. Gated to a non-exec op (an
        // exec never returns to the normal exit path where a `path_unreadable`
        // gap is emitted). When the call then succeeds it becomes a
        // `path_unreadable` gap.
        if entry.op != ClosedOp::Exec
            && let Some(marker) = &self.force_truncate_marker
            && path_has_marker(args.path.as_ref(), marker)
        {
            args.path = Some(PathSnapshot {
                bytes: Vec::new(),
                complete: false,
            });
            path_unreadable = true;
        }
        if let Some(index) = entry.path2 {
            let (snapshot, unreadable) = self.read_path(tid, raw[index as usize]);
            args.path2 = snapshot;
            path2_unreadable = unreadable;
        }
        if let Some(index) = entry.dirfd {
            args.dirfd = Some(raw[index as usize] as i32);
        }
        if let Some(index) = entry.dirfd2 {
            args.dirfd2 = Some(raw[index as usize] as i32);
        }
        // Issue draft 12: a relative pathname the kernel resolves against
        // the thread's own cwd is resolved against that cwd at
        // classification; the snapshot itself stays the raw argument, so the
        // exit-side stability check compares what the tracee still holds.
        args.cwd = Self::observed_cwd(tid, args.path.as_ref(), args.path2.as_ref());
        if let Some((ptr, len)) = entry.sockaddr {
            let (snapshot, unreadable) =
                self.read_sockaddr(tid, raw[ptr as usize], raw[len as usize]);
            args.sockaddr = snapshot;
            sockaddr_unreadable = unreadable;
        }
        Pending {
            entry,
            args,
            exec_confirmed: false,
            path_unreadable,
            path2_unreadable,
            sockaddr_unreadable,
            flags_unavailable: false,
            raw: *raw,
            entry_argv: None,
        }
    }

    /// The stopped thread's working directory, read from `/proc/<tid>/cwd`,
    /// when one of the call's path arguments is a complete relative pathname
    /// the kernel resolves against it (issue draft 12). The true dirfd cases
    /// resolve against their descriptor instead and read nothing.
    fn observed_cwd(
        tid: pid_t,
        path: Option<&PathSnapshot>,
        path2: Option<&PathSnapshot>,
    ) -> Option<Box<[u8]>> {
        use std::os::unix::ffi::OsStringExt as _;
        let relative = |snapshot: Option<&PathSnapshot>| {
            snapshot.is_some_and(|snapshot| {
                snapshot.complete && snapshot.bytes.first().is_some_and(|byte| *byte != b'/')
            })
        };
        if !relative(path) && !relative(path2) {
            return None;
        }
        std::fs::read_link(format!("/proc/{tid}/cwd"))
            .ok()
            .map(|link| link.into_os_string().into_vec().into_boxed_slice())
            .filter(|bytes| bytes.first() == Some(&b'/'))
    }
    /// A NUL-terminated pathname argument, bounded by `path_snapshot_max`.
    ///
    /// `complete` is false when the bytes ran out before a NUL or when the
    /// tracee's memory could not be read: §11.3 wants the weaker assertion
    /// carried in band, not a shorter path presented as the whole one. The
    /// second return says nothing was readable at all, which the syscall exit
    /// classifies once the kernel's own verdict on the same pointer is known.
    fn read_path(&mut self, tid: pid_t, addr: u64) -> (Option<PathSnapshot>, bool) {
        if addr == 0 {
            return (None, false);
        }
        let max = self.config.path_snapshot_max;
        let mut bytes: Vec<u8> = Vec::new();
        while bytes.len() < max {
            let offset = bytes.len();
            let at = addr.wrapping_add(offset as u64);
            let chunk_size = if offset == 0 { 256 } else { self.scratch.len() };
            let want = (max - offset)
                .min(chunk_size)
                .min(4096 - (at % 4096) as usize);
            let read = sys::read_remote(tid, at, &mut self.scratch[..want]);
            if read == 0 {
                if bytes.is_empty() {
                    return (
                        Some(PathSnapshot {
                            bytes,
                            complete: false,
                        }),
                        true,
                    );
                }
                self.summary.loss.path_truncated += 1;
                return (
                    Some(PathSnapshot {
                        bytes,
                        complete: false,
                    }),
                    false,
                );
            }
            let chunk = &self.scratch[..read];
            if let Some(end) = chunk.iter().position(|b| *b == 0) {
                bytes.extend_from_slice(&chunk[..end]);
                return (
                    Some(PathSnapshot {
                        bytes,
                        complete: true,
                    }),
                    false,
                );
            }
            bytes.extend_from_slice(chunk);
        }
        self.summary.loss.path_truncated += 1;
        (
            Some(PathSnapshot {
                bytes,
                complete: false,
            }),
            false,
        )
    }

    /// The `sockaddr` of a `connect`, as far as the closed set describes it.
    ///
    /// The address bytes are read — the family's own size, never the length
    /// the caller declared, which is a claim and not a fact — only to decide
    /// whether the whole address was readable, and are not retained: the
    /// record names the family and the completeness of the claim, and §11.1
    /// forbids collecting argument memory nothing downstream will ever see.
    /// For a family the set does not name, only the family is read.
    fn read_sockaddr(
        &mut self,
        tid: pid_t,
        addr: u64,
        len: u64,
    ) -> (Option<SockaddrSnapshot>, bool) {
        if addr == 0 {
            return (None, false);
        }
        let unknown = SockaddrSnapshot {
            family: None,
            complete: false,
        };
        if len < 2 {
            // The kernel rejects this too; there is no family to read.
            return (Some(unknown), false);
        }
        if sys::read_remote(tid, addr, &mut self.scratch[..2]) < 2 {
            return (Some(unknown), true);
        }
        let family = u16::from_ne_bytes([self.scratch[0], self.scratch[1]]);
        let Some(family_len) = sockaddr_len(family, len) else {
            return (
                Some(SockaddrSnapshot {
                    family: Some(family),
                    complete: false,
                }),
                false,
            );
        };
        let want = family_len.min(self.scratch.len());
        let read = sys::read_remote(tid, addr, &mut self.scratch[..want]);
        (
            Some(SockaddrSnapshot {
                family: Some(family),
                // Complete means the whole address of this family was read
                // and the caller declared at least that much, which
                // `sockaddr_len` has already bounded by the claim.
                complete: read == want,
            }),
            read == 0,
        )
    }

    // ---------------------------------------------------------- shutdown

    fn finish(mut self, handles: &Handles) -> TracerSummary {
        // Direct children that were never reaped have no route left for
        // their exit status: the supervisor was told not to wait for its own
        // children while a tracer is attached. J5-T: only those it answers
        // for — the backend and any child gained after it attached; a child
        // it was attached beside is its owner's to wait for once this ends.
        let unreaped: Vec<pid_t> = match self.owed {
            Owed::Every => proc::children(sys::getpid())
                .into_iter()
                .filter(|pid| !self.tasks.contains_key(pid))
                .collect(),
            Owed::Backend {
                pid,
                birth,
                reaped: false,
            } if self.still_there(pid, birth) => {
                std::iter::once(pid).chain(self.adopted()).collect()
            }
            Owed::Backend { .. } | Owed::Nothing => self.adopted(),
        };
        if !unreaped.is_empty() {
            self.summary.loss.unreaped_children += unreaped.len() as u64;
            self.gap(
                GapReason::UnreapedChildren,
                OpSet::EMPTY,
                Some(unreaped.len() as u64),
            );
            self.summary.unreaped_children = unreaped;
        }
        self.materialise_gap();
        let finished = TracerEvent::Finished;
        let bytes = event_bytes(&finished);
        self.enqueue(finished, bytes, true);

        // Hand over the backlog. Nothing is stopped behind it, so this waits
        // for a consumer that is slow; `finish` ends it at once by setting
        // the stop flag, and what is still undelivered is in the summary.
        let deadline = Instant::now() + TERMINAL_DRAIN;
        loop {
            self.flush();
            if self.pending.is_empty() || self.disconnected {
                break;
            }
            if Instant::now() >= deadline || handles.stop.load(Ordering::Acquire) {
                break;
            }
            std::thread::sleep(TERMINAL_POLL);
        }
        if !self.pending.is_empty() {
            self.summary.loss.lifecycle_dropped += self.pending.len() as u64;
        }
        self.summary
    }
}

/// How many bytes of a `sockaddr` belong to its family, bounded by what the
/// caller declared. This is what is read to decide whether the whole address
/// was readable, and no more than that is ever touched. `None` for a family
/// the closed set does not name.
fn sockaddr_len(family: u16, declared: u64) -> Option<usize> {
    let size = match i32::from(family) {
        libc::AF_INET => 16,
        libc::AF_INET6 => 28,
        // `sockaddr_un` is 110 bytes; an abstract or short name uses less,
        // and only the caller's length says how much of it is the name.
        libc::AF_UNIX => 110,
        _ => return None,
    };
    Some(size.min(usize::try_from(declared).unwrap_or(usize::MAX)))
}

#[cfg(test)]
mod tests {
    use super::super::EVENT_FIXED_BYTES;
    use super::sockaddr_len;
    use super::*;

    /// A session whose consumer never reads: the handoff holds one event.
    fn stalled_session() -> (Session, std::sync::mpsc::Receiver<TracerEvent>) {
        let (tx, rx) = std::sync::mpsc::sync_channel(1);
        let config = TracerConfig {
            queue_bytes_max: 64 * 1024 * 1024,
            ..TracerConfig::default()
        };
        (
            Session::new(config, tx, Arc::default(), 0, Box::new(LiveProc)),
            rx,
        )
    }

    #[test]
    fn path_reads_preserve_page_boundaries_long_names_and_terminator_checks() {
        let (mut session, _rx) = stalled_session();
        let pid = std::process::id() as pid_t;
        // Page-aligned, live memory followed by a deliberately unreadable page.
        // SAFETY: anonymous mapping; every access below stays in its first page.
        let memory = unsafe {
            libc::mmap(
                std::ptr::null_mut(),
                8192,
                libc::PROT_READ | libc::PROT_WRITE,
                libc::MAP_PRIVATE | libc::MAP_ANONYMOUS,
                -1,
                0,
            )
        };
        assert_ne!(memory, libc::MAP_FAILED);
        struct Mapping(*mut libc::c_void);
        impl Drop for Mapping {
            fn drop(&mut self) {
                // SAFETY: this test owns the entire mapping until drop.
                unsafe {
                    libc::munmap(self.0, 8192);
                }
            }
        }
        let mapping = Mapping(memory);
        // SAFETY: the second page is inside the mapping and has no Rust refs.
        assert_eq!(
            unsafe { libc::mprotect(memory.add(4096), 4096, libc::PROT_NONE) },
            0
        );
        // SAFETY: the first page remains writable and is exclusively owned.
        let page = unsafe { std::slice::from_raw_parts_mut(mapping.0.cast::<u8>(), 4096) };
        for length in [0, 1, 255, 256, 257, 1024, 4095] {
            let start = 4095 - length;
            page[start..4095].fill(b'x');
            page[4095] = 0;
            let addr = page[start..].as_ptr() as u64;
            let expected = vec![b'x'; length];
            let (snapshot, unreadable) = session.read_path(pid, addr);
            let snapshot = snapshot.unwrap();
            assert!(!unreadable && snapshot.complete);
            assert_eq!(snapshot.bytes, expected);
            assert!(session.path_unchanged(pid, addr, &expected));
            page[4095] = b'y';
            assert!(
                !session.path_unchanged(pid, addr, &expected),
                "changed NUL at length {length}"
            );
            let (snapshot, _) = session.read_path(pid, addr);
            assert!(
                !snapshot.unwrap().complete,
                "no terminator before unreadable memory"
            );
        }
        assert!(!session.path_unchanged(pid, 0, b""));
        assert!(!session.path_unchanged(pid, u64::MAX, b"x"));
    }

    /// Security 2026-09-25 (audit F1): the exit re-read of pointed
    /// arguments. A snapshot that still reads at the exit is stable; one
    /// whose memory changed (or can no longer be read) is not, and its event
    /// must become an `argument_snapshot_unstable` gap. Verified against
    /// this very process's memory, which `read_remote` can read.
    #[test]
    fn pointed_arguments_are_reverified_at_the_exit() {
        let (mut session, _rx) = stalled_session();
        let entry = closed_set::lookup(u64::from(crate::platform::linux::abi::nr(257, 56)))
            .expect("openat");
        let mut path = b"/workspace/file.txt\0".to_vec();
        let addr = path.as_ptr() as u64;
        let mut raw = [0u64; 6];
        raw[1] = addr; // pathname
        raw[2] = 0; // O_RDONLY, as a register argument
        let pending = Pending {
            entry,
            args: Args {
                path: Some(PathSnapshot {
                    bytes: b"/workspace/file.txt".to_vec(),
                    complete: true,
                }),
                flags: Some(0),
                ..Args::default()
            },
            exec_confirmed: false,
            path_unreadable: false,
            path2_unreadable: false,
            sockaddr_unreadable: false,
            flags_unavailable: false,
            raw,
            entry_argv: None,
        };
        let self_pid = std::process::id() as pid_t;
        assert!(
            session.arguments_stable(self_pid, &pending),
            "unchanged memory is stable"
        );
        path[4] = b'X';
        assert!(
            !session.arguments_stable(self_pid, &pending),
            "a rewritten pathname is unstable"
        );
        path[4] = b's';
        raw[1] = 1; // an address nothing can read
        let mut unreadable = pending.clone();
        unreadable.raw = raw;
        assert!(
            !session.arguments_stable(self_pid, &unreadable),
            "unreadable memory is unstable"
        );
        let zero = Pending {
            raw: [0; 6],
            ..pending
        };
        assert!(
            session.arguments_stable(self_pid, &zero),
            "a null pointer asserted nothing to re-read"
        );
    }

    /// Security 2026-09-25-2 (audit S1): an `openat2` classified read-only
    /// at its entry is followed to its exit, where the flags are re-read.
    /// Security 2026-09-27 (audit 3 A1): even stable read-only flags cannot
    /// be certified — an A-B-A rewrite satisfies both reads — so the call is
    /// counted AND recorded as a `memory_flags_unverified` gap of its
    /// classes, never a silent filter; flags rewritten between the two
    /// kernel reads remain an `argument_snapshot_unstable` gap.
    #[test]
    fn a_readonly_openat2_is_reverified_at_its_exit() {
        let (mut session, rx) = stalled_session();
        let entry = closed_set::lookup(437).expect("openat2");
        let mut how: u64 = 0; // O_RDONLY, as the kernel would read it
        let mut raw = [0u64; 6];
        raw[1] = c"path".as_ptr() as u64;
        raw[2] = &mut how as *const u64 as u64; // struct open_how *
        raw[3] = 24; // size
        let pending = Pending {
            entry,
            args: Args {
                flags: Some(0),
                ..Args::default()
            },
            exec_confirmed: false,
            path_unreadable: false,
            path2_unreadable: false,
            sockaddr_unreadable: false,
            flags_unavailable: false,
            raw,
            entry_argv: None,
        };
        let self_pid = std::process::id() as pid_t;
        session.tasks.insert(
            self_pid,
            Task {
                tgid: self_pid,
                start_ticks: None,
                pending: Some(InFlight::Closed(pending.clone())),
                site: Site {
                    arch: sys::AUDIT_ARCH,
                    nr: 437,
                    ip: 0,
                    arg0: 0,
                },
                entry_fresh: false,
                restart: None,
            },
        );
        session.handle_exit(self_pid, 3);
        assert_eq!(
            session.summary.filtered_readonly_opens, 1,
            "stable read-only flags are counted"
        );
        assert_eq!(
            session.summary.loss.memory_flags_unverified, 1,
            "a stable verdict on memory flags is still uncertifiable"
        );
        match rx.try_recv() {
            Ok(TracerEvent::Gap {
                reason: GapReason::MemoryFlagsUnverified,
                ..
            }) => {}
            other => panic!("expected a memory_flags_unverified gap, got {other:?}"),
        }
        how = libc::O_WRONLY as u64 | libc::O_CREAT as u64;
        assert_ne!(how, 0, "the raced value is what the kernel will apply");
        session.tasks.get_mut(&self_pid).unwrap().pending = Some(InFlight::Closed(pending));
        session.handle_exit(self_pid, 3);
        assert_eq!(
            session.summary.loss.argument_snapshot_unstable, 1,
            "rewritten flags are an unstable gap"
        );
        assert_eq!(
            session.summary.filtered_readonly_opens, 1,
            "the raced call never counts as filtered"
        );
    }

    /// Security 2026-09-25-2 (audit S1), mutation-B10 guard: the entry
    /// filter never takes an `openat2`, whatever its flags claim — its
    /// verdict is memory-sourced and only the exit re-read may certify it —
    /// while a read-only `open`/`openat` (register-sourced) is the entry
    /// fast path and is counted as filtered.
    #[test]
    fn the_entry_filter_never_takes_a_readonly_openat2() {
        let (mut session, _rx) = stalled_session();
        let openat2 = closed_set::lookup(437).expect("openat2");
        let openat = closed_set::lookup(u64::from(crate::platform::linux::abi::nr(257, 56)))
            .expect("openat");
        assert!(
            !session.filter_readonly_open_at_entry(openat2),
            "an openat2 is always followed to its exit (audit 2026-09-25-2 S1)"
        );
        assert_eq!(
            session.summary.filtered_readonly_opens, 0,
            "the followed call is not counted as filtered either"
        );
        assert!(
            session.filter_readonly_open_at_entry(openat),
            "a register-sourced read-only open is the entry fast path"
        );
        assert_eq!(session.summary.filtered_readonly_opens, 1);
    }

    /// Mutation-M02 guard: the REAL unmatched-exit branch of
    /// `handle_exit` — a syscall exit with no entry to pair (the O03.2
    /// seam's manufactured gap is this same shape, but the branch here is
    /// reached without the seam) — counts the loss and records one
    /// `unmatched_exit` gap over every class. Both shapes reach it: a
    /// thread this tracer tracks whose entry was never seen, and one it
    /// does not track at all.
    #[test]
    fn an_exit_with_no_entry_is_one_unmatched_exit_gap() {
        let (mut session, rx) = stalled_session();
        // A tracked thread whose pending entry is gone: the entry was
        // never seen for this exit.
        let pid = std::process::id() as pid_t;
        session.tasks.insert(
            pid,
            Task {
                tgid: pid,
                start_ticks: None,
                pending: None,
                site: Site {
                    arch: sys::AUDIT_ARCH,
                    nr: 257,
                    ip: 0,
                    arg0: 0,
                },
                entry_fresh: false,
                restart: None,
            },
        );
        session.handle_exit(pid, 0);
        assert_eq!(
            session.summary.loss.unmatched_exits, 1,
            "the tracked-but-unentered exit is counted"
        );
        match rx.try_recv() {
            Ok(TracerEvent::Gap {
                reason: GapReason::UnmatchedExit,
                count: Some(1),
                ..
            }) => {}
            other => panic!("expected one unmatched_exit gap, got {other:?}"),
        }
        // A thread this tracer does not track at all: the same branch, and
        // the count and the gap are not swallowed by the first.
        session.handle_exit(pid.wrapping_add(1 << 20), 0);
        assert_eq!(
            session.summary.loss.unmatched_exits, 2,
            "the untracked exit is counted too"
        );
        match rx.try_recv() {
            Ok(TracerEvent::Gap {
                reason: GapReason::UnmatchedExit,
                count: Some(1),
                ..
            }) => {}
            other => panic!("expected a second unmatched_exit gap, got {other:?}"),
        }
    }

    fn fork(child: pid_t) -> TracerEvent {
        TracerEvent::Fork {
            parent: 1,
            parent_tid: 1,
            child,
            is_thread: false,
            child_start_ticks: None,
            monotonic_ns: 0,
        }
    }

    /// J4 D6, at the unit level: with the lifecycle count full, a gap is not
    /// dropped but merged into its reason's summary (so a child that causes
    /// one per syscall cannot grow the backlog), an exit is admitted past
    /// the cap, and the summaries are delivered ahead of it.
    #[test]
    fn j4_d6_gaps_past_the_caps_are_coalesced_and_exits_admitted() {
        let (mut session, rx) = stalled_session();
        let mut child = 2;
        while session.lifecycle_pending < LIFECYCLE_MAX {
            session.emit(fork(child));
            child += 1;
        }
        let queued = session.pending.len();
        session.emit(fork(child));
        assert_eq!(
            session.summary.loss.lifecycle_dropped, 1,
            "a fork is not critical"
        );
        for i in 0..10_000u64 {
            let reason = if i % 2 == 0 {
                GapReason::UnexpectedTraceStop
            } else {
                GapReason::PathUnreadable
            };
            session.gap(reason, OpSet::ALL, Some(1));
        }
        assert_eq!(
            session.pending.len(),
            queued,
            "gaps past the cap wait in their summaries, not in the backlog"
        );
        assert_eq!(
            session.summary.loss.lifecycle_dropped, 1,
            "no gap was dropped"
        );
        session.emit(TracerEvent::Exit {
            pid: 1,
            start_ticks: None,
            status: 0,
            monotonic_ns: 0,
        });
        let tail: Vec<&TracerEvent> = session
            .pending
            .iter()
            .skip(queued)
            .map(|queued| &queued.event)
            .collect();
        assert_eq!(tail.len(), 4, "{tail:?}");
        let counts: Vec<(GapReason, Option<u64>)> = tail
            .iter()
            .filter_map(|event| match event {
                TracerEvent::Gap { reason, count, .. } => Some((*reason, *count)),
                _ => None,
            })
            .collect();
        assert!(counts.contains(&(GapReason::UnexpectedTraceStop, Some(5_000))));
        assert!(counts.contains(&(GapReason::PathUnreadable, Some(5_000))));
        assert!(matches!(tail[3], TracerEvent::Exit { pid: 1, .. }));
        assert_eq!(
            session.summary.loss.lifecycle_dropped, 1,
            "the exit was admitted"
        );
        drop(rx);
    }

    /// The byte budget is a cap too: with it full, an exit is still admitted
    /// and a gap still coalesced.
    #[test]
    fn j4_d6_the_byte_budget_does_not_drop_critical_facts_either() {
        let (tx, _rx) = std::sync::mpsc::sync_channel(1);
        let config = TracerConfig {
            queue_bytes_max: 4 * EVENT_FIXED_BYTES,
            ..TracerConfig::default()
        };
        let mut session = Session::new(config, tx, Arc::default(), 0, Box::new(LiveProc));
        for child in 2..100 {
            session.emit(fork(child));
        }
        assert!(
            session.summary.loss.lifecycle_dropped > 0,
            "the budget is full"
        );
        let dropped = session.summary.loss.lifecycle_dropped;
        session.gap(GapReason::UnexpectedTraceStop, OpSet::ALL, Some(1));
        session.emit(TracerEvent::Exit {
            pid: 1,
            start_ticks: None,
            status: 0,
            monotonic_ns: 0,
        });
        assert_eq!(session.summary.loss.lifecycle_dropped, dropped);
        assert!(session.pending.iter().any(|queued| matches!(
            queued.event,
            TracerEvent::Gap {
                reason: GapReason::UnexpectedTraceStop,
                ..
            }
        )));
        assert!(
            session
                .pending
                .iter()
                .any(|queued| matches!(queued.event, TracerEvent::Exit { pid: 1, .. }))
        );
    }

    /// `/proc` as a test scripts it: `tid -> (tgid, start ticks)`.
    struct ScriptedProc(std::sync::Arc<std::sync::Mutex<HashMap<pid_t, (pid_t, u64)>>>);

    impl ProcView for ScriptedProc {
        fn tgid(&self, tid: pid_t) -> Option<pid_t> {
            self.0.lock().unwrap().get(&tid).map(|(tgid, _)| *tgid)
        }
        fn start_ticks(&self, tid: pid_t) -> Option<u64> {
            self.0.lock().unwrap().get(&tid).map(|(_, ticks)| *ticks)
        }
        /// A script has no children: the test binary's real ones are other
        /// tests' business.
        fn children(&self, _pid: pid_t) -> Vec<pid_t> {
            Vec::new()
        }
    }

    /// A pid no real task can have (above `PID_MAX_LIMIT`), so the ptrace
    /// calls the handlers make on it fail with ESRCH and touch nothing.
    const RECYCLED: pid_t = 5_000_001;
    const WORKER: pid_t = 5_000_002;

    fn pend(session: &mut Session, tid: pid_t, nr: u64, path: &str) {
        let entry = closed_set::lookup(nr).expect("a closed-set row");
        let task = session.tasks.get_mut(&tid).expect("a registered task");
        task.pending = Some(InFlight::Closed(Pending {
            entry,
            args: Args {
                path: Some(PathSnapshot {
                    bytes: path.as_bytes().to_vec(),
                    complete: true,
                }),
                ..Args::default()
            },
            exec_confirmed: false,
            path_unreadable: false,
            path2_unreadable: false,
            sockaddr_unreadable: false,
            flags_unavailable: false,
            raw: [0; 6],
            entry_argv: None,
        }));
        session.inflight += 1;
    }

    fn drained(
        rx: &std::sync::mpsc::Receiver<TracerEvent>,
        session: &mut Session,
    ) -> Vec<TracerEvent> {
        session.flush();
        let mut out = Vec::new();
        while let Ok(event) = rx.try_recv() {
            out.push(event);
            session.flush();
        }
        out
    }

    /// J4 O02, S1: a tid the kernel recycles for a new task after the old
    /// one was reaped. The stock reference host will not let an
    /// unprivileged test choose a pid (`ns_last_pid`, `clone3 set_tid` and a
    /// namespace's `pid_max` all need `CAP_SYS_ADMIN` there), so the seam
    /// over the two `/proc` reads plays it. Every event names the birth its
    /// process had when the tracer took it on: a worker's result names its
    /// leader's birth, not the worker's own, even when the worker is the
    /// first task of the group the tracer sees; the old process's exec, result
    /// and exit name the old birth; the new task under the same number names
    /// its own, inherits no witnessed exec (so its death is no `Exit`) and
    /// no entry in flight.
    #[test]
    fn j4_o02_recycled_tid_carries_nothing_over() {
        let table = std::sync::Arc::new(std::sync::Mutex::new(HashMap::new()));
        let (tx, rx) = std::sync::mpsc::sync_channel(1024);
        let mut session = Session::new(
            TracerConfig::default(),
            tx,
            Arc::default(),
            0,
            Box::new(ScriptedProc(std::sync::Arc::clone(&table))),
        );
        table.lock().unwrap().insert(RECYCLED, (RECYCLED, 1000));
        table.lock().unwrap().insert(WORKER, (RECYCLED, 1500));
        // The worker's first stop arrives before anything of its leader's:
        // the group is taken on through the worker, and is still named by
        // its leader's birth, not by the worker's own.
        session.register(WORKER);
        session.register(RECYCLED);
        pend(
            &mut session,
            WORKER,
            u64::from(crate::platform::linux::abi::nr(83, 34)),
            "/w/by-worker",
        );
        session.handle_exit(WORKER, 0);
        session.handle_death(WORKER, 0);
        session.handle_exec(RECYCLED);
        pend(
            &mut session,
            RECYCLED,
            u64::from(crate::platform::linux::abi::nr(83, 34)),
            "/w/old",
        );
        session.handle_exit(RECYCLED, 0);
        session.handle_death(RECYCLED, 0);
        // Reaped: the kernel may now give the number to a new task.
        table.lock().unwrap().insert(RECYCLED, (RECYCLED, 2000));
        session.register(RECYCLED);
        pend(
            &mut session,
            RECYCLED,
            u64::from(crate::platform::linux::abi::nr(87, 35)),
            "/w/new",
        );
        session.handle_exit(RECYCLED, -i64::from(libc::ENOENT));
        session.handle_death(RECYCLED, libc::SIGKILL);
        let events = drained(&rx, &mut session);
        let seen: Vec<(String, Option<u64>)> = events
            .iter()
            .map(|event| match event {
                TracerEvent::Exec {
                    pid, start_ticks, ..
                } => (format!("exec {pid}"), *start_ticks),
                TracerEvent::Syscall {
                    pid,
                    tid,
                    syscall,
                    start_ticks,
                    ..
                } => (format!("{syscall} {pid}/{tid}"), *start_ticks),
                TracerEvent::Exit {
                    pid, start_ticks, ..
                } => (format!("exit {pid}"), *start_ticks),
                other => (format!("{other:?}"), None),
            })
            .collect();
        let mkdir = if cfg!(target_arch = "aarch64") {
            "mkdirat"
        } else {
            "mkdir"
        };
        let unlink = if cfg!(target_arch = "aarch64") {
            "unlinkat"
        } else {
            "unlink"
        };
        assert_eq!(
            seen,
            vec![
                (format!("{mkdir} {RECYCLED}/{WORKER}"), Some(1000)),
                (format!("exec {RECYCLED}"), Some(1000)),
                (format!("{mkdir} {RECYCLED}/{RECYCLED}"), Some(1000)),
                (format!("exit {RECYCLED}"), Some(1000)),
                (format!("{unlink} {RECYCLED}/{RECYCLED}"), Some(2000)),
            ],
            "the new task under the old number never execed: no second exit"
        );
        assert_eq!(
            session.summary.loss.total(),
            0,
            "{:?}",
            session.summary.loss
        );
        assert_eq!(session.inflight, 0, "no entry carried over");
        assert!(session.tasks.is_empty() && session.procs.is_empty());
    }

    /// J4 S4 at the session: a `clone(CLONE_UNTRACED)` that created a task
    /// is a gap in every class with no count; one that failed is nothing.
    #[test]
    fn j4_s4_an_untraced_descendant_is_a_gap_and_a_failed_clone_is_not() {
        let table = std::sync::Arc::new(std::sync::Mutex::new(HashMap::new()));
        table.lock().unwrap().insert(RECYCLED, (RECYCLED, 1000));
        let (tx, rx) = std::sync::mpsc::sync_channel(64);
        let mut session = Session::new(
            TracerConfig::default(),
            tx,
            Arc::default(),
            0,
            Box::new(ScriptedProc(std::sync::Arc::clone(&table))),
        );
        session.register(RECYCLED);
        session.begin(RECYCLED, InFlight::Untraced, Site::default());
        session.handle_exit(RECYCLED, -i64::from(libc::EPERM));
        assert_eq!(session.summary.untraced_clone_refused, 1);
        session.begin(RECYCLED, InFlight::Untraced, Site::default());
        session.handle_exit(RECYCLED, 4242);
        let gaps: Vec<(GapReason, OpSet, Option<u64>)> = drained(&rx, &mut session)
            .into_iter()
            .filter_map(|event| match event {
                TracerEvent::Gap {
                    reason, ops, count, ..
                } => Some((reason, ops, count)),
                _ => None,
            })
            .collect();
        assert_eq!(
            gaps,
            vec![(GapReason::UntracedDescendant, OpSet::ALL, None)]
        );
        assert_eq!(session.summary.loss.untraced_descendants, 1);
        assert!(GapReason::UntracedDescendant.is_open_ended());
        assert_eq!(
            GapReason::UntracedDescendant.as_str(),
            "untraced_descendant"
        );
    }

    // ------------------------------------------------ O-2, the decision

    /// J4 O-2: the kernel's rule at a handler's entry, for every restart
    /// code. Only `ERESTARTSYS` depends on the frame, and only the two frames
    /// the kernel writes for it are accepted.
    #[test]
    fn j4_o2_the_verdict_at_a_handler_follows_the_kernel_for_every_code() {
        let site = Site {
            arch: sys::AUDIT_ARCH,
            nr: 257,
            ip: 0x40_1002,
            arg0: 257,
        };
        let eintr = (-i64::from(libc::EINTR)) as u64;
        let restarted = Some((
            257,
            site.ip - if cfg!(target_arch = "aarch64") { 4 } else { 2 },
        ));
        let interrupted = Some((eintr, 0x40_1002));
        for frame in [None, restarted, interrupted] {
            assert_eq!(
                verdict_at_handler(sys::ERESTARTNOINTR, frame, site),
                Verdict::Restarted,
                "ERESTARTNOINTR is re-entered whatever the handler"
            );
            for code in [sys::ERESTARTNOHAND, sys::ERESTART_RESTARTBLOCK] {
                assert_eq!(
                    verdict_at_handler(code, frame, site),
                    Verdict::Interrupted,
                    "{code} becomes EINTR under any handler"
                );
            }
        }
        assert_eq!(
            verdict_at_handler(sys::ERESTARTSYS, interrupted, site),
            Verdict::Interrupted,
            "no SA_RESTART"
        );
        assert_eq!(
            verdict_at_handler(sys::ERESTARTSYS, restarted, site),
            Verdict::Restarted,
            "SA_RESTART"
        );
        for frame in [
            None,
            Some((257, 0x40_1002)),
            Some((eintr, 0x40_1000)),
            Some((0, 0x40_1002)),
            Some((258, 0x40_1000)),
            Some((eintr, 0x40_2002)),
        ] {
            assert_eq!(
                verdict_at_handler(sys::ERESTARTSYS, frame, site),
                Verdict::Unknown,
                "{frame:x?} is not a frame the kernel wrote for this call"
            );
        }
        assert_eq!(
            verdict_at_handler(515, interrupted, site),
            Verdict::Unknown,
            "515 is not a restart code"
        );
    }

    fn waiting(session: &mut Session, tid: pid_t, nr: u64, path: &str) {
        pend(session, tid, nr, path);
        session.handle_exit(tid, -sys::ERESTARTSYS);
    }

    /// J4 O-2 at the session: a restart code keeps the call in flight; each
    /// way the wait ends gives exactly what it should — `EINTR` one result,
    /// a re-entry nothing (the re-entered call is its own entry), an
    /// unresolved decision one gap naming the call's classes, a death
    /// nothing — and every one releases the slot.
    #[test]
    fn j4_o2_each_end_of_a_restart_wait_is_exact() {
        let table = std::sync::Arc::new(std::sync::Mutex::new(HashMap::new()));
        table.lock().unwrap().insert(RECYCLED, (RECYCLED, 1000));
        let (tx, rx) = std::sync::mpsc::sync_channel(64);
        let mut session = Session::new(
            TracerConfig::default(),
            tx,
            Arc::default(),
            0,
            Box::new(ScriptedProc(std::sync::Arc::clone(&table))),
        );
        session.register(RECYCLED);

        waiting(
            &mut session,
            RECYCLED,
            libc::SYS_openat as u64,
            "/w/interrupted",
        );
        assert_eq!(session.inflight, 1, "still in flight while waiting");
        assert!(drained(&rx, &mut session).is_empty(), "no result yet");
        session.settle_restart(RECYCLED, Verdict::Interrupted);
        let events = drained(&rx, &mut session);
        assert!(
            matches!(
                events.as_slice(),
                [TracerEvent::Syscall { op: ClosedOp::Open, ret, .. }] if *ret == -i64::from(libc::EINTR)
            ),
            "{events:?}"
        );
        assert_eq!(session.inflight, 0);

        waiting(
            &mut session,
            RECYCLED,
            u64::from(crate::platform::linux::abi::nr(83, 34)),
            "/w/restarted",
        );
        session.settle_restart(RECYCLED, Verdict::Restarted);
        assert!(drained(&rx, &mut session).is_empty());
        assert_eq!(session.inflight, 0);

        waiting(
            &mut session,
            RECYCLED,
            u64::from(crate::platform::linux::abi::nr(83, 34)),
            "/w/unknown",
        );
        session.settle_restart(RECYCLED, Verdict::Unknown);
        let events = drained(&rx, &mut session);
        assert!(
            matches!(
                events.as_slice(),
                [TracerEvent::Gap { reason: GapReason::RestartUnresolved, ops, count: Some(1), .. }]
                    if *ops == OpSet::of(ClosedOp::Mkdir)
            ),
            "{events:?}"
        );
        assert_eq!(session.inflight, 0);

        waiting(
            &mut session,
            RECYCLED,
            u64::from(crate::platform::linux::abi::nr(83, 34)),
            "/w/died",
        );
        session.handle_death(RECYCLED, libc::SIGKILL);
        assert!(drained(&rx, &mut session).is_empty(), "no result, no gap");
        assert_eq!(session.inflight, 0);

        assert_eq!(session.summary.interrupted, 1);
        assert_eq!(session.summary.restarts, 1);
        assert_eq!(session.summary.restarts_unfinished, 1);
        assert_eq!(session.summary.loss.restart_unresolved, 1);
        assert_eq!(
            session.summary.loss.total(),
            1,
            "{:?}",
            session.summary.loss
        );
        assert_eq!(GapReason::RestartUnresolved.as_str(), "restart_unresolved");
        assert!(!GapReason::RestartUnresolved.is_open_ended());
    }

    // ------------------------------------------------ J4 wave 3

    fn scripted(
        config: TracerConfig,
        tasks: &[(pid_t, pid_t)],
    ) -> (Session, std::sync::mpsc::Receiver<TracerEvent>) {
        let table = std::sync::Arc::new(std::sync::Mutex::new(HashMap::new()));
        for (tid, tgid) in tasks {
            table.lock().unwrap().insert(*tid, (*tgid, 1000));
        }
        let (tx, rx) = std::sync::mpsc::sync_channel(64);
        let mut session = Session::new(
            config,
            tx,
            Arc::default(),
            0,
            Box::new(ScriptedProc(std::sync::Arc::clone(&table))),
        );
        for (tid, _) in tasks {
            session.register(*tid);
        }
        (session, rx)
    }

    /// A handler's entry has just said "restarted": by the frame, or by the
    /// restart code alone.
    fn announced(session: &mut Session, tid: pid_t, by_kernel: bool) {
        waiting(session, tid, libc::SYS_openat as u64, "/w/fifo");
        let wait = session
            .tasks
            .get_mut(&tid)
            .and_then(|task| task.restart.as_mut())
            .expect("a restart wait");
        wait.awaiting = Awaiting::Reentry { by_kernel };
    }

    /// J4 W3, tracer review R1, at the session: a restart read at a
    /// handler's entry is settled by what the thread does next. Its
    /// re-entry at the same site: restarted, no result of its own and no
    /// loss. Any other entry: one `restart_unresolved` gap of the call's
    /// classes. Its end: nothing when the restart code alone decided
    /// (`ERESTARTNOINTR`), a gap when the frame did. Killed at an entry
    /// stop that cannot be read: taken as the re-entry only when the code
    /// decided. Every end releases the slot.
    #[test]
    fn j4_w3_r1_a_restart_read_at_a_handler_is_settled_by_what_follows() {
        let open = OpSet::of(ClosedOp::Open);
        type Step = fn(&mut Session);
        let die: Step = |session| session.handle_death(RECYCLED, 0);
        let reenter: Step =
            |session| session.judge_entry_stop(RECYCLED, EntryStop::At(Site::default()));
        let other: Step = |session| {
            session.judge_entry_stop(
                RECYCLED,
                EntryStop::At(Site {
                    nr: 83,
                    ..Site::default()
                }),
            );
        };
        let killed: Step = |session| session.judge_entry_stop(RECYCLED, EntryStop::Killed);
        let unreadable: Step = |session| session.judge_entry_stop(RECYCLED, EntryStop::Unreadable);
        let gap = vec![(GapReason::RestartUnresolved, open, Some(1))];
        type Gaps = Vec<(GapReason, OpSet, Option<u64>)>;
        // (label, decided by the code alone, what follows, the gaps, restarts,
        // restarts unfinished)
        type Case = (&'static str, bool, Step, Gaps, u64, u64);
        let cases: [Case; 10] = [
            ("frame, re-entry", false, reenter, vec![], 1, 0),
            ("code, re-entry", true, reenter, vec![], 1, 0),
            ("frame, another entry", false, other, gap.clone(), 0, 0),
            ("code, another entry", true, other, gap.clone(), 0, 0),
            (
                "frame, unreadable entry",
                false,
                unreadable,
                gap.clone(),
                0,
                0,
            ),
            ("frame, death", false, die, gap.clone(), 0, 0),
            ("code, death", true, die, vec![], 0, 1),
            (
                "frame, killed at an entry",
                false,
                killed,
                gap.clone(),
                0,
                0,
            ),
            ("code, killed at an entry", true, killed, vec![], 0, 0),
            (
                "code, killed then death",
                true,
                |session| {
                    session.judge_entry_stop(RECYCLED, EntryStop::Killed);
                    session.handle_death(RECYCLED, 0);
                },
                vec![],
                0,
                0,
            ),
        ];
        for (label, by_kernel, step, gaps, restarts, unfinished) in cases {
            let (mut session, rx) = scripted(TracerConfig::default(), &[(RECYCLED, RECYCLED)]);
            announced(&mut session, RECYCLED, by_kernel);
            assert_eq!(session.inflight, 1, "{label}: still in flight");
            step(&mut session);
            let events = drained(&rx, &mut session);
            assert_eq!(gaps_of(&events), gaps, "{label}: {events:?}");
            assert!(
                !events
                    .iter()
                    .any(|e| matches!(e, TracerEvent::Syscall { .. })),
                "{label}: never a result: {events:?}"
            );
            assert_eq!(session.summary.restarts, restarts, "{label}");
            assert_eq!(session.summary.restarts_unfinished, unfinished, "{label}");
            assert_eq!(session.inflight, 0, "{label}: the slot is released");
        }
    }

    /// R1 through the stepping phase is unchanged: a re-entry seen while
    /// stepping — no handler ran — is the kernel's own, and a kill there
    /// counts the call once (R2), as killed at its entry.
    #[test]
    fn j4_w3_r2_a_kill_at_a_stepped_reentry_ends_the_wait_without_a_count() {
        let (mut session, rx) = scripted(TracerConfig::default(), &[(RECYCLED, RECYCLED)]);
        waiting(&mut session, RECYCLED, libc::SYS_openat as u64, "/w/fifo");
        session.judge_entry_stop(RECYCLED, EntryStop::Killed);
        session.handle_death(RECYCLED, libc::SIGKILL);
        assert!(drained(&rx, &mut session).is_empty());
        assert_eq!(session.summary.restarts_unfinished, 0);
        assert_eq!(session.summary.restarts, 0);
        assert_eq!(session.inflight, 0);
    }

    const LEADER: pid_t = 5_000_011;
    const PEER: pid_t = 5_000_012;

    /// J4 W3, loss review finding 1, at the session: after a non-leader
    /// exec the leader's entry is abandoned — a gap of its own classes —
    /// whether the thread that execed carried its own entry or had none
    /// (refused an in-flight slot), and nothing is left on the leader's id
    /// that the exec's syscall exit could be paired with. A restart the
    /// leader owed ends as its death would.
    #[test]
    fn j4_w3_a_non_leader_exec_abandons_the_leaders_entry_whatever_was_carried() {
        for carried in [false, true] {
            let (mut session, rx) =
                scripted(TracerConfig::default(), &[(LEADER, LEADER), (PEER, LEADER)]);
            pend(&mut session, LEADER, libc::SYS_openat as u64, "/w/fifo");
            if carried {
                pend(&mut session, PEER, libc::SYS_execve as u64, "/bin/image");
            }
            session.exec_transition(LEADER, PEER);
            let events = drained(&rx, &mut session);
            assert_eq!(
                gaps_of(&events),
                vec![(
                    GapReason::EntryAbandoned,
                    OpSet::of(ClosedOp::Open),
                    Some(1)
                )],
                "carried {carried}: {events:?}"
            );
            let exec_path = events.iter().find_map(|event| match event {
                TracerEvent::Exec { pid, path, .. } => Some((*pid, path.clone())),
                _ => None,
            });
            let leader = session
                .tasks
                .get(&LEADER)
                .expect("the leader's id lives on");
            if carried {
                assert!(
                    matches!(
                        leader.pending,
                        Some(InFlight::Closed(Pending {
                            exec_confirmed: true,
                            ..
                        }))
                    ),
                    "the carried execve is the one entry left"
                );
                assert_eq!(session.inflight, 1);
                assert_eq!(
                    exec_path.map(|(pid, path)| (pid, path.map(|p| p.bytes))),
                    Some((LEADER, Some(b"/bin/image".to_vec())))
                );
            } else {
                assert!(leader.pending.is_none(), "nothing to pair the exit with");
                assert_eq!(session.inflight, 0);
                assert_eq!(exec_path, Some((LEADER, None)));
            }
            assert!(!session.tasks.contains_key(&PEER));
            assert_eq!(session.summary.loss.abandoned_entries, 1);
        }
        for (by_kernel, gaps) in [
            (
                false,
                vec![(
                    GapReason::RestartUnresolved,
                    OpSet::of(ClosedOp::Open),
                    Some(1),
                )],
            ),
            (true, vec![]),
        ] {
            let (mut session, rx) =
                scripted(TracerConfig::default(), &[(LEADER, LEADER), (PEER, LEADER)]);
            announced(&mut session, LEADER, by_kernel);
            session.exec_transition(LEADER, PEER);
            let events = drained(&rx, &mut session);
            assert_eq!(gaps_of(&events), gaps, "by kernel {by_kernel}: {events:?}");
            assert_eq!(session.inflight, 0);
            assert!(session.tasks[&LEADER].restart.is_none());
        }
    }

    /// J4 W3, loss review finding 3, at the session: refused an in-flight
    /// slot, a listener request and an untraced clone cost the open-ended
    /// gap of their kind; a foreign call is one call.
    #[test]
    fn j4_w3_a_refused_listener_or_untraced_clone_is_the_open_ended_gap_of_its_kind() {
        let (mut session, rx) = scripted(
            TracerConfig {
                inflight_max: 1,
                ..TracerConfig::default()
            },
            &[(LEADER, LEADER), (PEER, LEADER)],
        );
        pend(&mut session, LEADER, libc::SYS_openat as u64, "/w/fifo");
        session.follow(PEER, InFlight::Listener, Site::default());
        session.follow(PEER, InFlight::Untraced, Site::default());
        session.follow(PEER, InFlight::Foreign, Site::default());
        assert_eq!(
            gaps_of(&drained(&rx, &mut session)),
            vec![
                (GapReason::ChildNotificationListener, OpSet::ALL, None),
                (GapReason::UntracedDescendant, OpSet::ALL, None),
                (GapReason::InflightExhausted, OpSet::ALL, Some(1)),
            ]
        );
        assert_eq!(session.summary.loss.inflight_rejected, 3);
        assert!(session.tasks[&PEER].pending.is_none());
        assert_eq!(session.inflight, 1);
    }

    /// J4 W3, loss review finding 4, at the session: what was handed to the
    /// channel and not taken counts against the budget, and taking it gives
    /// the bytes back.
    #[test]
    fn j4_w3_the_handoff_channel_is_inside_the_byte_budget() {
        let (tx, rx) = std::sync::mpsc::sync_channel(64);
        let handed = Arc::new(AtomicUsize::new(0));
        let config = TracerConfig {
            queue_bytes_max: 4 * EVENT_FIXED_BYTES,
            ..TracerConfig::default()
        };
        let mut session = Session::new(config, tx, Arc::clone(&handed), 0, Box::new(LiveProc));
        for child in 2..20 {
            session.emit(fork(child));
        }
        assert_eq!(
            handed.load(Ordering::Relaxed),
            4 * EVENT_FIXED_BYTES,
            "four events fit, all of them already in the channel"
        );
        assert_eq!(session.pending.len(), 0);
        assert_eq!(session.summary.loss.lifecycle_dropped, 14);
        assert!(session.summary.queue_bytes_peak <= 4 * EVENT_FIXED_BYTES);
        let events = super::super::Events::new(rx, Arc::clone(&handed));
        while events.try_recv().is_ok() {}
        assert_eq!(handed.load(Ordering::Relaxed), 0, "taken, and given back");
        session.emit(fork(99));
        assert_eq!(session.summary.loss.lifecycle_dropped, 14, "room again");
    }

    #[test]
    fn relative_syscall_cwd_counts_against_admission_and_handoff_credit() {
        let (tx, rx) = std::sync::mpsc::sync_channel(64);
        let handed = Arc::new(AtomicUsize::new(0));
        let charge = EVENT_FIXED_BYTES + 512;
        let config = TracerConfig {
            queue_bytes_max: 64 * 1024 + 2 * charge,
            ..TracerConfig::default()
        };
        let mut session = Session::new(config, tx, Arc::clone(&handed), 0, Box::new(LiveProc));
        let syscall = || TracerEvent::Syscall {
            pid: 1,
            start_ticks: None,
            tid: 1,
            op: ClosedOp::Open,
            syscall: "openat",
            args: super::super::Args {
                cwd: Some(vec![b'x'; 512].into_boxed_slice()),
                ..Default::default()
            },
            ret: 3,
            monotonic_ns: 0,
        };
        session.emit(syscall());
        session.emit(syscall());
        assert_eq!(handed.load(Ordering::Relaxed), 2 * charge);
        // Skip the already-tested backpressure wait: a stalled consumer
        // must immediately refuse the third retained working directory.
        session.stalled = true;
        session.emit(syscall());
        assert_eq!(session.summary.loss.queue_dropped, 1);
        assert_eq!(handed.load(Ordering::Relaxed), 2 * charge);
        let events = super::super::Events::new(rx, Arc::clone(&handed));
        assert!(matches!(
            events.try_recv().unwrap(),
            TracerEvent::Syscall { .. }
        ));
        assert_eq!(handed.load(Ordering::Relaxed), charge);
        assert!(matches!(
            events.try_recv().unwrap(),
            TracerEvent::Syscall { .. }
        ));
        assert_eq!(handed.load(Ordering::Relaxed), 0);
        session.emit(syscall());
        assert_eq!(
            session.summary.loss.queue_dropped, 1,
            "credit frees room again"
        );
        while events.try_recv().is_ok() {}
        assert_eq!(handed.load(Ordering::Relaxed), 0);
    }

    // ------------------------------------------------ O-3, with a real kernel

    /// A child of this test, seized by the calling thread, that has the
    /// narrowing filter installed and makes one `mkdir` of `path` when
    /// released (or, from [`Mkdirer::start_open`], one `openat(path,
    /// O_WRONLY)`): its first stop is that call's seccomp entry stop.
    struct Mkdirer {
        pid: pid_t,
        go: libc::c_int,
    }

    impl Mkdirer {
        /// `None` when this host will not let a test trace its own child.
        fn start(path: &std::ffi::CStr) -> Option<Mkdirer> {
            Mkdirer::start_call(path, false)
        }

        /// The same child making `openat(path, O_WRONLY)`: on a FIFO nobody
        /// reads, it sleeps inside the call.
        fn start_open(path: &std::ffi::CStr) -> Option<Mkdirer> {
            Mkdirer::start_call(path, true)
        }

        fn start_call(path: &std::ffi::CStr, open: bool) -> Option<Mkdirer> {
            let mut fds: [libc::c_int; 2] = [0; 2];
            // SAFETY: `pipe2` writes two descriptors into the live array.
            assert_eq!(unsafe { libc::pipe2(fds.as_mut_ptr(), libc::O_CLOEXEC) }, 0);
            // SAFETY: the child runs only async-signal-safe code — `close`,
            // the allocation-free filter install, `read`, one raw syscall
            // with a pointer prepared before the fork, and `_exit` — so the
            // other threads of this test process cannot matter to it.
            let pid = unsafe { libc::fork() };
            if pid == 0 {
                // SAFETY: as above; every pointer is live in the child's copy
                // of this address space.
                unsafe {
                    libc::close(fds[1]);
                    if super::super::install_narrowing_filter().is_err() {
                        libc::_exit(3);
                    }
                    let mut byte = 0u8;
                    libc::read(fds[0], (&raw mut byte).cast::<libc::c_void>(), 1);
                    if open {
                        libc::syscall(
                            libc::SYS_openat,
                            libc::AT_FDCWD,
                            path.as_ptr(),
                            libc::O_WRONLY | libc::O_CLOEXEC,
                        );
                    } else {
                        // J5-D: `mkdir` has no syscall of its own off x86_64;
                        // the test only runs where the tracer does, but it
                        // must compile for every Linux target.
                        #[cfg(target_arch = "x86_64")]
                        libc::syscall(libc::SYS_mkdir, path.as_ptr(), 0o700);
                        #[cfg(not(target_arch = "x86_64"))]
                        libc::syscall(libc::SYS_mkdirat, libc::AT_FDCWD, path.as_ptr(), 0o700);
                    }
                    libc::_exit(0);
                }
            }
            assert!(pid > 0, "fork: {}", std::io::Error::last_os_error());
            // SAFETY: the read end belongs to the child now.
            unsafe { libc::close(fds[0]) };
            let child = Mkdirer { pid, go: fds[1] };
            if let Err(err) = sys::seize(pid, sys::SEIZE_OPTIONS) {
                ouro_fixture::harness::skip_or_fail(&format!(
                    "this host will not let a test trace its own child: {err}"
                ));
                return None;
            }
            Some(child)
        }

        /// Release the child and return the status of its first stop.
        fn release(&self) -> libc::c_int {
            // SAFETY: one byte from a live buffer to a descriptor we own.
            assert_eq!(
                unsafe { libc::write(self.go, b"g".as_ptr().cast::<libc::c_void>(), 1) },
                1
            );
            self.wait()
        }

        /// The next status of this child only: never `waitpid(-1)`, which
        /// would take another test's children.
        fn wait(&self) -> libc::c_int {
            let mut status = 0;
            // SAFETY: `waitpid` writes one int through a live pointer.
            let got = unsafe { libc::waitpid(self.pid, &raw mut status, libc::__WALL) };
            assert_eq!(got, self.pid, "{}", std::io::Error::last_os_error());
            status
        }

        fn kill(&self) {
            // SAFETY: a pid this test created, and a valid signal.
            assert_eq!(unsafe { libc::kill(self.pid, libc::SIGKILL) }, 0);
        }

        /// Hand every remaining status to the session until the child is
        /// reaped.
        fn reap_into(&self, session: &mut Session) {
            loop {
                let status = self.wait();
                session.handle(self.pid, status);
                if libc::WIFEXITED(status) || libc::WIFSIGNALED(status) {
                    return;
                }
            }
        }
    }

    impl Drop for Mkdirer {
        fn drop(&mut self) {
            // SAFETY: our own pid and descriptor; both calls tolerate either
            // being already gone.
            unsafe {
                libc::kill(self.pid, libc::SIGKILL);
                libc::close(self.go);
            }
        }
    }

    fn live_session() -> (Session, std::sync::mpsc::Receiver<TracerEvent>) {
        let (tx, rx) = std::sync::mpsc::sync_channel(1024);
        (
            Session::new(
                TracerConfig::default(),
                tx,
                Arc::default(),
                0,
                Box::new(LiveProc),
            ),
            rx,
        )
    }

    fn is_seccomp_stop(status: libc::c_int) -> bool {
        libc::WIFSTOPPED(status) && (status >> 16) & 0xff == sys::PTRACE_EVENT_SECCOMP
    }

    fn gaps_of(events: &[TracerEvent]) -> Vec<(GapReason, OpSet, Option<u64>)> {
        events
            .iter()
            .filter_map(|event| match event {
                TracerEvent::Gap {
                    reason, ops, count, ..
                } => Some((*reason, *ops, *count)),
                _ => None,
            })
            .collect()
    }

    /// Security 2026-09-27 (audit 4 B2): the compat-ABI spellings of the
    /// listener and untraced-clone requests reach their own classifications,
    /// and everything else foreign stays `None` (the plain foreign path).
    #[test]
    fn audit4_compat_abi_listener_and_untraced_clone_route_to_their_gaps() {
        use crate::platform::linux::tracer::filter as tfilter;
        let kind = |of: Option<InFlight>| match of {
            Some(InFlight::Listener) => "listener",
            Some(InFlight::Untraced) => "untraced",
            Some(InFlight::Foreign) => "foreign",
            Some(InFlight::Closed(_)) => "closed",
            None => "none",
        };
        let info = |arch: u32, nr: u64, a0: u64, a1: u64| sys::SyscallInfo {
            op: sys::SYSCALL_INFO_SECCOMP,
            arch,
            nr,
            ip: 0,
            args: [a0, a1, 0, 0, 0, 0],
            rval: 0,
        };
        let flag = u64::from(tfilter::SECCOMP_FILTER_FLAG_NEW_LISTENER);
        let untraced = u64::from(tfilter::CLONE_UNTRACED);
        // i386 int 0x80 seccomp(354) with NEW_LISTENER.
        assert_eq!(
            kind(Session::compat_special(&info(
                sys::AUDIT_ARCH_I386,
                354,
                0,
                flag
            ))),
            "listener"
        );
        // The same call without the flag is ordinary foreign.
        assert_eq!(
            kind(Session::compat_special(&info(
                sys::AUDIT_ARCH_I386,
                354,
                0,
                0
            ))),
            "none"
        );
        // i386 clone(120) with CLONE_UNTRACED.
        assert_eq!(
            kind(Session::compat_special(&info(
                sys::AUDIT_ARCH_I386,
                120,
                untraced,
                0
            ))),
            "untraced"
        );
        // x32 seccomp (317 | bit) and clone (56 | bit).
        assert_eq!(
            kind(Session::compat_special(&info(
                0xc000_003e,
                317u64 | u64::from(sys::X32_SYSCALL_BIT),
                0,
                flag
            ))),
            "listener"
        );
        assert_eq!(
            kind(Session::compat_special(&info(
                0xc000_003e,
                56u64 | u64::from(sys::X32_SYSCALL_BIT),
                untraced,
                0
            ))),
            "untraced"
        );
        // A native number under the i386 arch is a *different* call: 317 is
        // not i386 seccomp.
        assert_eq!(
            kind(Session::compat_special(&info(
                sys::AUDIT_ARCH_I386,
                317,
                0,
                flag
            ))),
            "none"
        );
        // AArch32 EABI has its own seccomp number. It can create the same
        // open-ended listener/untraced-child gaps as x86 compatibility ABIs.
        assert_eq!(
            kind(Session::compat_special(&info(0x4000_0028, 383, 0, flag))),
            "listener"
        );
        assert_eq!(
            kind(Session::compat_special(&info(
                0x4000_0028,
                120,
                untraced,
                0
            ))),
            "untraced"
        );
        assert_eq!(
            kind(Session::compat_special(&info(0x4000_0028, 354, 0, flag))),
            "none"
        );
        assert_eq!(
            kind(Session::compat_special(&info(0x4000_0028, 383, 0, 0))),
            "none"
        );
        // Another foreign architecture entirely.
        assert_eq!(
            kind(Session::compat_special(&info(0xc000_00b7, 354, 0, flag))),
            "none"
        );
    }

    fn target_path(dir: &std::path::Path) -> (std::path::PathBuf, std::ffi::CString) {
        let target = dir.join("made");
        let c = std::ffi::CString::new(target.as_os_str().as_encoded_bytes()).unwrap();
        (target, c)
    }

    /// The control for the two checks below: not killed, the child's
    /// `mkdir` runs and is one result. The harness is sound, so an absent
    /// directory below is the kernel skipping the call, not a child that
    /// never tried.
    #[test]
    fn j4_o3_control_an_unkilled_entry_runs_and_is_one_result() {
        let dir = tempfile::tempdir().unwrap();
        let (target, c) = target_path(dir.path());
        let Some(child) = Mkdirer::start(&c) else {
            return;
        };
        let (mut session, rx) = live_session();
        let status = child.release();
        assert!(is_seccomp_stop(status), "status {status:#x}");
        session.handle(child.pid, status);
        child.reap_into(&mut session);
        let events = drained(&rx, &mut session);
        assert!(target.is_dir(), "the call ran");
        assert!(
            events.iter().any(|event| matches!(
                event,
                TracerEvent::Syscall {
                    op: ClosedOp::Mkdir,
                    ret: 0,
                    ..
                }
            )),
            "{events:?}"
        );
        assert_eq!(gaps_of(&events), vec![]);
    }

    /// J4 O-3, the first window: the tracee is killed after the tracer has
    /// taken its seccomp entry stop from `waitpid` and before the tracer
    /// reads it. `PTRACE_GET_SYSCALL_INFO` then fails with `ESRCH` — and the
    /// kernel skips the call, because a fatal signal is pending after the
    /// trace event (`__seccomp_filter`). The directory is never made: the
    /// call had no effect, so it is not loss.
    #[test]
    fn j4_o3_a_tracee_killed_before_its_entry_is_read_made_no_call() {
        let dir = tempfile::tempdir().unwrap();
        let (target, c) = target_path(dir.path());
        let Some(child) = Mkdirer::start(&c) else {
            return;
        };
        let (mut session, rx) = live_session();
        let status = child.release();
        assert!(is_seccomp_stop(status), "status {status:#x}");
        child.kill();
        session.handle(child.pid, status);
        child.reap_into(&mut session);
        let events = drained(&rx, &mut session);
        assert!(!target.exists(), "the kernel skipped the call");
        assert_eq!(
            gaps_of(&events),
            vec![],
            "a call the kernel provably did not execute is not a loss"
        );
        assert_eq!(
            session.summary.loss.total(),
            0,
            "{:?}",
            session.summary.loss
        );
        assert_eq!(session.summary.killed_at_entry, 1, "{:?}", session.summary);
        assert_eq!(session.inflight, 0);
    }

    /// J4 O-3, the second window: the entry was read (the tracer holds it)
    /// and the tracee is killed before the tracer resumes it. The resume
    /// fails with `ESRCH`, and the kernel skips the call for the same
    /// reason. The entry is not abandoned: it never ran.
    ///
    /// The kill has to reach the tracee before the resume does. A tracee
    /// fast enough to get to its exit notification first is resumed from
    /// there — the resume succeeds, the observer cannot tell that stop from
    /// a call that ran and was then killed, and the entry stays an
    /// `entry_abandoned` gap (uncertain, so a gap). That branch is checked
    /// too, and the attempt repeated until the first branch is met, which on
    /// the reference host is the first try.
    #[test]
    fn j4_o3_a_tracee_killed_before_its_entry_is_resumed_made_no_call() {
        for _ in 0..20 {
            let dir = tempfile::tempdir().unwrap();
            let (target, c) = target_path(dir.path());
            let Some(child) = Mkdirer::start(&c) else {
                return;
            };
            let (mut session, rx) = live_session();
            let status = child.release();
            assert!(is_seccomp_stop(status), "status {status:#x}");
            session.register(child.pid);
            session.handle_entry(child.pid);
            assert_eq!(session.inflight, 1, "the entry is in hand");
            child.kill();
            session.restart(child.pid, 0);
            let met_the_killed_stop = session.summary.killed_at_entry == 1;
            child.reap_into(&mut session);
            let events = drained(&rx, &mut session);
            assert!(!target.exists(), "the kernel skipped the call");
            assert_eq!(session.inflight, 0);
            if !met_the_killed_stop {
                assert_eq!(
                    gaps_of(&events),
                    vec![(
                        GapReason::EntryAbandoned,
                        OpSet::of(ClosedOp::Mkdir),
                        Some(1)
                    )],
                    "resumed from somewhere it cannot tell: uncertain, so a gap"
                );
                continue;
            }
            assert_eq!(
                gaps_of(&events),
                vec![],
                "a call the kernel provably did not execute is not a loss"
            );
            assert_eq!(
                session.summary.loss.total(),
                0,
                "{:?}",
                session.summary.loss
            );
            return;
        }
        panic!("the resume never met the killed stop in 20 attempts");
    }

    /// J4 O-3, the exit window: the tracee is killed after its call ran and
    /// stopped at its syscall exit, before the tracer read the return. The
    /// call did run (the directory exists), and its result can no longer be
    /// read: that is a loss, and exactly one — of the call's own classes
    /// (`entry_abandoned` naming `mkdir`), not a second gap in every class.
    #[test]
    fn j4_o3_a_tracee_killed_at_its_exit_stop_is_one_loss_of_its_own_classes() {
        let dir = tempfile::tempdir().unwrap();
        let (target, c) = target_path(dir.path());
        let Some(child) = Mkdirer::start(&c) else {
            return;
        };
        let (mut session, rx) = live_session();
        let status = child.release();
        assert!(is_seccomp_stop(status), "status {status:#x}");
        session.handle(child.pid, status);
        let status = child.wait();
        assert!(
            libc::WIFSTOPPED(status) && libc::WSTOPSIG(status) == sys::SYSCALL_STOP_SIG,
            "the exit stop: {status:#x}"
        );
        child.kill();
        session.handle(child.pid, status);
        child.reap_into(&mut session);
        let events = drained(&rx, &mut session);
        assert!(target.is_dir(), "the call ran");
        assert_eq!(
            gaps_of(&events),
            vec![(
                GapReason::EntryAbandoned,
                OpSet::of(ClosedOp::Mkdir),
                Some(1)
            )],
            "one lost result, of the call's classes"
        );
        assert_eq!(
            session.summary.loss.total(),
            1,
            "{:?}",
            session.summary.loss
        );
        assert_eq!(session.inflight, 0);
    }

    /// Whether `pid` is asleep inside syscall `nr`, by `/proc`.
    fn sleeping_in(pid: pid_t, nr: libc::c_long) -> bool {
        let stat = std::fs::read_to_string(format!("/proc/{pid}/stat")).unwrap_or_default();
        let state = stat
            .rsplit_once(") ")
            .and_then(|(_, rest)| rest.chars().next());
        let syscall = std::fs::read_to_string(format!("/proc/{pid}/syscall")).unwrap_or_default();
        state == Some('S')
            && syscall
                .split_whitespace()
                .next()
                .and_then(|first| first.parse::<libc::c_long>().ok())
                == Some(nr)
    }

    /// J4 W3, tracer review R2: a SIGKILL exactly at the re-entry of a
    /// restarted call. The child sleeps in `openat` of a FIFO, a default-
    /// ignored signal interrupts it (`-ERESTARTSYS` at the exit), the kernel
    /// re-enters the call, and the child is killed at that re-entry's
    /// seccomp stop. The kernel skips the re-entered call, so it is neither
    /// a result nor a loss — and it is one call, counted once. On the base
    /// it was counted twice, as `killed_at_entry` and `restarts_unfinished`.
    #[test]
    fn j4_w3_r2_a_kill_at_the_reentry_of_a_restarted_call_is_counted_once() {
        let dir = tempfile::tempdir().unwrap();
        let fifo = dir.path().join("fifo");
        let c = std::ffi::CString::new(fifo.as_os_str().as_encoded_bytes()).unwrap();
        // SAFETY: a valid NUL-terminated path and a mode.
        assert_eq!(unsafe { libc::mkfifo(c.as_ptr(), 0o600) }, 0);
        let Some(child) = Mkdirer::start_open(&c) else {
            return;
        };
        let (mut session, rx) = live_session();
        let status = child.release();
        assert!(is_seccomp_stop(status), "the open's entry: {status:#x}");
        session.handle(child.pid, status);
        let deadline = Instant::now() + Duration::from_secs(10);
        while !sleeping_in(child.pid, libc::SYS_openat) {
            assert!(
                Instant::now() < deadline,
                "the child never slept in its open"
            );
            std::thread::sleep(Duration::from_millis(1));
        }
        // SAFETY: a pid this test created, and a valid signal.
        assert_eq!(unsafe { libc::kill(child.pid, libc::SIGWINCH) }, 0);
        let status = child.wait();
        assert!(
            libc::WIFSTOPPED(status) && libc::WSTOPSIG(status) == sys::SYSCALL_STOP_SIG,
            "the restart-coded exit: {status:#x}"
        );
        session.handle(child.pid, status);
        let status = child.wait();
        assert!(
            libc::WIFSTOPPED(status) && libc::WSTOPSIG(status) == libc::SIGWINCH,
            "the signal's delivery: {status:#x}"
        );
        session.handle(child.pid, status);
        let status = child.wait();
        assert!(is_seccomp_stop(status), "the re-entry: {status:#x}");
        child.kill();
        session.handle(child.pid, status);
        child.reap_into(&mut session);
        let events = drained(&rx, &mut session);
        assert_eq!(gaps_of(&events), vec![], "{events:?}");
        assert_eq!(
            session.summary.killed_at_entry + session.summary.restarts_unfinished,
            1,
            "one call, counted once: {:?}",
            session.summary
        );
        assert_eq!(
            session.summary.loss.total(),
            0,
            "{:?}",
            session.summary.loss
        );
        assert_eq!(session.inflight, 0);
    }

    #[test]
    fn a_sockaddr_is_clamped_to_its_family_not_the_callers_claim() {
        // A sockaddr_in announced as 128 bytes is still 16 bytes of address.
        assert_eq!(sockaddr_len(libc::AF_INET as u16, 128), Some(16));
        assert_eq!(sockaddr_len(libc::AF_INET as u16, 0x7fff_ffff), Some(16));
        // A claim shorter than the family's size bounds it further: the
        // kernel would reject the call, and nothing beyond the claim is ours.
        assert_eq!(sockaddr_len(libc::AF_INET as u16, 8), Some(8));
        assert_eq!(sockaddr_len(libc::AF_INET6 as u16, 128), Some(28));
        assert_eq!(sockaddr_len(libc::AF_UNIX as u16, 128), Some(110));
        assert_eq!(sockaddr_len(libc::AF_UNIX as u16, 20), Some(20));
        // A family the closed set does not name keeps no bytes at all.
        assert_eq!(sockaddr_len(libc::AF_NETLINK as u16, 128), None);
        assert_eq!(sockaddr_len(libc::AF_PACKET as u16, 128), None);
        assert_eq!(sockaddr_len(0xffff, 128), None);
    }

    /// J5-T (review of the fix, M5): the backend is owed only while its
    /// number still names the process born at the recorded time. A reused
    /// number — same pid, another birth — is not the backend: the tracer
    /// neither waits for it nor lists it as unreaped. The same pid and
    /// birth is, zombie included, until its exit is reaped. The kernel
    /// will not reuse a live pid on demand, so the birth is scripted.
    #[test]
    fn j5t_the_backend_is_owed_only_under_its_own_birth() {
        const BACKEND: pid_t = RECYCLED;
        let table = std::sync::Arc::new(std::sync::Mutex::new(HashMap::new()));
        let (tx, rx) = std::sync::mpsc::sync_channel(64);
        let mut session = Session::new(
            TracerConfig::default(),
            tx,
            Arc::default(),
            0,
            Box::new(ScriptedProc(std::sync::Arc::clone(&table))),
        );
        session.owed = Owed::Backend {
            pid: BACKEND,
            birth: Some(1000),
            reaped: false,
        };
        let now_named = |birth: Option<u64>| {
            let mut table = table.lock().unwrap();
            match birth {
                Some(ticks) => table.insert(BACKEND, (BACKEND, ticks)),
                None => table.remove(&BACKEND),
            };
        };

        now_named(Some(1000));
        assert!(session.tasks.is_empty());
        assert!(
            !session.accounted_for(),
            "the backend, born at 1000, is alive or a zombie: wait for its exit"
        );
        now_named(Some(2000));
        assert!(
            session.accounted_for(),
            "the number now names a process born at 2000: the backend is gone"
        );
        now_named(None);
        assert!(session.accounted_for(), "nothing has the number");

        // Without a recorded birth any holder of the number is kept.
        session.owed = Owed::Backend {
            pid: BACKEND,
            birth: None,
            reaped: false,
        };
        now_named(Some(2000));
        assert!(!session.accounted_for());
        // A reaped backend is done whatever holds its number now.
        session.owed = Owed::Backend {
            pid: BACKEND,
            birth: Some(1000),
            reaped: true,
        };
        now_named(Some(1000));
        assert!(session.accounted_for());

        // The same rule decides what `finish` reports as unreaped.
        let handles = |session: &Session| Handles {
            stop: Arc::new(AtomicBool::new(true)),
            shutdown_ns: Arc::default(),
            tid: Arc::default(),
            handed: Arc::clone(&session.handed),
        };
        let unreaped = |birth_now: u64| {
            let (tx, _rx) = std::sync::mpsc::sync_channel(64);
            let mut session = Session::new(
                TracerConfig::default(),
                tx,
                Arc::default(),
                0,
                Box::new(ScriptedProc(std::sync::Arc::clone(&table))),
            );
            session.owed = Owed::Backend {
                pid: BACKEND,
                birth: Some(1000),
                reaped: false,
            };
            now_named(Some(birth_now));
            let handles = handles(&session);
            session.finish(&handles).unreaped_children
        };
        assert_eq!(unreaped(1000), vec![BACKEND], "its own birth: unreaped");
        assert_eq!(
            unreaped(2000),
            Vec::<pid_t>::new(),
            "another birth: not the backend, not loss"
        );
        drop(rx);
    }
    /// J5-T w3: the children a session was attached beside are recognised
    /// by pid and birth; anything else that is not a tracee was gained since
    /// and is owed — awaited, and listed unreaped if the tracer stops first.
    /// A pid the kernel reused after a bystander ended is gained, not beside.
    /// Scripted: the kernel will not reuse a pid, or hand an unprivileged
    /// test a live orphan, on demand.
    #[test]
    fn j5t_a_child_gained_after_the_attach_is_owed_and_a_bystander_is_not() {
        struct Family(std::sync::Arc<std::sync::Mutex<Vec<(pid_t, u64)>>>);
        impl ProcView for Family {
            fn tgid(&self, tid: pid_t) -> Option<pid_t> {
                Some(tid)
            }
            fn start_ticks(&self, tid: pid_t) -> Option<u64> {
                self.0
                    .lock()
                    .unwrap()
                    .iter()
                    .find(|(pid, _)| *pid == tid)
                    .map(|(_, birth)| *birth)
            }
            fn children(&self, _pid: pid_t) -> Vec<pid_t> {
                self.0.lock().unwrap().iter().map(|(pid, _)| *pid).collect()
            }
        }
        const BYSTANDER: pid_t = RECYCLED;
        const ORPHAN: pid_t = WORKER;
        let family = std::sync::Arc::new(std::sync::Mutex::new(vec![(BYSTANDER, 1000)]));
        let session = || {
            let (tx, _) = std::sync::mpsc::sync_channel(64);
            let mut session = Session::new(
                TracerConfig::default(),
                tx,
                Arc::default(),
                0,
                Box::new(Family(std::sync::Arc::clone(&family))),
            );
            session.owed = Owed::Nothing;
            session.beside = vec![(BYSTANDER, 1000)];
            session
        };
        let set = |children: &[(pid_t, u64)]| *family.lock().unwrap() = children.to_vec();

        let s = session();
        assert!(s.adopted().is_empty());
        assert!(s.accounted_for(), "only the bystander: done");
        set(&[(BYSTANDER, 1000), (ORPHAN, 1500)]);
        assert_eq!(s.adopted(), vec![ORPHAN]);
        assert!(!s.accounted_for(), "an orphan gained since: wait for it");
        set(&[(BYSTANDER, 2000)]);
        assert_eq!(
            s.adopted(),
            vec![BYSTANDER],
            "the bystander's number under another birth is a new child"
        );
        assert!(!s.accounted_for());

        let handles = |session: &Session| Handles {
            stop: Arc::new(AtomicBool::new(true)),
            shutdown_ns: Arc::default(),
            tid: Arc::default(),
            handed: Arc::clone(&session.handed),
        };
        set(&[(BYSTANDER, 1000), (ORPHAN, 1500)]);
        let s = session();
        let h = handles(&s);
        assert_eq!(
            s.finish(&h).unreaped_children,
            vec![ORPHAN],
            "stopped first: the orphan is unreaped, the bystander is not"
        );
    }

    // Audit-6 review begin: the descriptor corroboration and the exec-time
    // command re-check.

    /// Plays the kernel's side of the audit-6 checks: each task's thread
    /// group, cmdline, image link and descriptor links.
    #[derive(Default)]
    struct Kernel {
        tasks: HashMap<pid_t, pid_t>,
        cmdline: HashMap<pid_t, Vec<u8>>,
        exe: HashMap<pid_t, Vec<u8>>,
        fds: HashMap<(pid_t, i64), Vec<u8>>,
    }

    impl ProcView for Kernel {
        fn tgid(&self, tid: pid_t) -> Option<pid_t> {
            self.tasks.get(&tid).copied()
        }
        fn start_ticks(&self, tid: pid_t) -> Option<u64> {
            self.tasks.contains_key(&tid).then_some(1000)
        }
        fn children(&self, _pid: pid_t) -> Vec<pid_t> {
            Vec::new()
        }
        fn cmdline(&self, tid: pid_t) -> Option<Vec<u8>> {
            self.cmdline.get(&tid).cloned()
        }
        fn exe(&self, tid: pid_t) -> Option<Vec<u8>> {
            self.exe.get(&tid).cloned()
        }
        fn fd_link(&self, tid: pid_t, fd: i64) -> Option<Vec<u8>> {
            self.fds.get(&(tid, fd)).cloned()
        }
    }

    fn kernel_session(
        config: TracerConfig,
        kernel: Kernel,
    ) -> (Session, std::sync::mpsc::Receiver<TracerEvent>) {
        let tasks: Vec<pid_t> = kernel.tasks.keys().copied().collect();
        let (tx, rx) = std::sync::mpsc::sync_channel(64);
        let mut session = Session::new(config, tx, Arc::default(), 0, Box::new(kernel));
        for tid in tasks {
            session.register(tid);
        }
        (session, rx)
    }

    #[test]
    fn a_path_claim_is_corroborated_by_its_components_not_only_its_name() {
        // Absolute: exactly the resolved path.
        assert!(path_corroborated(b"/w/out.txt", b"/w/out.txt", false, None));
        assert!(path_corroborated(
            b"/w//./out.txt",
            b"/w/out.txt",
            false,
            None
        ));
        assert!(
            !path_corroborated(b"/w/public/x", b"/w/secret/x", false, None),
            "a rewritten directory component"
        );
        assert!(!path_corroborated(b"/w/a", b"/w/b", false, None));
        // Relative: the tail of the resolved path, bare names included.
        assert!(path_corroborated(b"out.txt", b"/w/out.txt", false, None));
        assert!(path_corroborated(
            b"sub/out.txt",
            b"/w/sub/out.txt",
            false,
            None
        ));
        assert!(
            !path_corroborated(b"a", b"/w/b", false, None),
            "a bare name is checked too"
        );
        assert!(!path_corroborated(
            b"sub/out.txt",
            b"/w/other/out.txt",
            false,
            None
        ));
        // Past a `..`, only what follows the last one.
        assert!(path_corroborated(b"../out/x", b"/w/out/x", false, None));
        assert!(!path_corroborated(b"../out/x", b"/w/in/x", false, None));
        assert!(!path_corroborated(b"a/..", b"/w", false, None));
        // Unlinked since: the annotation is the kernel's and the count
        // agrees; a live decoy *named* `gone (deleted)` or an unreadable
        // count does not corroborate (audit 7 L7).
        assert!(path_corroborated(
            b"/w/gone",
            b"/w/gone (deleted)",
            false,
            Some(0)
        ));
        assert!(!path_corroborated(
            b"/w/gone",
            b"/w/gone (deleted)",
            false,
            Some(1)
        ));
        assert!(!path_corroborated(
            b"/w/gone",
            b"/w/gone (deleted)",
            false,
            None
        ));
        // O_TMPFILE names the directory; its descriptor is `#<ino>` inside.
        assert!(path_corroborated(
            b"/tmp",
            b"/tmp/#1234 (deleted)",
            true,
            None
        ));
        assert!(path_corroborated(
            b"/tmp/",
            b"/tmp/#1234 (deleted)",
            true,
            None
        ));
        assert!(!path_corroborated(
            b"/tmp",
            b"/var/tmp/#1234 (deleted)",
            true,
            None
        ));
        assert!(
            !path_corroborated(b"/tmp", b"/tmp/#1234 (deleted)", false, Some(0)),
            "only an O_TMPFILE open drops the name"
        );
        // No path at all: the pipe or terminal behind /dev/stderr.
        assert!(!path_corroborated(
            b"/dev/stderr",
            b"pipe:[4242]",
            false,
            None
        ));
        assert!(!path_corroborated(
            b"/dev/stderr",
            b"/dev/pts/3",
            false,
            None
        ));
    }

    /// Audit-6 review: a claim the descriptor does not corroborate is
    /// downgraded and named by a bookkeeping gap — never loss, never a
    /// degraded class — so ordinary `O_TMPFILE` and `/dev/stderr` opens cannot
    /// stop a strict run, while a bare relative name is checked like any
    /// other. Verified against this process's own memory, which the exit's
    /// stability re-read can read.
    #[test]
    fn an_open_claim_the_descriptor_does_not_corroborate_is_downgraded_not_lost() {
        let self_pid = std::process::id() as pid_t;
        let write = (libc::O_WRONLY | libc::O_CREAT) as u64;
        let cases: [(&[u8], u64, &[u8], bool); 5] = [
            (b"/w/out.txt\0", write, b"/w/out.txt", true),
            (
                b"/tmp\0",
                (libc::O_RDWR | libc::O_TMPFILE) as u64,
                b"/tmp/#77 (deleted)",
                true,
            ),
            (
                b"/dev/stderr\0",
                libc::O_WRONLY as u64,
                b"pipe:[4242]",
                false,
            ),
            (b"a\0", write, b"/w/b", false),
            (b"/w/public/x\0", write, b"/w/secret/x", false),
        ];
        for (path, flags, link, corroborated) in cases {
            let (mut session, rx) = kernel_session(
                TracerConfig::default(),
                Kernel {
                    tasks: [(self_pid, self_pid)].into(),
                    fds: [((self_pid, 5), link.to_vec())].into(),
                    ..Kernel::default()
                },
            );
            let mut raw = [0u64; 6];
            raw[1] = path.as_ptr() as u64;
            raw[2] = flags;
            session.tasks.get_mut(&self_pid).unwrap().pending = Some(InFlight::Closed(Pending {
                entry: closed_set::lookup(u64::from(crate::platform::linux::abi::nr(257, 56)))
                    .expect("openat"),
                args: Args {
                    path: Some(PathSnapshot {
                        bytes: path[..path.len() - 1].to_vec(),
                        complete: true,
                    }),
                    flags: Some(flags),
                    ..Args::default()
                },
                exec_confirmed: false,
                path_unreadable: false,
                path2_unreadable: false,
                sockaddr_unreadable: false,
                flags_unavailable: false,
                raw,
                entry_argv: None,
            }));
            session.inflight += 1;
            session.handle_exit(self_pid, 5);
            let events = drained(&rx, &mut session);
            let delivered = events
                .iter()
                .find_map(|event| match event {
                    TracerEvent::Syscall { args, .. } => args.path.clone(),
                    _ => None,
                })
                .expect("the call is delivered either way");
            let name = String::from_utf8_lossy(path);
            assert_eq!(delivered.complete, corroborated, "{name}");
            assert_eq!(
                gaps_of(&events),
                if corroborated {
                    Vec::new()
                } else {
                    vec![(GapReason::PathClaimUnverified, OpSet::EMPTY, Some(1))]
                },
                "{name}"
            );
            assert_eq!(
                session.summary.path_claims_unverified,
                u64::from(!corroborated),
                "{name}"
            );
            assert_eq!(session.summary.loss.total(), 0, "{name}: never loss");
        }
    }

    #[test]
    fn the_exec_recheck_judges_what_the_entry_judged_on_the_kernels_copy() {
        let rules = crate::commands::Rules {
            deny: vec![
                "git push --force".into(),
                "git push".into(),
                "deploy.sh --prod".into(),
            ],
            forbid: vec!["dangerous-tool **".into(), "bash **".into()],
        };
        rules.validate().unwrap();
        let argv = |items: &[&str]| {
            items
                .iter()
                .map(|item| item.as_bytes().to_vec())
                .collect::<Vec<_>>()
        };
        let recheck = |entry: &[&str], kernel: &[&str], claimed: &str, image: &str| {
            exec_recheck(
                &rules,
                &argv(entry),
                Some(argv(kernel).as_slice()),
                Some(claimed.as_bytes()),
                Some(image.as_bytes()),
            )
            .map(|hit| (hit.pattern, hit.forbidden))
        };
        // An argv raced between the entry read and the kernel's copy: the
        // kernel's copy is judged.
        assert_eq!(
            recheck(
                &["git", "status"],
                &["git", "push", "--force"],
                "/usr/bin/git",
                "/usr/bin/git"
            ),
            Some(("git push --force".to_owned(), false))
        );
        // Unchanged, with an empty argument kept in its place: `git push ""`
        // is not `git push`.
        assert_eq!(
            recheck(
                &["git", "push", ""],
                &["git", "push", ""],
                "/usr/bin/git",
                "/usr/bin/git"
            ),
            None
        );
        // A `#!` script: the interpreter's argv is never judged...
        assert_eq!(
            recheck(
                &["./build.sh", "x"],
                &["/bin/bash", "./build.sh", "x"],
                "./build.sh",
                "/usr/bin/bash"
            ),
            None
        );
        // ...while the script and its arguments still are, past an
        // interpreter argument too.
        assert_eq!(
            recheck(
                &["./deploy.sh", "--prod"],
                &["/bin/sh", "-e", "./deploy.sh", "--prod"],
                "./deploy.sh",
                "/usr/bin/dash"
            ),
            Some(("deploy.sh --prod".to_owned(), false))
        );
        // An execve with no argv: the kernel's inserted empty argument is
        // that argv, and the image names the program.
        assert_eq!(
            recheck(&[], &[""], "/usr/bin/other-tool", "/usr/bin/other-tool"),
            None
        );
        assert_eq!(
            recheck(&[], &[""], "/usr/bin/other-tool", "/usr/bin/dangerous-tool"),
            Some(("dangerous-tool **".to_owned(), true))
        );
        // A raced exec path: the image the kernel loaded names what argv[0]
        // and the snapshot hide, unlinked or not.
        assert_eq!(
            recheck(
                &["benign"],
                &["benign"],
                "/usr/bin/benign",
                "/usr/bin/dangerous-tool (deleted)"
            ),
            Some(("dangerous-tool **".to_owned(), true))
        );
        // An unreadable kernel copy refuses, as an unreadable argv does at
        // the entry stop.
        assert_eq!(
            exec_recheck(&rules, &argv(&["ls"]), None, Some(b"/bin/ls"), None)
                .map(|hit| (hit.pattern, hit.forbidden)),
            Some(("<unreadable-or-oversized-argv>".to_owned(), false))
        );
    }

    /// Audit-6 review: the process an exec-time hit kills leaves flight at
    /// its exec event, which carries the verdict, so the death that follows
    /// has no entry to abandon — no invented `entry_abandoned` loss.
    #[test]
    fn an_exec_the_recheck_kills_leaves_flight_with_its_event_and_no_abandoned_gap() {
        // No real task has this pid, so the SIGKILL touches nothing.
        const EXECER: pid_t = RECYCLED;
        let (mut session, rx) = kernel_session(
            TracerConfig {
                commands: crate::commands::Rules {
                    deny: vec!["git push --force".into()],
                    forbid: Vec::new(),
                },
                ..TracerConfig::default()
            },
            Kernel {
                tasks: [(EXECER, EXECER)].into(),
                cmdline: [(EXECER, b"git\0push\0--force\0".to_vec())].into(),
                exe: [(EXECER, b"/usr/bin/git".to_vec())].into(),
                ..Kernel::default()
            },
        );
        session.tasks.get_mut(&EXECER).unwrap().pending = Some(InFlight::Closed(Pending {
            entry: closed_set::lookup(libc::SYS_execve as u64).expect("execve"),
            args: Args {
                path: Some(PathSnapshot {
                    bytes: b"/usr/bin/git".to_vec(),
                    complete: true,
                }),
                ..Args::default()
            },
            exec_confirmed: false,
            path_unreadable: false,
            path2_unreadable: false,
            sockaddr_unreadable: false,
            flags_unavailable: false,
            raw: [0; 6],
            entry_argv: Some(vec![b"git".to_vec(), b"status".to_vec()]),
        }));
        session.inflight += 1;
        session.exec_transition(EXECER, EXECER);
        assert!(session.tasks[&EXECER].pending.is_none());
        assert_eq!(session.inflight, 0);
        session.handle_death(EXECER, libc::SIGKILL);
        let events = drained(&rx, &mut session);
        assert!(gaps_of(&events).is_empty(), "{events:?}");
        assert_eq!(session.summary.loss.abandoned_entries, 0);
        let command = events
            .iter()
            .find_map(|event| match event {
                TracerEvent::Exec { command, .. } => Some(command.clone()),
                _ => None,
            })
            .expect("the exec event");
        assert_eq!(
            command.map(|hit| (hit.pattern, hit.forbidden)),
            Some(("git push --force".to_owned(), false))
        );
    }
    // Audit-6 review end.
}
