//! Configuration files, the environment allow-list and limit parsing.
//!
//! Implements jail-v1 §6.2 (paths and precedence), the file keys of §6.3 and
//! the limit grammar of §6.4.
//!
//! Unknown keys refuse rather than being ignored, so a future policy key can
//! never be silently dropped by an older binary. Duplicate keys refuse because
//! TOML itself forbids them and the parser reports them; a test pins that.
//! Only the four documented environment variables are read; every other
//! `OURO_*` name is ignored, so a submitter cannot smuggle authority in.

use std::collections::BTreeSet;
use std::ffi::OsString;
use std::net::Ipv6Addr;
use std::path::PathBuf;

use serde::Deserialize;

use crate::network::NetworkMode;
use crate::policy::{Ceiling, Ceilings, LimitKey, PolicyDelta, ProtectedCoverage};
use crate::records::{
    ErrorCode, ErrorStage, EvidenceMode, JailError, ObserveMode, Remediation, SCHEMA_POLICY,
};

/// The documented environment allow-list (§6.2 step 3).
pub const ENVIRONMENT_ALLOW_LIST: &[&str] = &[
    "OURO_CONFIG_DIR",
    "OURO_DATA_DIR",
    "OURO_JAIL_OBSERVE",
    "OURO_JAIL_EVIDENCE",
    "OURO_JAIL_TRACE_CAP",
];

fn invalid(key: &str, message: impl Into<String>) -> JailError {
    JailError::new(
        ErrorCode::InvalidConfig,
        ErrorStage::Resolving,
        Remediation::Configuration,
        message.into(),
    )
    .with_key_path(key)
}

/// A TOML scalar that may be written as an integer or as a string with a unit.
#[derive(Clone, PartialEq, Eq, Debug, Deserialize)]
#[serde(untagged)]
pub enum Scalar {
    /// An integer literal.
    Integer(i64),
    /// A string literal, possibly carrying a unit.
    Text(String),
}

impl Scalar {
    fn as_text(&self) -> String {
        match self {
            Scalar::Integer(value) => value.to_string(),
            Scalar::Text(text) => text.clone(),
        }
    }
}

/// `[filesystem]` in a policy file.
#[derive(Clone, Default, PartialEq, Eq, Debug, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct FilesystemSection {
    /// `filesystem.read_write`.
    #[serde(default)]
    pub read_write: Vec<String>,
    /// `filesystem.read_only`.
    #[serde(default)]
    pub read_only: Vec<String>,
    /// `filesystem.deny_read`.
    #[serde(default)]
    pub deny_read: Vec<String>,
    /// `filesystem.protected_coverage`.
    pub protected_coverage: Option<String>,
}

/// `[network]` in a policy file.
#[derive(Clone, Default, PartialEq, Eq, Debug, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct NetworkSection {
    /// `network.mode`.
    pub mode: Option<String>,
    /// `network.allow`.
    #[serde(default)]
    pub allow: Option<Vec<String>>,
}

/// `[limits]` in a policy file.
#[derive(Clone, Default, PartialEq, Eq, Debug, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct LimitsSection {
    /// `limits.wall`.
    pub wall: Option<Scalar>,
    /// `limits.pids`.
    pub pids: Option<Scalar>,
    /// `limits.mem`.
    pub mem: Option<Scalar>,
    /// `limits.swap` (zero disables swapping).
    pub swap: Option<Scalar>,
    /// `limits.storage`.
    pub storage: Option<Scalar>,
    /// `limits.inodes`.
    pub inodes: Option<Scalar>,
    /// `limits.cpu`.
    pub cpu: Option<Scalar>,
}

/// `[observation]` in a policy file.
#[derive(Clone, Default, PartialEq, Eq, Debug, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ObservationSection {
    /// `observation.mode`.
    pub mode: Option<String>,
    /// `observation.evidence`.
    pub evidence: Option<String>,
}

/// A selected operator profile file (§6.3). `extends` is required.
#[derive(Clone, PartialEq, Eq, Debug, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct PolicyFile {
    /// Must be `ouro.jail.policy/1`.
    pub schema: String,
    /// Exactly one built-in contained profile.
    pub extends: String,
    /// Filesystem keys.
    #[serde(default)]
    pub filesystem: FilesystemSection,
    /// Network keys.
    #[serde(default)]
    pub network: NetworkSection,
    /// Limit keys.
    #[serde(default)]
    pub limits: LimitsSection,
    /// Observation keys.
    #[serde(default)]
    pub observation: ObservationSection,
}

/// The `[jail]` table shared by `config.toml` and a project `ouro.toml`.
#[derive(Clone, Default, PartialEq, Eq, Debug, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct JailSection {
    /// Operator-only argv accident filters.
    #[serde(default)]
    pub commands: crate::commands::Rules,
    /// `jail.schema`.
    pub schema: Option<String>,
    /// `jail.profile`: a built-in name or an operator profile file path.
    /// Forbidden in a project file.
    pub profile: Option<String>,
    /// `jail.extends`: forbidden in a project file and in `config.toml`.
    pub extends: Option<String>,
    /// Filesystem keys.
    #[serde(default)]
    pub filesystem: FilesystemSection,
    /// Network keys.
    #[serde(default)]
    pub network: NetworkSection,
    /// Limit keys.
    #[serde(default)]
    pub limits: LimitsSection,
    /// Observation keys.
    #[serde(default)]
    pub observation: ObservationSection,
}

/// `[jail_host.network]`: host configuration, forbidden in project files.
#[derive(Clone, Default, PartialEq, Eq, Debug, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct JailHostNetwork {
    /// Canonical IPv6 CIDRs of the provisioned network.
    #[serde(default)]
    pub translation_prefixes: Vec<String>,
}

/// `[jail_host]`.
#[derive(Clone, Default, PartialEq, Eq, Debug, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct JailHostSection {
    /// Network host configuration.
    pub network: Option<JailHostNetwork>,
}

/// The operator's `config.toml`.
#[derive(Clone, Default, PartialEq, Eq, Debug, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct OperatorConfig {
    /// Local ledger retention settings; execution does not apply them.
    pub ledger: Option<ouro_records::retention::LedgerRetention>,
    /// Jail defaults.
    pub jail: Option<JailSection>,
    /// Host configuration.
    pub jail_host: Option<JailHostSection>,
}

/// The workspace-root `ouro.toml`.
#[derive(Clone, Default, PartialEq, Eq, Debug, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ProjectConfig {
    /// The project's narrowing section.
    pub jail: Option<JailSection>,
}

/// Parses a selected operator profile file.
///
/// # Errors
/// Returns [`ErrorCode::InvalidConfig`] for a syntax error, an unknown key, a
/// duplicate key or a wrong `schema` value.
pub fn parse_policy_file(text: &str) -> Result<PolicyFile, JailError> {
    let file: PolicyFile =
        toml::from_str(text).map_err(|error| invalid("profile", error.message().to_owned()))?;
    if file.schema != SCHEMA_POLICY {
        return Err(invalid(
            "schema",
            format!("expected schema `{SCHEMA_POLICY}`, found `{}`", file.schema),
        ));
    }
    Ok(file)
}

/// Parses the operator's `config.toml`.
///
/// # Errors
/// Returns [`ErrorCode::InvalidConfig`] for a syntax error, an unknown key or a
/// duplicate key.
pub fn parse_operator_config(text: &str) -> Result<OperatorConfig, JailError> {
    toml::from_str(text).map_err(|error| invalid("config", error.message().to_owned()))
}

/// Parses a project `ouro.toml`.
///
/// # Errors
/// Returns [`ErrorCode::InvalidConfig`] for a syntax error, an unknown key or a
/// duplicate key.
pub fn parse_project_config(text: &str) -> Result<ProjectConfig, JailError> {
    let project: ProjectConfig =
        toml::from_str(text).map_err(|error| invalid("jail", error.message().to_owned()))?;
    if project
        .jail
        .as_ref()
        .is_some_and(|j| !j.commands.is_empty())
    {
        return Err(invalid("jail.commands", "command rules are operator-only"));
    }
    Ok(project)
}

/// Builds the semantic delta of a policy file's body.
///
/// `prefix` is the key-path prefix used when reporting an exact key path, so a
/// project file reports `jail.limits.wall` and a profile file `limits.wall`.
/// `explicit_required` marks every ceiling this layer sets as required (§6.4:
/// "Every explicit limit from CLI, operator or project config is required").
///
/// # Errors
/// Returns [`ErrorCode::InvalidConfig`] for an unparsable value.
pub fn delta_from_sections(
    prefix: &str,
    filesystem: &FilesystemSection,
    network: &NetworkSection,
    limits: &LimitsSection,
    observation: &ObservationSection,
) -> Result<PolicyDelta, JailError> {
    let mut delta = PolicyDelta {
        read_write: filesystem
            .read_write
            .iter()
            .map(|p| p.as_bytes().to_vec())
            .collect(),
        read_only: filesystem
            .read_only
            .iter()
            .map(|p| p.as_bytes().to_vec())
            .collect(),
        deny_read: filesystem
            .deny_read
            .iter()
            .map(|p| p.as_bytes().to_vec())
            .collect(),
        ..PolicyDelta::default()
    };
    if let Some(coverage) = &filesystem.protected_coverage {
        delta.protected_coverage = Some(ProtectedCoverage::parse(coverage).ok_or_else(|| {
            invalid(
                &format!("{prefix}filesystem.protected_coverage"),
                format!("unknown protected coverage `{coverage}`"),
            )
        })?);
    }
    if let Some(mode) = &network.mode {
        delta.network_mode = Some(match mode.as_str() {
            "none" => NetworkMode::None,
            "proxy" => NetworkMode::Proxy,
            "host" => NetworkMode::Host,
            other => {
                return Err(invalid(
                    &format!("{prefix}network.mode"),
                    format!("unknown network mode `{other}`"),
                ));
            }
        });
    }
    delta.network_allow_present = network.allow.is_some();
    delta.network_allow = network.allow.clone().unwrap_or_default();
    delta.limits = ceilings_from_section(prefix, limits, true)?;
    if let Some(mode) = &observation.mode {
        delta.observe = Some(parse_observe(&format!("{prefix}observation.mode"), mode)?);
    }
    if let Some(evidence) = &observation.evidence {
        delta.evidence = Some(parse_evidence(
            &format!("{prefix}observation.evidence"),
            evidence,
        )?);
    }
    Ok(delta)
}

/// Parses every ceiling a `[limits]` section sets.
///
/// # Errors
/// Returns [`ErrorCode::InvalidConfig`] for a zero, negative, unbounded,
/// overflowing or unknown value.
pub fn ceilings_from_section(
    prefix: &str,
    limits: &LimitsSection,
    required: bool,
) -> Result<Ceilings, JailError> {
    let mut out = Ceilings::default();
    for (key, scalar) in [
        (LimitKey::Wall, &limits.wall),
        (LimitKey::Pids, &limits.pids),
        (LimitKey::Mem, &limits.mem),
        (LimitKey::Swap, &limits.swap),
        (LimitKey::Storage, &limits.storage),
        (LimitKey::Inodes, &limits.inodes),
        (LimitKey::Cpu, &limits.cpu),
    ] {
        let Some(scalar) = scalar else { continue };
        let text = scalar.as_text();
        let key_path = format!("{prefix}limits.{}", key.as_str());
        let value = parse_limit_value(&key_path, key, &text)?;
        let ceiling = Some(Ceiling {
            value,
            requested: text,
            required,
        });
        match key {
            LimitKey::Wall => out.wall = ceiling,
            LimitKey::Pids => out.pids = ceiling,
            LimitKey::Mem => out.mem = ceiling,
            LimitKey::Swap => out.swap = ceiling,
            LimitKey::Storage => out.storage = ceiling,
            LimitKey::Inodes => out.inodes = ceiling,
            LimitKey::Cpu => out.cpu = ceiling,
        }
    }
    Ok(out)
}

/// Parses one `--limit KEY=VALUE` argument list into ceilings.
///
/// Duplicate keys refuse (§6.4).
///
/// # Errors
/// Returns [`ErrorCode::InvalidConfig`] for an unknown key, a duplicate key or
/// an unparsable value.
pub fn ceilings_from_cli(arguments: &[String]) -> Result<Ceilings, JailError> {
    let mut out = Ceilings::default();
    let mut seen: BTreeSet<&'static str> = BTreeSet::new();
    for argument in arguments {
        let Some((key, value)) = argument.split_once('=') else {
            return Err(invalid("--limit", format!("`{argument}` is not KEY=VALUE")));
        };
        let Some(limit) = LimitKey::parse(key) else {
            return Err(invalid(
                "--limit",
                format!(
                    "unknown limit key `{key}`; expected wall, pids, mem, swap, storage, inodes or cpu"
                ),
            ));
        };
        if !seen.insert(limit.as_str()) {
            return Err(invalid(
                &format!("--limit {}", limit.as_str()),
                format!("`{}` is supplied more than once", limit.as_str()),
            ));
        }
        let key_path = format!("--limit {}", limit.as_str());
        let parsed = parse_limit_value(&key_path, limit, value)?;
        let ceiling = Some(Ceiling {
            value: parsed,
            requested: value.to_owned(),
            required: true,
        });
        match limit {
            LimitKey::Wall => out.wall = ceiling,
            LimitKey::Pids => out.pids = ceiling,
            LimitKey::Mem => out.mem = ceiling,
            LimitKey::Swap => out.swap = ceiling,
            LimitKey::Storage => out.storage = ceiling,
            LimitKey::Inodes => out.inodes = ceiling,
            LimitKey::Cpu => out.cpu = ceiling,
        }
    }
    Ok(out)
}

/// Parses one limit value in its key's grammar (§6.4).
///
/// # Errors
/// Returns [`ErrorCode::InvalidConfig`] for a zero, negative, unbounded,
/// overflowing or unknown value.
pub fn parse_limit_value(key_path: &str, key: LimitKey, text: &str) -> Result<u64, JailError> {
    match key {
        LimitKey::Wall => parse_scaled(
            key_path,
            text,
            &[("ms", 1), ("s", 1000), ("m", 60_000), ("h", 3_600_000)],
            true,
        ),
        LimitKey::Swap if matches!(text, "0" | "0KiB" | "0MiB" | "0GiB") => Ok(0),
        LimitKey::Mem | LimitKey::Swap | LimitKey::Storage => parse_scaled(
            key_path,
            text,
            &[
                ("KiB", 1024),
                ("MiB", 1024 * 1024),
                ("GiB", 1024 * 1024 * 1024),
            ],
            false,
        ),
        LimitKey::Pids | LimitKey::Cpu | LimitKey::Inodes => {
            parse_scaled(key_path, text, &[], false)
        }
    }
}

/// Parses `<digits><unit>` with checked multiplication.
///
/// The units are tried longest-first so `ms` is not read as `m` followed by a
/// stray `s`. `unit_required` is true for `wall`, whose grammar has no bare
/// integer form.
fn parse_scaled(
    key_path: &str,
    text: &str,
    units: &[(&str, u64)],
    unit_required: bool,
) -> Result<u64, JailError> {
    // §6.4's grammar is `<digits><unit>` with nothing around it. Trimming
    // would quietly accept `"  1m  "`, and a narrowing file that is allowed to
    // spell a ceiling two ways is a comparison waiting to disagree.
    let trimmed = text;
    let mut sorted: Vec<&(&str, u64)> = units.iter().collect();
    sorted.sort_by_key(|(unit, _)| std::cmp::Reverse(unit.len()));
    let (digits, multiplier) = match sorted
        .iter()
        .find(|(unit, _)| trimmed.len() > unit.len() && trimmed.ends_with(unit))
    {
        Some((unit, multiplier)) => (&trimmed[..trimmed.len() - unit.len()], *multiplier),
        None => {
            if unit_required {
                return Err(invalid(
                    key_path,
                    format!("`{text}` needs one of the units ms, s, m or h"),
                ));
            }
            (trimmed, 1)
        }
    };
    if digits.is_empty() || !digits.bytes().all(|byte| byte.is_ascii_digit()) {
        return Err(invalid(
            key_path,
            format!("`{text}` is not a positive integer with an accepted unit"),
        ));
    }
    if digits.len() > 1 && digits.starts_with('0') {
        return Err(invalid(key_path, format!("`{text}` has a leading zero")));
    }
    let base: u64 = digits
        .parse()
        .map_err(|_| invalid(key_path, format!("`{text}` does not fit in 64 bits")))?;
    if base == 0 {
        return Err(invalid(
            key_path,
            format!("`{text}` is zero; a ceiling must be positive"),
        ));
    }
    base.checked_mul(multiplier)
        .ok_or_else(|| invalid(key_path, format!("`{text}` overflows 64 bits")))
}

/// Validates a `schema` key wherever one may appear (§6.2).
///
/// An absent key is accepted: `config.toml` and `ouro.toml` may omit it. Any
/// other value refuses, because a file declaring a schema this build does not
/// implement is not a file whose keys this build may interpret.
///
/// # Errors
/// Returns [`ErrorCode::InvalidConfig`] for a value other than
/// `ouro.jail.policy/1`.
pub fn check_schema(key_path: &str, schema: Option<&str>) -> Result<(), JailError> {
    match schema {
        None => Ok(()),
        Some(value) if value == SCHEMA_POLICY => Ok(()),
        Some(value) => Err(invalid(
            key_path,
            format!("expected schema `{SCHEMA_POLICY}`, found `{value}`"),
        )),
    }
}

/// Parses `observation.mode`.
///
/// # Errors
/// Returns [`ErrorCode::InvalidConfig`] for an unknown value.
pub fn parse_observe(key_path: &str, text: &str) -> Result<ObserveMode, JailError> {
    match text {
        "on" => Ok(ObserveMode::On),
        "off" => Ok(ObserveMode::Off),
        other => Err(invalid(
            key_path,
            format!("unknown observation mode `{other}`; expected on or off"),
        )),
    }
}

/// Parses `observation.evidence`.
///
/// # Errors
/// Returns [`ErrorCode::InvalidConfig`] for an unknown value.
pub fn parse_evidence(key_path: &str, text: &str) -> Result<EvidenceMode, JailError> {
    match text {
        "strict" => Ok(EvidenceMode::Strict),
        "best-effort" => Ok(EvidenceMode::BestEffort),
        other => Err(invalid(
            key_path,
            format!("unknown evidence mode `{other}`; expected strict or best-effort"),
        )),
    }
}

/// Canonicalizes `[jail_host.network] translation_prefixes` (§6.2).
///
/// Each entry must be an IPv6 CIDR `address/prefix`; it is re-rendered in
/// RFC 5952 form (lowercase, longest run of zero groups compressed) through
/// [`Ipv6Addr`]'s `Display` before it enters the policy, so equivalent
/// spellings such as `2001:0db8::/96` and `2001:db8::/96` produce one digest
/// (§6.3: "equivalent semantic inputs have the same digest"). A zone-id or
/// embedded whitespace would make the entry name a link or two entries at
/// once rather than a network, and anything that is not an IPv6 CIDR is
/// refused instead of being carried into the snapshot as opaque text.
///
/// # Errors
/// Returns [`ErrorCode::InvalidConfig`] naming `key_path` for an entry that
/// is not an IPv6 CIDR with a prefix length of 0..=128.
pub fn canonical_translation_prefixes(
    key_path: &str,
    entries: &[String],
) -> Result<Vec<String>, JailError> {
    entries
        .iter()
        .map(|entry| {
            let refuse_entry = |reason: String| {
                invalid(key_path, format!("`{entry}` is not an IPv6 CIDR: {reason}"))
            };
            if entry.chars().any(char::is_whitespace) {
                return Err(refuse_entry("it contains whitespace".to_owned()));
            }
            let Some((address, prefix)) = entry.split_once('/') else {
                return Err(refuse_entry("it has no `/prefix` length".to_owned()));
            };
            if address.contains('%') {
                return Err(refuse_entry(
                    "a zone-id names a link, not a network".to_owned(),
                ));
            }
            let address: Ipv6Addr = address
                .parse()
                .map_err(|error| refuse_entry(format!("the address is invalid: {error}")))?;
            if prefix.is_empty() || !prefix.bytes().all(|byte| byte.is_ascii_digit()) {
                return Err(refuse_entry(
                    "the prefix length is not a decimal integer".to_owned(),
                ));
            }
            let prefix: u8 = prefix
                .parse()
                .map_err(|_| refuse_entry("the prefix length is not a number".to_owned()))?;
            if prefix > 128 {
                return Err(refuse_entry("the prefix length exceeds 128".to_owned()));
            }
            Ok(format!("{address}/{prefix}"))
        })
        .collect()
}

/// The operator settings read from the environment allow-list (§6.2 step 3).
#[derive(Clone, Default, PartialEq, Eq, Debug)]
pub struct EnvSettings {
    /// `OURO_CONFIG_DIR`.
    pub config_dir: Option<PathBuf>,
    /// `OURO_DATA_DIR`.
    pub data_dir: Option<PathBuf>,
    /// `OURO_JAIL_OBSERVE`.
    pub observe: Option<ObserveMode>,
    /// `OURO_JAIL_EVIDENCE`.
    pub evidence: Option<EvidenceMode>,
    /// `OURO_JAIL_TRACE_CAP`: the local trace budget in bytes.
    pub trace_cap: Option<u64>,
}

/// Reads the allowed environment settings; ignores every other variable.
///
/// No environment-derived path or host grant is accepted (§6.2), so the two
/// path variables only relocate the operator's own directories.
///
/// # Errors
/// Returns [`ErrorCode::InvalidConfig`] when an allowed variable has an
/// unparsable value.
pub fn env_settings(lookup: &dyn Fn(&str) -> Option<OsString>) -> Result<EnvSettings, JailError> {
    let mut settings = EnvSettings::default();
    if let Some(value) = lookup("OURO_CONFIG_DIR") {
        settings.config_dir = Some(PathBuf::from(value));
    }
    if let Some(value) = lookup("OURO_DATA_DIR") {
        settings.data_dir = Some(PathBuf::from(value));
    }
    if let Some(value) = lookup("OURO_JAIL_OBSERVE") {
        let text = value
            .to_str()
            .ok_or_else(|| invalid("OURO_JAIL_OBSERVE", "the value is not UTF-8"))?;
        settings.observe = Some(parse_observe("OURO_JAIL_OBSERVE", text)?);
    }
    if let Some(value) = lookup("OURO_JAIL_EVIDENCE") {
        let text = value
            .to_str()
            .ok_or_else(|| invalid("OURO_JAIL_EVIDENCE", "the value is not UTF-8"))?;
        settings.evidence = Some(parse_evidence("OURO_JAIL_EVIDENCE", text)?);
    }
    if let Some(value) = lookup("OURO_JAIL_TRACE_CAP") {
        let text = value
            .to_str()
            .ok_or_else(|| invalid("OURO_JAIL_TRACE_CAP", "the value is not UTF-8"))?;
        let cap = text.parse::<u64>().map_err(|_| {
            invalid(
                "OURO_JAIL_TRACE_CAP",
                "the value must be plain decimal bytes",
            )
        })?;
        if !(crate::trace::TRACE_CAP_SEAM_MIN..=crate::trace::TRACE_CAP_MAX).contains(&cap) {
            return Err(invalid(
                "OURO_JAIL_TRACE_CAP",
                format!(
                    "the local trace budget must be {}..={} bytes",
                    crate::trace::TRACE_CAP_SEAM_MIN,
                    crate::trace::TRACE_CAP_MAX
                ),
            ));
        }
        settings.trace_cap = Some(cap);
    }
    Ok(settings)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn shared_operator_retention_settings_do_not_become_jail_policy() {
        let config = parse_operator_config("[ledger]\nretain='90d'\ncapture_retain='7d'").unwrap();
        assert!(config.jail.is_none());
        assert_eq!(
            config
                .ledger
                .unwrap()
                .resolve(None, None)
                .unwrap()
                .capture_retain_days,
            7
        );
        assert!(parse_operator_config("[ledger]\nretian='7d'").is_err());
    }

    /// A project `ouro.toml` may not carry `[jail.commands]`: without this
    /// refusal the operator-only rules would be silently dropped.
    #[test]
    fn a_project_file_may_not_carry_command_rules() {
        let error = parse_project_config("[jail.commands]\ndeny = [\"git push --force\"]\n")
            .expect_err("project command rules must refuse");
        assert_eq!(error.key_path.as_deref(), Some("jail.commands"));
        assert!(error.message.contains("operator-only"), "{}", error.message);
        // Without the section the same shape parses.
        assert!(parse_project_config("").is_ok());
    }

    #[test]
    fn wall_units_scale_and_a_bare_integer_refuses() {
        assert_eq!(
            parse_limit_value("k", LimitKey::Wall, "5m").expect("parses"),
            300_000
        );
        assert_eq!(
            parse_limit_value("k", LimitKey::Wall, "300s").expect("parses"),
            300_000
        );
        assert_eq!(
            parse_limit_value("k", LimitKey::Wall, "2h").expect("parses"),
            7_200_000
        );
        assert_eq!(
            parse_limit_value("k", LimitKey::Wall, "250ms").expect("parses"),
            250
        );
        assert!(parse_limit_value("k", LimitKey::Wall, "300").is_err());
        assert!(parse_limit_value("k", LimitKey::Wall, "0s").is_err());
        assert!(parse_limit_value("k", LimitKey::Wall, "-1s").is_err());
        assert!(parse_limit_value("k", LimitKey::Wall, "forever").is_err());
    }

    #[test]
    fn memory_units_are_binary_and_overflow_refuses() {
        assert_eq!(
            parse_limit_value("k", LimitKey::Mem, "512MiB").expect("parses"),
            512 * 1024 * 1024
        );
        assert_eq!(
            parse_limit_value("k", LimitKey::Mem, "1024").expect("parses"),
            1024
        );
        assert!(parse_limit_value("k", LimitKey::Mem, "18446744073709551615GiB").is_err());
        assert!(parse_limit_value("k", LimitKey::Mem, "0KiB").is_err());
    }

    #[test]
    fn swap_is_independent_and_allows_an_explicit_zero() {
        for zero in ["0", "0KiB", "0MiB", "0GiB"] {
            assert_eq!(parse_limit_value("swap", LimitKey::Swap, zero).unwrap(), 0);
            assert!(parse_limit_value("mem", LimitKey::Mem, zero).is_err());
        }
        for bad in ["00", "-1", "max", " 0", "0 ", "18446744073709551615GiB"] {
            assert!(parse_limit_value("swap", LimitKey::Swap, bad).is_err());
        }
        let limits = ceilings_from_cli(&["mem=64MiB".into(), "swap=0".into()]).unwrap();
        assert_eq!(limits.mem.unwrap().value, 64 * 1024 * 1024);
        assert_eq!(limits.swap.unwrap().value, 0);
        assert!(ceilings_from_cli(&["swap=0".into(), "swap=1MiB".into()]).is_err());
    }

    #[test]
    fn a_duplicate_cli_limit_refuses() {
        let error = ceilings_from_cli(&["wall=1m".to_owned(), "wall=2m".to_owned()])
            .expect_err("duplicates refuse");
        assert_eq!(error.code, ErrorCode::InvalidConfig);
        assert_eq!(error.exit_code(), 2);
    }

    #[test]
    fn an_unknown_cli_limit_key_refuses() {
        let error = ceilings_from_cli(&["disk=1".to_owned()]).expect_err("an unknown key refuses");
        assert_eq!(error.code, ErrorCode::InvalidConfig);
    }

    #[test]
    fn translation_prefixes_are_canonicalized_or_refused() {
        let key = "jail_host.network.translation_prefixes";
        let canonical = canonical_translation_prefixes(
            key,
            &[
                "2001:0db8::/96".to_owned(),
                "FE80::/10".to_owned(),
                "2001:db8:0:0:0:0:0:0/96".to_owned(),
            ],
        )
        .expect("every spelling parses");
        assert_eq!(
            canonical,
            vec![
                "2001:db8::/96".to_owned(),
                "fe80::/10".to_owned(),
                "2001:db8::/96".to_owned()
            ],
            "equivalent spellings render as one RFC 5952 form"
        );

        for entry in [
            "banana",
            "2001:db8::",
            "10.0.0.0/8",
            "fe80::1%eth0/64",
            "2001:db8:: /96",
            "2001:db8::/129",
            "2001:db8::/96/48",
        ] {
            let error = canonical_translation_prefixes(key, &[entry.to_owned()])
                .expect_err("a non-CIDR entry refuses");
            assert_eq!(error.code, ErrorCode::InvalidConfig, "for `{entry}`");
            assert_eq!(
                error.key_path.as_deref(),
                Some(key),
                "the refusal names the exact key path"
            );
        }
    }

    #[test]
    fn a_duplicate_toml_key_refuses() {
        let error = parse_policy_file(
            "schema = \"ouro.jail.policy/1\"\nextends = \"tool\"\n[limits]\nwall = \"1m\"\nwall = \"2m\"\n",
        )
        .expect_err("TOML forbids duplicate keys");
        assert_eq!(error.code, ErrorCode::InvalidConfig);
    }

    #[test]
    fn an_unknown_toml_key_refuses() {
        let error = parse_policy_file(
            "schema = \"ouro.jail.policy/1\"\nextends = \"tool\"\nfuture_key = 1\n",
        )
        .expect_err("unknown keys are never ignored");
        assert_eq!(error.code, ErrorCode::InvalidConfig);
    }

    #[test]
    fn the_environment_allow_list_ignores_everything_else() {
        let lookup = |name: &str| match name {
            "OURO_JAIL_OBSERVE" => Some(OsString::from("off")),
            "OURO_JAIL_PROFILE" => Some(OsString::from("none")),
            "OURO_RW" => Some(OsString::from("/")),
            _ => None,
        };
        let settings = env_settings(&lookup).expect("parses");
        assert_eq!(settings.observe, Some(ObserveMode::Off));
        assert_eq!(settings.config_dir, None);
        assert_eq!(settings.data_dir, None);
        assert_eq!(settings.evidence, None);
        assert_eq!(settings.trace_cap, None);
        assert_eq!(ENVIRONMENT_ALLOW_LIST.len(), 5);
    }
}
